﻿using appBLL;
using KalDogWasm6.Shared;
using Microsoft.AspNetCore.Mvc;

using GenCode;

namespace KalDogWasm6.Server.Controllers
{
    //[Authorize]
    [ApiController]
    //[Route("[controller]")]
    public class GenCodeController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;

        public GenCodeController(IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }



        [HttpPost]
        [Route("api/GenCode/PostCombo")]
        public ENTITYTABLE PostCombo([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs" ,SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {
                        
                        string folderin = _Env.ContentRootPath;

                        GenCode.Class1.GenerateCOMBOFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);



                        GenCode.Class1.GenerateCOMBORSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }




        [HttpPost]
        [Route("api/GenCode/PostComboAuto")]
        public ENTITYTABLE PostComboAuto([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        string folderin = _Env.ContentRootPath;

                        GenCode.Class1.GenerateCOMBOAUTORFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        GenCode.Class1.GenerateCOMBOAUTOSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);

  
                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }



        [HttpPost]
        [Route("api/GenCode/Post")]
        public ENTITYTABLE Post([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();
             
            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                //new for combos
                string strdropcol1In = "";
                string strdropcol2In = "";
                string strdropcol3In = "";
                string strdropcol4In = "";
                string strdropcol5In = "";
                string strdropcol6In = "";
                string strautodropcol1In = "";
                string strautodropcol2In = "";
                string strautodropcol3In = "";
                string strautodropcol4In = "";
                string strautodropcol5In = "";
                string strautodropcol6In = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.primarykey;
                column1str = paramENTITY.column1;
                column1type = paramENTITY.column1type;
                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //new for combos
                strdropcol1In = paramENTITY.dropcol1In;
                strdropcol2In = paramENTITY.dropcol2In;
                strdropcol3In = paramENTITY.dropcol3In;
                strdropcol4In = paramENTITY.dropcol4In;
                strdropcol5In = paramENTITY.dropcol5In;
                strdropcol6In = paramENTITY.dropcol6In;

                strautodropcol1In = paramENTITY.autodropcol1In;
                strautodropcol2In = paramENTITY.autodropcol2In;
                strautodropcol3In = paramENTITY.autodropcol3In;
                strautodropcol4In = paramENTITY.autodropcol4In;
                strautodropcol5In = paramENTITY.autodropcol5In;
                strautodropcol6In = paramENTITY.autodropcol6In;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column1str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 1 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column2str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 2 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column3str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 3 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column4str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 4 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        string folderin = _Env.ContentRootPath;

                        GenCode.Class1.GenerateTOPGRIDFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                            strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);



                        GenCode.Class1.GenerateTOPGRIDSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        //Next is for MAUI building code
                        GenCode.Class1.GenerateTOPGRIDMAUI(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                            strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);

                      
						paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                string folderin = "";

                folderin = _Env.ContentRootPath;
                GenCode.Class1.DelALLProgs(progstr, folderin);   //Delete code again

                return paramENTITY;

            }

        }



        [HttpPost]
        [Route("api/DelCode/Post")]
        public ENTITYTABLE PostDel([FromBody] ENTITYTABLE paramENTITY)
        {
           
            try
            {
                string progstr = "";

                //string tablestr = ThisViewModel.tablename;
                progstr = paramENTITY.progname;

                //paramENTITY.propnote = "propnote";  //test

                if (progstr == null || progstr == "")
                {
                    List<string> outputMessagesk = new List<string>();

                    //returnStatus = false;
                    //outputMessagesk.Add("Program Name invalid!");

                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }


                string chk = "NotFound";
                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    {
                        chk = "foundProg";  //so found already
                    }
                }

                if (chk == "NotFound")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please Change Name.";

                }


                string folderin = "";

                folderin = _Env.ContentRootPath;
                GenCode.Class1.DelALLProgs(progstr, folderin);


                paramENTITY.ErrChk = true;
                paramENTITY.ErrMsg = "Code Deleted OK.";

                return paramENTITY;

            }
            catch (Exception ex)
            {
                
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                return paramENTITY;
            }

        }



        [HttpPost]
        [Route("api/EncryptCode/Post")]
        public ENTITYTABLE PostEncrypt([FromBody] ENTITYTABLE paramENTITY)
        {
            
            try
            {
                string folderin = _Env.ContentRootPath;
                bool resultk = GenCode.Class1.EncryptFilesTOPGRID(folderin);
               
                if (!resultk)
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Code Encrypted ERROR!";
                }
                else
                {

                    paramENTITY.ErrChk = true;
                    paramENTITY.ErrMsg = "Code Encrypted OK.";

                }

               
                return paramENTITY;

            }
            catch (Exception ex)
            {
               
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                return paramENTITY;
            }

        }






    }
}
