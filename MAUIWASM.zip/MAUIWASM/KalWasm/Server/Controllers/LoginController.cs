﻿using KalDogWasm6.Shared;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using KalDogWasm6.Server.Models;
//using ShopifySharp;
//using ShopifySharp.Filters;

namespace KalDogWasm6.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public LoginController(IConfiguration configuration,
                               SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager)
        {
            _configuration = configuration;
            _signInManager = signInManager;
            _userManager = userManager;
        }

        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginModel login)
        {


            //--------------------------------------------------------------------------------------
            //Next is TEST of Shopify Order processing
            //--------------------------------------------------------------------------------------
            /*
            string domainstr = "razaball.myshopify.com";
            //string tokenstr = "37dfe4975d7106f9c7c994015b5d05b1";
            string tokenstr = "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";
            var allOrders = new List<Order>();
            var service = new OrderService(domainstr, tokenstr);
            var page = await service.ListAsync(new OrderListFilter
            {
                Limit = 250,
            });

            while (true)
            {
                allOrders.AddRange(page.Items);

                if (!page.HasNextPage)
                {
                    break;
                }

                page = await service.ListAsync(page.GetNextPageFilter());
            }


            //-------------------------------------------------------------------------------

            //-------------------------------------------------------------------------------
            //Create an Order
            var service2 = new OrderService(domainstr, tokenstr);

            var order = new Order()
            {
                CreatedAt = DateTime.UtcNow,
                BillingAddress = new ShopifyAddress()
                {
                    Address1 = "Unit 1008 2 Aqua Street",
                    City = "Southport",
                    Province = "Gold Coast",
                    ProvinceCode = "4215",
                    Zip = "4215",
                    Phone = "555-555-5555",
                    FirstName = "Kalvin",
                    LastName = "Kliese",
                    Company = "RazaTech",
                    Country = "Australia",
                    CountryCode = "US",
                    Default = true,
                },
                LineItems = new List<LineItem>()
    {
        new LineItem()
        {
            Name = "RazaBall White",
            Price = (decimal?)25.00,
            Title = "This is RB"
        }
    },
                FinancialStatus = "paid",
                //Price = (decimal?)5.00,
                TotalPrice = (decimal?)25.00,
                //Email = Guid.NewGuid().ToString() + "@example.com",
                Email = "kalvinlernst@gmail.com",
                Note = "Please check with Customer.",
            };

            order = await service2.CreateAsync(order);

           */
            //-----------------------------------------------------------------------------------------------------------


            var user = await _userManager.FindByEmailAsync(login.Email);
            var result = await _userManager.CheckPasswordAsync(user, login.Password);


            //var result = await _signInManager.PasswordSignInAsync(login.Email, login.Password, false, false);
            //var result = await _signInManager.PasswordSignInAsync(login.Email, login.Password, login.RememberMe, false);

            //if (!result.Succeeded) return BadRequest(new LoginResult { Successful = false, Error = "Username and password are invalid." });
            if (!result) return BadRequest(new LoginResult { Successful = false, Error = "Username and password are invalid." });

            var claims = new[]
            {
            new Claim(ClaimTypes.Name, login.Email)
        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSecurityKey"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expiry = DateTime.Now.AddDays(Convert.ToInt32(_configuration["JwtExpiryInDays"]));

            var token = new JwtSecurityToken(
                _configuration["JwtIssuer"],
                _configuration["JwtAudience"],
                claims,
                expires: expiry,
                signingCredentials: creds
            );

            return Ok(new LoginResult { Successful = true, Token = new JwtSecurityTokenHandler().WriteToken(token) });
        }
    }

    /*
    internal class ShopifyAddress : Address
    {
        public string Address1 { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string ProvinceCode { get; set; }
        public string Zip { get; set; }
        public string Phone { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public bool Default { get; set; }
    }
    */

}
