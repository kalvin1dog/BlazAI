using KalDogWasm6.Server.PersonKOLUI;
using KalDogWasm6.Shared.PersonKOLUI;
using KalDogWasm6.Server.Models.PersonKOLUI;
using Microsoft.AspNetCore.Mvc;


namespace KalDogWasm6.Server.Controllers.PersonKOLUI
{
 
    [ApiController]
    public class PersonKOLCountry_IDautoController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PersonKOLCountry_IDautoController> logger;

        public PersonKOLCountry_IDautoController(ILogger<PersonKOLCountry_IDautoController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PersonKOLCountry_IDauto/GetAsyncListAuto")]
        public async Task<IEnumerable<PersonKOLCountry_IDauto>> GetAsyncListAuto(string Id)
        {
            string testget = Id;
           
            List<PersonKOLCountry_IDauto> ColJobs = new List<PersonKOLCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKOLCountry_IDautoBLL ThisBLL = new PersonKOLCountry_IDautoBLL();

            PersonKOLCountry_IDautoViewModel ThisViewModel = new PersonKOLCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKOLCountryListAuto(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }

          
        [HttpGet]
        [Route("api/PersonKOLCountry_IDauto/GetAsyncListGet")]
        public async Task<IEnumerable<PersonKOLCountry_IDauto>> GetAsyncListGet(string Id)
        {
            string testget = Id;
           
            List<PersonKOLCountry_IDauto> ColJobs = new List<PersonKOLCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKOLCountry_IDautoBLL ThisBLL = new PersonKOLCountry_IDautoBLL();

            PersonKOLCountry_IDautoViewModel ThisViewModel = new PersonKOLCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKOLCountryListGet(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
