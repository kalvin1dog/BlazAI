using KalDogWasm6.Server.PersonKOLUI;
using KalDogWasm6.Shared.PersonKOLUI;
using KalDogWasm6.Server.Models.PersonKOLUI;
using Microsoft.AspNetCore.Mvc;


namespace KalDogWasm6.Server.Controllers.PersonKOLUI
{
 
    [ApiController]
    public class PersonKOLPostCode_IDController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PersonKOLPostCode_IDController> logger;

        public PersonKOLPostCode_IDController(ILogger<PersonKOLPostCode_IDController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PersonKOLPostCode_ID/GetAsyncList")]
        public async Task<IEnumerable<PersonKOLPostCode_ID>> GetAsyncList(string Id)
        {
            string testget = Id;
           
            List<PersonKOLPostCode_ID> ColJobs = new List<PersonKOLPostCode_ID>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKOLPostCode_IDBLL ThisBLL = new PersonKOLPostCode_IDBLL();

            PersonKOLPostCode_IDViewModel ThisViewModel = new PersonKOLPostCode_IDViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKOLPostCodeList(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
