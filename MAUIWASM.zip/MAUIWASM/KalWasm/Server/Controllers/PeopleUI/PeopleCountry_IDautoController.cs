using KalDogWasm6.Server.PeopleUI;
using KalDogWasm6.Shared.PeopleUI;
using KalDogWasm6.Server.Models.PeopleUI;
using Microsoft.AspNetCore.Mvc;


namespace KalDogWasm6.Server.Controllers.PeopleUI
{
 
    [ApiController]
    public class PeopleCountry_IDautoController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PeopleCountry_IDautoController> logger;

        public PeopleCountry_IDautoController(ILogger<PeopleCountry_IDautoController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PeopleCountry_IDauto/GetAsyncListAuto")]
        public async Task<IEnumerable<PeopleCountry_IDauto>> GetAsyncListAuto(string Id)
        {
            string testget = Id;
           
            List<PeopleCountry_IDauto> ColJobs = new List<PeopleCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PeopleCountry_IDautoBLL ThisBLL = new PeopleCountry_IDautoBLL();

            PeopleCountry_IDautoViewModel ThisViewModel = new PeopleCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPeopleCountryListAuto(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }

          
        [HttpGet]
        [Route("api/PeopleCountry_IDauto/GetAsyncListGet")]
        public async Task<IEnumerable<PeopleCountry_IDauto>> GetAsyncListGet(string Id)
        {
            string testget = Id;
           
            List<PeopleCountry_IDauto> ColJobs = new List<PeopleCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PeopleCountry_IDautoBLL ThisBLL = new PeopleCountry_IDautoBLL();

            PeopleCountry_IDautoViewModel ThisViewModel = new PeopleCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPeopleCountryListGet(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
