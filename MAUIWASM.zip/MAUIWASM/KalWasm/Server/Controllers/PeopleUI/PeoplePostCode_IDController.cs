using KalDogWasm6.Server.PeopleUI;
using KalDogWasm6.Shared.PeopleUI;
using KalDogWasm6.Server.Models.PeopleUI;
using Microsoft.AspNetCore.Mvc;


namespace KalDogWasm6.Server.Controllers.PeopleUI
{
 
    [ApiController]
    public class PeoplePostCode_IDController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PeoplePostCode_IDController> logger;

        public PeoplePostCode_IDController(ILogger<PeoplePostCode_IDController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PeoplePostCode_ID/GetAsyncList")]
        public async Task<IEnumerable<PeoplePostCode_ID>> GetAsyncList(string Id)
        {
            string testget = Id;
           
            List<PeoplePostCode_ID> ColJobs = new List<PeoplePostCode_ID>();

            bool returnStatus;
            string returnErrorMessage;

            PeoplePostCode_IDBLL ThisBLL = new PeoplePostCode_IDBLL();

            PeoplePostCode_IDViewModel ThisViewModel = new PeoplePostCode_IDViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPeoplePostCodeList(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
