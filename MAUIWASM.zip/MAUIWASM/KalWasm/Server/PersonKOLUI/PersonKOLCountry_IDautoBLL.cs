using KalDogWasm6.Shared.PersonKOLUI;
using System.Data;
//using Microsoft.Data.SqlClient;
using System.Data.SQLite;
//using Microsoft.Data.Sqlite; 

namespace KalDogWasm6.Server.PersonKOLUI
{
   
    public class PersonKOLCountry_IDautoBLL
    {
     
       //Combo Reference Table/View
        public List<PersonKOLCountry_IDauto> GetPersonKOLCountryListAuto(
            PersonKOLCountry_IDauto SearchValues,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //SqlConnection connection;
            //connection = new SqlConnection();

            SQLiteConnection connection;
            connection = new SQLiteConnection();

            //SqlConnection connection = DBConnectString; //SQL Server
            connection.ConnectionString = DBConnectString;
            connection.Open();


            try
            {
                 
                string strSQL = "";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                //sqlCommand.CommandType = CommandType.Text;
                //sqlCommand.Connection = connection;
                //sqlCommand.CommandText = strSQL;

                string sqlString = "";
                string strfilter = "";

                if (SearchValues.GlobalSearchString == "1")  //just get 1 record
                {
                    sqlString = "SELECT Country_ID, Name FROM Country LIMIT 1 ";
                }
                else
                {
                
                    sqlString = "SELECT Country_ID, Name FROM Country ";
                    strfilter = " WHERE 1=1 ";

                    if (SearchValues.GlobalSearchString != null)
                    {
                        //strfilter = strfilter + " AND UPPER(Name) LIKE " + "'%" + SearchValues.GlobalSearchString.ToUpper().Trim() + "%'";

                        strfilter = strfilter + " AND UPPER(Name) LIKE @fir77 ";
                        SQLiteParameter caram77 = new SQLiteParameter("@fir77", DbType.String);
                        caram77.Value = "%" + SearchValues.GlobalSearchString.ToUpper().Trim() + "%";
                        sqlCommand.Parameters.Add(caram77);


                        
                    }

                }

                
                //strSQL = sqlString + strfilter;   //get ALL
                strSQL = sqlString + strfilter + " LIMIT 20";

                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = strSQL;

                PersonKOLCountry_IDauto vtype;

                List<PersonKOLCountry_IDauto> vtypeList = new List<PersonKOLCountry_IDauto>();

                SQLiteDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read() == true)
                {
                    vtype = new PersonKOLCountry_IDauto();

                    vtype.Country_ID = dataReader["Country_ID"] != DBNull.Value ? Convert.ToInt32(dataReader["Country_ID"]) : 0;
                    vtype.Name = dataReader["Name"] != DBNull.Value ? dataReader["Name"].ToString() : "";

                    vtypeList.Add(vtype);

                }

                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnStatus = true;
                returnErrorMessage = "";

                return vtypeList;

            }
            catch (Exception ex)
            {
                List<PersonKOLCountry_IDauto> vtypeList = new List<PersonKOLCountry_IDauto>();
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return vtypeList;
            }
            finally
            {
                //connection.Close();
            }


        }

        

        
       //Combo Reference Table/View
        public List<PersonKOLCountry_IDauto> GetPersonKOLCountryListGet(
            PersonKOLCountry_IDauto SearchValues,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //SqlConnection connection;
            //connection = new SqlConnection();

            SQLiteConnection connection;
            connection = new SQLiteConnection();

            //SqlConnection connection = DBConnectString; //SQL Server
            connection.ConnectionString = DBConnectString;
            connection.Open();


            try
            {
                 
                string strSQL = "";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                //sqlCommand.CommandType = CommandType.Text;
                //sqlCommand.Connection = connection;
                //sqlCommand.CommandText = strSQL;

                string sqlString = "";
                string strfilter = "";

                sqlString = "SELECT Country_ID, Name FROM Country ";
                strfilter = " WHERE 1=1 ";

                if (SearchValues.GlobalSearchString != null)
                {
                  strfilter = strfilter + " AND Country_ID = " + "" + SearchValues.GlobalSearchString.Trim() + "";
                      
                }

                strSQL = sqlString + strfilter;

                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = strSQL;

                PersonKOLCountry_IDauto vtype;

                List<PersonKOLCountry_IDauto> vtypeList = new List<PersonKOLCountry_IDauto>();

                SQLiteDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read() == true)
                {
                    vtype = new PersonKOLCountry_IDauto();

                    vtype.Country_ID = dataReader["Country_ID"] != DBNull.Value ? Convert.ToInt32(dataReader["Country_ID"]) : 0;
                    vtype.Name = dataReader["Name"] != DBNull.Value ? dataReader["Name"].ToString() : "";

                    vtypeList.Add(vtype);

                }

                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnStatus = true;
                returnErrorMessage = "";

                return vtypeList;

            }
            catch (Exception ex)
            {
                List<PersonKOLCountry_IDauto> vtypeList = new List<PersonKOLCountry_IDauto>();
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return vtypeList;
            }
            finally
            {
                //connection.Close();
            }


        }




    }

}
