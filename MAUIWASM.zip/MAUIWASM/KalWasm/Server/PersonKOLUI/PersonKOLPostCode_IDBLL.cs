using KalDogWasm6.Shared.PersonKOLUI;
using System.Data;
//using Microsoft.Data.SqlClient;
using System.Data.SQLite;
//using Microsoft.Data.Sqlite; 

namespace KalDogWasm6.Server.PersonKOLUI
{
   
    public class PersonKOLPostCode_IDBLL
    {
     
       //Combo Reference Table/View
        public List<PersonKOLPostCode_ID> GetPersonKOLPostCodeList(
            PersonKOLPostCode_ID SearchValues,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //SqlConnection connection;
            //connection = new SqlConnection();

            SQLiteConnection connection;
            connection = new SQLiteConnection();

            //SqlConnection connection = DBConnectString; //SQL Server
            connection.ConnectionString = DBConnectString;
            connection.Open();


            try
            {
                string sqlString = "SELECT PostCode_ID, PostCodeNo FROM PostCode ORDER BY PostCodeNo ";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                PersonKOLPostCode_ID vtype;

                List<PersonKOLPostCode_ID> vtypeList = new List<PersonKOLPostCode_ID>();

                SQLiteDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read() == true)
                {
                    vtype = new PersonKOLPostCode_ID();

                    vtype.PostCode_ID = dataReader["PostCode_ID"] != DBNull.Value ? Convert.ToInt32(dataReader["PostCode_ID"]) : 0;
                    vtype.PostCodeNo = dataReader["PostCodeNo"] != DBNull.Value ? dataReader["PostCodeNo"].ToString() : "";

                    vtypeList.Add(vtype);

                }

                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnStatus = true;
                returnErrorMessage = "";

                return vtypeList;

            }
            catch (Exception ex)
            {
                List<PersonKOLPostCode_ID> vtypeList = new List<PersonKOLPostCode_ID>();
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return vtypeList;
            }
            finally
            {
                //connection.Close();
            }


        }





    }

}
