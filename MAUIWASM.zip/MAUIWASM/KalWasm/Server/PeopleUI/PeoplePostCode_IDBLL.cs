using KalDogWasm6.Shared.PeopleUI;
using System.Data;
//using Microsoft.Data.SqlClient;
using System.Data.SQLite;
//using Microsoft.Data.Sqlite; 

namespace KalDogWasm6.Server.PeopleUI
{
   
    public class PeoplePostCode_IDBLL
    {
     
       //Combo Reference Table/View
        public List<PeoplePostCode_ID> GetPeoplePostCodeList(
            PeoplePostCode_ID SearchValues,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //SqlConnection connection;
            //connection = new SqlConnection();

            SQLiteConnection connection;
            connection = new SQLiteConnection();

            //SqlConnection connection = DBConnectString; //SQL Server
            connection.ConnectionString = DBConnectString;
            connection.Open();


            try
            {
                string sqlString = "SELECT PostCode_ID, PostCodeNo FROM PostCode ORDER BY PostCodeNo ";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                PeoplePostCode_ID vtype;

                List<PeoplePostCode_ID> vtypeList = new List<PeoplePostCode_ID>();

                SQLiteDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read() == true)
                {
                    vtype = new PeoplePostCode_ID();

                    vtype.PostCode_ID = dataReader["PostCode_ID"] != DBNull.Value ? Convert.ToInt32(dataReader["PostCode_ID"]) : 0;
                    vtype.PostCodeNo = dataReader["PostCodeNo"] != DBNull.Value ? dataReader["PostCodeNo"].ToString() : "";

                    vtypeList.Add(vtype);

                }

                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnStatus = true;
                returnErrorMessage = "";

                return vtypeList;

            }
            catch (Exception ex)
            {
                List<PeoplePostCode_ID> vtypeList = new List<PeoplePostCode_ID>();
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return vtypeList;
            }
            finally
            {
                //connection.Close();
            }


        }





    }

}
