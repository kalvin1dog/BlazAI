﻿using Microsoft.AspNetCore.Identity;

namespace KalDogWasm6.Server.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}