﻿using System.ComponentModel.DataAnnotations;

namespace KalDogWasm6.Shared
{
    public class ForgotPasswordModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

    }
}
