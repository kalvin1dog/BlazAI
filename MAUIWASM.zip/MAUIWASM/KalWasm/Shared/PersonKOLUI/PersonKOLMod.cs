using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
//using BlazorValidation.Data;


namespace KalDogWasm6.Shared.PersonKOLUI
{

    public class PersonKOL
    {

        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        //public string DBConnectString { get; set; }

        public int Person_ID { get; set; }   //use int for SqLite DB , use long if SQLServer

        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
         public string FirstName { get; set; }

        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string LastName { get; set; }
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string Address { get; set; }
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public int PostCode_ID { get; set; }


        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public int Country_ID { get; set; }

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public int Job_ID { get; set; }

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public int Bank_ID { get; set; }

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public decimal Savings { get; set; }

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public DateTime UpdateDate { get; set; }
        //public DateTimeOffset UpdateDate { get; set; }       //Use when date is in Offset format
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public string Note { get; set; }
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]


        public string GlobalSearchString { get; set; }
        public double TimeDiff { get; set; }                   //for getting real time anywhere in the world, for Offset Date

        public string FirstName_Str { get; set; }
        public string LastName_Str { get; set; }
        public string Address_Str { get; set; }
        public string PostCode_ID_Str { get; set; }

        public string UpdateDate_Str { get; set; }
    
        public string Note_Str { get; set; }
    
        public string Country_ID_Str { get; set; }
        public string Job_ID_Str { get; set; }
        public string Bank_ID_Str { get; set; }
    
        public string Savings_Str { get; set; }
    
        public string Date_Bought_From { get; set; }
        public string Date_Bought_To { get; set; }
        public string Created_By { get; set; }

        public List<int> PK_IDD { get; set; }
        public List<string> CheckBoxx { get; set; }

        public string Logoimg { get; set; }

        //public int Document_ID { get; set; }    //for Upload of a Document
       
        //Next line is for Checkbox processing
        public int Private_Cover { get; set; }

        //Next line is for Radio processing
        public string Sex { get; set; }

 
        //These next are for columns do not exist
        public string column1BLANK { get; set; }
        public string column2BLANK { get; set; }
        public string column3BLANK { get; set; }
        public string column4BLANK { get; set; }
        public string column5BLANK { get; set; }
        public string column6BLANK { get; set; }
        public string column7BLANK { get; set; }
        public string column8BLANK { get; set; }
        public string column9BLANK { get; set; }
        public string column10BLANK { get; set; }
        public string column11BLANK { get; set; }

    }


    public class PersonKOLUPD
    {
    
        public int Person_ID { get; set; }   //use int for SqLite DB , use long if SQLServer

         public string FirstName { get; set; }

        public string LastName { get; set; }
        
        public string Address { get; set; }
       
        public int PostCode_ID { get; set; }

        public int Country_ID { get; set; }

        public int Job_ID { get; set; }

        public int Bank_ID { get; set; }

        public decimal Savings { get; set; }

        public DateTime UpdateDate { get; set; }
        //public DateTimeOffset UpdateDate { get; set; }       //Use when date is in Offset format
       
        public string Note { get; set; }
       

        

        //These next are for columns do not exist
        public string column1BLANK { get; set; }
        public string column2BLANK { get; set; }
        public string column3BLANK { get; set; }
        public string column4BLANK { get; set; }
        public string column5BLANK { get; set; }
        public string column6BLANK { get; set; }
        public string column7BLANK { get; set; }
        public string column8BLANK { get; set; }
        public string column9BLANK { get; set; }
        public string column10BLANK { get; set; }
        public string column11BLANK { get; set; }


    }

}
