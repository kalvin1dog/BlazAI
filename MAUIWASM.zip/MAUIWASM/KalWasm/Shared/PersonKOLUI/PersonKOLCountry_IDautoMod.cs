using System.ComponentModel.DataAnnotations;

namespace KalDogWasm6.Shared.PersonKOLUI
{

    public class PersonKOLCountry_IDauto
    {
     
        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        public int Country_ID { get; set; }      //use int for SqLite DB , use long if SQLServer

        public string Name { get; set; }


        public string Name_Str { get; set; }

        public string GlobalSearchString { get; set; } = "";
       
    }


    public class PersonKOLCountry_IDUPDauto
    {
    
        public int Country_ID { get; set; }     //use int for SqLite DB , use int if SQLServer

        public string Name { get; set; }

     
    }

}
