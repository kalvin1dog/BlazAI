﻿namespace KalDogWasm6.Shared.Rendering;

public abstract record RenderLocation;
public sealed record RenderedOnServer : RenderLocation;
public sealed record RenderedOnClient : RenderLocation;
