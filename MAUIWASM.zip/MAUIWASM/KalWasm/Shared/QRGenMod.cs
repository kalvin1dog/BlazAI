using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
//using BlazorValidation.Data;


namespace KalDogWasm6.Shared
{

    public class QRGen
    {

        public long QuantityIN { get; set; }
        public long Product_ID { get; set; }
        public string CacheID { get; set; }
    }


}
