﻿using System.ComponentModel.DataAnnotations;

namespace KalDogWasm6.Shared
{
    public class RegisterModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }



        //---------------------------------------------------------------------------------------------
        //KLE added
        
        [Required]
        [Display(Name = "Name")]
        public string FullName { get; set; }

        //[Required]
        [Display(Name = "Address")]
        public string Address { get; set; }


        //[Required]
        [Display(Name = "Country")]
        public string Country { get; set; }


        [Display(Name = "City")]
        public string City { get; set; }


        [Display(Name = "Zip")]
        public string Zip { get; set; }


        [Display(Name = "Statein")]
        public string Statein { get; set; }


        [Display(Name = "Address2")]
        public string Address2 { get; set; }



        [Display(Name = "Birthday")]
        [DataType(DataType.Date)]
        public DateTime BirthDateIn { get; set; }


        [Display(Name = "I agree to the terms & conditions")]
        public bool AgreeMe { get; set; }


        [Display(Name = "MR")]
        public bool MrMe { get; set; }


        [Display(Name = "MISS")]
        public bool MissMe { get; set; }


        [Display(Name = "MRS")]
        public bool MrsMe { get; set; }


        [Display(Name = "OTHER")]
        public bool OtherMe { get; set; }


        //END new KLE code
        //--------------------------------------------------------------------------------------------
        


    }
}
