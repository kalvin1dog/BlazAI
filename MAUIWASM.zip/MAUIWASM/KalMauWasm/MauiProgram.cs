﻿using Microsoft.AspNetCore.Components.WebView.Maui;
using KalDogMaui.Data;
using Microsoft.AspNetCore.Components.Authorization;
using KalDogMaui.Client;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using KalDogMaui.Client.Services;
using KalDogMaui.Shared.Rendering;

namespace KalDogMaui;

public static class MauiProgram
{

	//WASM6 on my PC
	public static string BaseAddressk = DeviceInfo.Platform == DevicePlatform.Android ? "https://10.0.2.2:7040" : "https://localhost:7040";


	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
			});


		builder.Services.AddMauiBlazorWebView();
		#if DEBUG
		builder.Services.AddBlazorWebViewDeveloperTools();
#endif


		//Register needed elements for authentication
		builder.Services.AddAuthorizationCore(); // This is the core functionality

        builder.Services.AddSingleton<WeatherForecastService>();

		builder.Services.AddScoped(sp => new HttpClient
		{
			
			BaseAddress = new Uri(BaseAddressk)

		});

		//builder.Services.AddAuthorizationCore();

		builder.Services.AddScoped<AuthenticationStateProvider,
			ApiAuthenticationStateProvider>();
		builder.Services.AddScoped<IAuthService, AuthService>();

		builder.Services.AddSingleton<RenderLocation, RenderedOnClient>();

		
		return builder.Build();
	}
}
