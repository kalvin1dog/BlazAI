using System.ComponentModel.DataAnnotations;

namespace KalDogMaui.Data.PostRefTTUI
{

    public class PostRefTTLanguage
    {
     
        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        public int Name { get; set; }       //use int for SqLite DB , use long if SQLServer

        public string Capitol { get; set; }


        public string Capitol_Str { get; set; }
       
    }


    public class PostRefTTLanguageUPD
    {
    
        public int Name { get; set; }      //use int for SqLite DB , use long if SQLServer

        public string Capitol { get; set; }

     
    }

}
