using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
//using BlazorValidation.Data;


namespace KalDogMaui.Data.PostRefUI
{

    public class PostRef
    {

        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        //public string DBConnectString { get; set; }

        public int PostCode_ID { get; set; }   //use int for SqLite DB , use long if SQLServer

        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
         public string PostCodeNo { get; set; }

        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public DateTime StartDate { get; set; }
        //public DateTimeOffset Description { get; set; }       //Use when date is in Offset format
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public int Population { get; set; }
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string Description { get; set; }


        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        public DateTime UpdateDate { get; set; }
        //public DateTimeOffset UpdateDate { get; set; }       //Use when date is in Offset format

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]


        public string GlobalSearchString { get; set; }
        public double TimeDiff { get; set; }                   //for getting real time anywhere in the world, for Offset Date

        public string PostCodeNo_Str { get; set; }
        public string StartDate_Str { get; set; }
        public string Population_Str { get; set; }
        public string Description_Str { get; set; }

        public string UpdateDate_Str { get; set; }
    
    
    
    
        public string Date_Bought_From { get; set; }
        public string Date_Bought_To { get; set; }
        public string Created_By { get; set; }

        public List<int> PK_IDD { get; set; }
        public List<string> CheckBoxx { get; set; }

        public string Logoimg { get; set; }

        //public int Document_ID { get; set; }    //for Upload of a Document
       
        //Next line is for Checkbox processing
        public int Private_Cover { get; set; }

        //Next line is for Radio processing
        public string Sex { get; set; }

 
        //These next are for columns do not exist
        public string column1BLANK { get; set; }
        public string column2BLANK { get; set; }
        public string column3BLANK { get; set; }
        public string column4BLANK { get; set; }
        public string column5BLANK { get; set; }
        public string column6BLANK { get; set; }
        public string column7BLANK { get; set; }
        public string column8BLANK { get; set; }
        public string column9BLANK { get; set; }
        public string column10BLANK { get; set; }
        public string column11BLANK { get; set; }

    }


    public class PostRefUPD
    {
    
        public int PostCode_ID { get; set; }   //use int for SqLite DB , use long if SQLServer

         public string PostCodeNo { get; set; }

        public DateTime StartDate { get; set; }
        //public DateTimeOffset Description { get; set; }       //Use when date is in Offset format
        
        public int Population { get; set; }
       
        public string Description { get; set; }

        public DateTime UpdateDate { get; set; }
        //public DateTimeOffset UpdateDate { get; set; }       //Use when date is in Offset format




       
       

        

        //These next are for columns do not exist
        public string column1BLANK { get; set; }
        public string column2BLANK { get; set; }
        public string column3BLANK { get; set; }
        public string column4BLANK { get; set; }
        public string column5BLANK { get; set; }
        public string column6BLANK { get; set; }
        public string column7BLANK { get; set; }
        public string column8BLANK { get; set; }
        public string column9BLANK { get; set; }
        public string column10BLANK { get; set; }
        public string column11BLANK { get; set; }


    }

}
