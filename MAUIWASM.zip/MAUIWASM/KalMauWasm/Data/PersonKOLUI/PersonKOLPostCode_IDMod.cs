using System.ComponentModel.DataAnnotations;

namespace KalDogMaui.Data.PersonKOLUI
{

    public class PersonKOLPostCode_ID
    {
     
        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        public int PostCode_ID { get; set; }       //use int for SqLite DB , use long if SQLServer

        public string PostCodeNo { get; set; }


        public string PostCodeNo_Str { get; set; }
       
    }


    public class PersonKOLPostCode_IDUPD
    {
    
        public int PostCode_ID { get; set; }      //use int for SqLite DB , use long if SQLServer

        public string PostCodeNo { get; set; }

     
    }

}
