﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Text;
using System;

namespace KalDogMaui.Shared
{
    public class UploadedFile
    {
        public string? FileName { get; set; }
        public byte[]? FileContent { get; set; }
        public long ProductIDD { get; set; }

        //public string? ProdImage { get; set; }

        //public byte[] ImageData { get; set; }


    }
   


}
