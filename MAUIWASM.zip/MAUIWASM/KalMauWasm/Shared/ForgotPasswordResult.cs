﻿namespace KalDogMaui.Shared
{
    public class ForgotPasswordResult
    {
        public bool Successful { get; set; }
        public IEnumerable<string> Errors { get; set; }
    }
}
