﻿namespace KalDogMaui.Shared
{
    public class DownLoad
    {
        public DateTime DateCreate { get; set; }

        public int Counter { get; set; }

        public string FileName { get; set; }

        public string FolderDir { get; set; }

    }
}
