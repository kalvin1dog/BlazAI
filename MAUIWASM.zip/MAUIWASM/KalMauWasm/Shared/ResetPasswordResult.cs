﻿namespace KalDogMaui.Shared
{
    public class ResetPasswordResult
    {
        public bool Successful { get; set; }
        public IEnumerable<string> Errors { get; set; }
    }
}
