﻿redirectToCheckout = function (sessionId) {
    //alert("stripe");
    var stripe = Stripe('pk_test_aClpWskI5Fyei9CEUT1ZYetP');
    stripe.redirectToCheckout({
        sessionId: sessionId
    }).then(function (result) {
        if (result.error) {
            var displayError = document.getElementById("stripe-error");
            displayError.textContent = result.error.message;
        }
    });
};