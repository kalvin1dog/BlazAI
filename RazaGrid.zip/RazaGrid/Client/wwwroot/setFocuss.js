﻿// Write your JavaScript code.


//window.SetFocusToElement = (element) => {
  //  element.focus();
//};
function setFocuss(idd) {
    //alert("test PDF");
    document.getElementById("grommID").onmouseover();
    //var link = document.createElement('a');
    //link.download = filename;
    //link.href = "data:application/octet-stream;base64," + bytesBase64;
    //document.body.appendChild(link);
    //link.click();
    //document.body.removeChild(link);


}