﻿// Write your JavaScript code.
//var NetRef;

var xhr = new XMLHttpRequest();
function getIP(filename) {
    alert("test IP");
    //NetRef = dotNetReference;
    //alert("test IP2");
    xhr.onreadystatechange = processRequest;
    xhr.open('GET', "https://api.ipify.org", true);
    //xhr.open('GET', "https://www.goldcoastsotn.com.au/internal/getip.php", true);
    xhr.send();

    //alert("test IP3");


    //var remoteIpAddress = request.HttpContext.Connection.RemoteIpAddress;
    //document.getElementById("ipk").innerHTML = remoteIpAddress;
    //alert("ip is " + remoteIpAddress);

}

var text = document.getElementById('ipk');

function processRequest(e) {
    alert("test IP34");
    if (xhr.readyState == 4 && xhr.status == 200) {
        var response = JSON.parse(xhr.responseText);
        alert("ip is " + response.ip);
        //text.value = response.ip;
        document.getElementById("ipk").innerHTML = response.ip;
        // text.value += '\nIP: ' + response.ip + '\nLocation: ' + response.loc +
        //   '\nCity/Region/Country: ' + response.city + '/' +
        // response.region + '/' + response.country;
        //NetRef.invokeMethodAsync('AddText', response.ip);

    }
    else {

        alert("err is " + xhr.status);
    }
}

function requestPosition() {
    //alert("test IP2");
    xhr.onreadystatechange = processRequest;
    xhr.open('GET', "//ipinfo.io/json", true);
    xhr.send();
}
