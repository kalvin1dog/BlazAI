﻿// Write your JavaScript code.
function saveAsFileQR(filename, bytesBase64) {
    //alert("test ZIP");
    var link = document.createElement('a');
    //link.download = filename;
    //link.href = "data:application/zip;base64," + bytesBase64;
    //link.href = "data:application/x-zip-compressed";
    link.href = filename + "";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);


}
