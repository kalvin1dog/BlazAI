﻿// Write your JavaScript code.

function ShowFireWorks(videoScan, canvasScan) {
    //alert("test QR Scan canvasScan is " + canvasScan);
    //alert("start scan");

    setTimeout(ShowNext1, 200);
    setTimeout(ShowNext2, 200);

}


function ShowNexts() {
    document.getElementById("NextLG").style.display = "";
    document.getElementById("NextXS").style.display = "";
}
// var checkLoggedInn = document.getElementById("CheckLoggedIn").value;
//if (checkLoggedInn != "AlreadyLoggedIn") {



function ShowNext1() {

    //document.getElementById("NextLG").style.display = "";
    //document.getElementById("NextXS").style.display = "";

    var fw1222 = new CFirework("fireworksContainerK", "0000e6", 160, 180, 1.1);
    fw1222.velY = 30;
    fw1222.timeBeforeExplosion = 10;    //default 1500 millsecs
    fw1222.numExplosionParticles = 199;  //default 200
    fw1222.explosionParticleRadius = 2;  //default 2.5
    fw1222.start();

}


function ShowNext2() {

    var fw1222 = new CFirework("fireworksContainerK", "a300cc", 160, 180, 1.1);
    fw1222.velX = -61;
    fw1222.timeBeforeExplosion = 10;    //default 1500 millsecs
    fw1222.numExplosionParticles = 199;  //default 200
    fw1222.explosionParticleRadius = 2;  //default 2.5
    fw1222.start();

}

