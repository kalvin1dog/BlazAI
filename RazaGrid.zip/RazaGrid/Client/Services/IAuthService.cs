﻿using BlazLite1.Shared;

namespace BlazLite1.Client.Services
{
    public interface IAuthService
    {
        Task<LoginResult> Login(LoginModel loginModel);
        Task Logout();
        Task<RegisterResult> Register(RegisterModel registerModel);
        Task<ForgotPasswordResult> Remove(ForgotPasswordModel removeModel);
        Task<ResetPasswordResult> ResetPass(ResetPasswordModel resetPasswordModel);

        Task<ResetPasswordResult> ResetPassForgot(ResetPasswordModel resetPasswordModel);

        Task<ForgotPasswordResult> ForgotPass(ForgotPasswordModel forgotPasswordModel);


    }
}