﻿using BlazLite1.Shared;
using Blazored.LocalStorage;
using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace BlazLite1.Client.Services
{
    // Press Ctrl-R, Ctrl-I to Extract an Interface
    public class AuthService : IAuthService
    {
        private readonly HttpClient _httpClient;
        private readonly AuthenticationStateProvider _authenticationStateProvider;
        private readonly ILocalStorageService _localStorage;

        public AuthService(HttpClient httpClient,
                           AuthenticationStateProvider authenticationStateProvider,
                           ILocalStorageService localStorage)
        {
            _httpClient = httpClient;
            _authenticationStateProvider = authenticationStateProvider;
            _localStorage = localStorage;
        }

        public async Task<ForgotPasswordResult> ForgotPass(ForgotPasswordModel forgotPasswordModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Forgot/Post", forgotPasswordModel);
            //var response = await _httpClient.PostAsJsonAsync("api/accounts", registerModel);
            return await response.Content.ReadFromJsonAsync<ForgotPasswordResult>();
        }

        public async Task<ResetPasswordResult> ResetPass(ResetPasswordModel resetPasswordModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Reset/Post", resetPasswordModel);
            //var response = await _httpClient.PostAsJsonAsync("api/accounts", registerModel);
            return await response.Content.ReadFromJsonAsync<ResetPasswordResult>();
        }
        public async Task<ResetPasswordResult> ResetPassForgot(ResetPasswordModel resetPasswordModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/ResetForgot/Post", resetPasswordModel);
            //var response = await _httpClient.PostAsJsonAsync("api/accounts", registerModel);
            return await response.Content.ReadFromJsonAsync<ResetPasswordResult>();
        }

        public async Task<RegisterResult> Register(RegisterModel registerModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Register/Post", registerModel);
            return await response.Content.ReadFromJsonAsync<RegisterResult>();
        }


        public async Task<ForgotPasswordResult> Remove(ForgotPasswordModel removeModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Remove/Post", removeModel);
            return await response.Content.ReadFromJsonAsync<ForgotPasswordResult>();
        }


        public async Task<LoginResult> Login(LoginModel loginModel)
        {
            var loginAsJson = JsonSerializer.Serialize(loginModel);
            var response = await _httpClient.PostAsync("api/Login",
                new StringContent(loginAsJson, Encoding.UTF8, "application/json"));
            var loginResult = JsonSerializer.Deserialize<LoginResult>(
                await response.Content.ReadAsStringAsync(),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (!response.IsSuccessStatusCode)
            {
                return loginResult;
            }

            await _localStorage.SetItemAsync("authToken", loginResult.Token);
            ((ApiAuthenticationStateProvider)_authenticationStateProvider)
                .MarkUserAsAuthenticated(loginModel.Email);
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", loginResult.Token);

            return loginResult;
        }

        public async Task Logout()
        {
            await _localStorage.RemoveItemAsync("authToken");
            ((ApiAuthenticationStateProvider)_authenticationStateProvider)
                .MarkUserAsLoggedOut();
            _httpClient.DefaultRequestHeaders.Authorization = null;
        }
    }
}
