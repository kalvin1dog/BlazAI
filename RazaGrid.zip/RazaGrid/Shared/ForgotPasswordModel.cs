﻿using System.ComponentModel.DataAnnotations;

namespace BlazLite1.Shared
{
    public class ForgotPasswordModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

    }
}
