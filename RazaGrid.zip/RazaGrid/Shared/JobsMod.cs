﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Text;
using System;

namespace BlazLite1.Shared
{

    public class Jobs
    {

        public string Statuss { get; set; }


    }




}
