using System.ComponentModel.DataAnnotations;

namespace BlazLite1.Shared.PersonKALUI
{

    public class PersonKALPostCode_ID
    {
     
        public int TotalPages { get; set; }
        public int TotalRows { get; set; }

        public int PostCode_ID { get; set; }       //use int for SqLite DB , use long if SQLServer

        public string PostCodeNo { get; set; }


        public string PostCodeNo_Str { get; set; }
       
    }


    public class PersonKALPostCode_IDUPD
    {
    
        public int PostCode_ID { get; set; }      //use int for SqLite DB , use long if SQLServer

        public string PostCodeNo { get; set; }

     
    }

}
