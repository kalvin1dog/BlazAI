﻿using Microsoft.AspNetCore.Identity;

namespace BlazLite1.Server.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}