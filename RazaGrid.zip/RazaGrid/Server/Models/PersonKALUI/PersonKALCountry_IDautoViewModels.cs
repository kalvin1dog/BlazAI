using System.Reflection;
using appBLL;
 
namespace BlazLite1.Server.Models.PersonKALUI
{
    public class PersonKALCountry_IDautoViewModel : BlazLite1.Shared.PersonKALUI.PersonKALCountry_IDauto
    {

        public string DBConnectString { get; set; }
        public int CurrentPageNumber { get; set; }
        public int CurrentRowNumber { get; set; }     
        public int PageSize { get; set; }      
        //public int TotalPages { get; set; }
        //public int TotalRows { get; set; }
        public int PageRows { get; set; }
        public List<string> ReturnMessage { get; set; }
        public bool ReturnStatus { get; set; }
        public string SortBy { get; set; }
        public string SortAscendingDescending { get; set; }
        public int PreviframeWidth { get; set; }
        public int PreviframeHeight { get; set; } 
        public string SortBy2 { get; set; }
        public string SortAscendingDescending2 { get; set; }  
        public int PageSize2 { get; set; }  
        public string download_token_value { get; set; }
        public string PDFFlag { get; set; }

        public void UpdateViewModel(object fromRecord, PropertyInfo[] fromFields)
        {
            UtilitiesBLL.SetProperties(fromFields, fromRecord, this);
        }
      
    }    

}