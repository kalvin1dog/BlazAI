using BlazLite1.Shared.PersonKALUI;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Data.SQLite;
using appBLL;
 
namespace BlazLite1.Server.PersonKALUI
{
    /// <summary>
    /// GLOBAL Business Logic Layer
    /// </summary>
    public class PersonKALBLL
    {

        /// <summary>
        /// Uses PAGING GRID Query to get 1 page at a time.
        /// By internal SQL statement
        /// </summary>
        public List<PersonKAL> PersonKALSearch(
            PersonKAL SearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int totalRows,
            out int totalPages,
            out int pageRows,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentRow;
            int result;

            try
            {
                totalPages = 0;
                totalRows = 0;
               pageRows = 0;
               double timediff = SearchValues.TimeDiff;     //getting local time difference from UTC, from javascript on client

                List<PersonKAL> GridList = new List<PersonKAL>();
                
                DataTable scriptDataTable = GetPersonKAL(SearchValues,
                    currentPageNumber,
                    pageSize,
                    sortBy,
                    sortAscendingDescending,
                    DBConnectString,
                    out totalRows,
                    out returnStatus,
                    out returnErrorMessage);

                if (returnStatus == false)
                {
                    return GridList;
                }

                //totalRows = scriptDataTable.Rows.Count;
                totalPages = 0;

                Math.DivRem(totalRows, pageSize, out result);
                if (result > 0)
                    totalPages = Convert.ToInt32(totalRows / pageSize) + 1;
                else
                    totalPages = Convert.ToInt32(totalRows / pageSize);

                currentRow = 0;

                for (int i = 0; i < scriptDataTable.Rows.Count; i++)
                {
                        currentRow++;

                        PersonKAL recList = new PersonKAL();

                        recList.Person_ID = scriptDataTable.Rows[i]["Person_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Person_ID"]) : 0;

                        recList.FirstName = scriptDataTable.Rows[i]["FirstName"] != DBNull.Value ? scriptDataTable.Rows[i]["FirstName"].ToString() : "";



                        recList.LastName = scriptDataTable.Rows[i]["LastName"] != DBNull.Value ? scriptDataTable.Rows[i]["LastName"].ToString() : "";



                        recList.Address = scriptDataTable.Rows[i]["Address"] != DBNull.Value ? scriptDataTable.Rows[i]["Address"].ToString() : "";
           





                        if (scriptDataTable.Rows[i]["UpdateDate"] == DBNull.Value)
                        {
                            recList.UpdateDate = Convert.ToDateTime("01/01/1858");
                            //recList.UpdateDate = DateTimeOffset.Parse("01/01/1858");       //option for Date in Offset format
                        }
                        else
                        {
                            recList.UpdateDate = Convert.ToDateTime(scriptDataTable.Rows[i]["UpdateDate"]);
                            //recList.UpdateDate = DateTimeOffset.Parse(scriptDataTable.Rows[i]["UpdateDate"].ToString());      //option for Date in Offset format
                            //recList.UpdateDate = recList.UpdateDate.AddMinutes(-timediff);                                                        //adjust to local time here    
                       }

                       

                        recList.Country_ID = scriptDataTable.Rows[i]["Country_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Country_ID"]) : 0;


                       

                        recList.PostCode_ID = scriptDataTable.Rows[i]["PostCode_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["PostCode_ID"]) : 0;


                       

                        recList.Bank_ID = scriptDataTable.Rows[i]["Bank_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Bank_ID"]) : 0;


                       

                        recList.Savings = scriptDataTable.Rows[i]["Savings"] != DBNull.Value ? Convert.ToDecimal(scriptDataTable.Rows[i]["Savings"]) : 0;


                       

                        recList.Job_ID = scriptDataTable.Rows[i]["Job_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Job_ID"]) : 0;



                        recList.Note = scriptDataTable.Rows[i]["Note"] != DBNull.Value ? scriptDataTable.Rows[i]["Note"].ToString() : "";



                       





                        recList.TotalPages = totalPages;
                        recList.TotalRows = totalRows;

                        GridList.Add(recList);

                }
                
                pageRows = currentRow;

                returnErrorMessage = "";
                returnStatus = true;
                return GridList;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
                totalPages = 0;
                totalRows = 0;
                pageRows = 0;

                List<PersonKAL> GridList = new List<PersonKAL>();
             
                return GridList;
            }

        }

  

        /// <summary>
        /// Get Scripts -  SQL SERVER ONLY
        /// Uses PAGING GRID Query to get 1 page at a time.
        /// By internal SQL statements
        /// </summary>
        public DataTable GetPersonKAL(
            PersonKAL scriptSearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int TotalRecords,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage); //SQL Server
            //OracleConnection connection = CreateConnectionOracle(out returnStatus, out returnErrorMessage);  //Oracle

            //SqlConnection connection;
            //connection = new SqlConnection();
            
            SQLiteConnection connection;
            connection = new SQLiteConnection();


            try
            {
                int StartPoint;
                int EndPoint;
                String strfilter = "";
                bool GlobalSearchSQL = false;

                DataSet scriptData = new DataSet();

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                //SqlCommand scriptCommand = new SqlCommand();
                SQLiteCommand scriptCommand = new SQLiteCommand();
                scriptCommand.CommandType = CommandType.Text;
                scriptCommand.Connection = connection;


                //String strFields = "Person_ID, FirstName, LastName, ";
                //strFields = strFields + "Address, ";

                String strFields = "Person_ID, FirstName, LastName ";

                strFields = strFields + ", Address ";
                strFields = strFields + ", Note ";
                
                strFields = strFields + ", UpdateDate ";
                   
                strFields = strFields + ", Country_ID ";
                strFields = strFields + ", PostCode_ID ";
                strFields = strFields + ", Bank_ID ";
                strFields = strFields + ", Job_ID ";
                      
                strFields = strFields + ", Savings ";

                String strTable = "Person ";
               
                strfilter = " WHERE 1=1 ";


                //Next code will have to be done manually, depending if any columns are Char
                //if (scriptSearchValues.GlobalSearchString != null)
                //{
                    //GlobalSearchSQL = true;
                    //strfilter = strfilter + " AND ( ";

                    //strfilter = strfilter + " UPPER(FirstName_Str) LIKE @ppt1 OR  ";
                    //SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                    //param1.Value = "%" + scriptSearchValues.GlobalSearchString.ToUpper().Trim() + "%";
                    //scriptCommand.Parameters.Add(param1);

                    //strfilter = strfilter + " UPPER(LastName_Str) LIKE @ppt2  ";
                    //SQLiteParameter param2 = new SQLiteParameter("@ppt2", DbType.String);
                    //param2.Value = "%" + scriptSearchValues.GlobalSearchString.ToUpper().Trim() + "%";
                    //scriptCommand.Parameters.Add(param2);

                    //strfilter = strfilter + " ) ";
                //}


                if (GlobalSearchSQL == false)  //OK use normal individual Search strings
                {
                    if (scriptSearchValues.FirstName_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(FirstName) LIKE @ppt1 ";
                        //SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                        SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                        param1.Value = "%" + scriptSearchValues.FirstName_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param1);
                    }





                    if (scriptSearchValues.LastName_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(LastName) LIKE @ppt2 ";
                        SQLiteParameter param2 = new SQLiteParameter("@ppt2", DbType.String);
                        param2.Value = "%" + scriptSearchValues.LastName_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param2);
                    }





                    if (scriptSearchValues.Address_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(Address) LIKE @ppt3 ";
                        SQLiteParameter param3 = new SQLiteParameter("@ppt3", DbType.String);
                        param3.Value = "%" + scriptSearchValues.Address_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param3);
                    }








                    if (scriptSearchValues.UpdateDate_Str != null)
                    {
                        strfilter = strfilter + " AND UpdateDate >= @ppt4 ";
                        SQLiteParameter paramcol4 = new SQLiteParameter("@ppt4", DbType.DateTime);
                        paramcol4.Value = "" + scriptSearchValues.UpdateDate_Str.ToUpper().Trim() + "";
                        scriptCommand.Parameters.Add(paramcol4);
                     }

                    //if (scriptSearchValues.Address_Str != null)
                    //{
                        //SQLiteParameter param11 = new SQLiteParameter("@ppt3", DbType.DateTime);
                        //param11.Value = "" + scriptSearchValues.Address_Str.ToUpper().Trim() + "";
                        //scriptCommand.Parameters.Add(param11);

                       // if (scriptSearchValues.UpdateDate_Str != null)
                       // {
                           // sqlWhereClause.Append(" AND Address BETWEEN @ppt3 AND @ppt4 ");
                            //SQLiteParameter param12 = new SQLiteParameter("@ppt4", DbType.DateTime);
                            //param12.Value = "" + scriptSearchValues.UpdateDate_Str.ToUpper().Trim() + "";
                            //scriptCommand.Parameters.Add(param12);
                        //}
                    //}


                }


                //String strWherePK = "WHERE Person_ID = @PKID ";
                //SQLiteParameter parampk = new SQLiteParameter("@PKID", DbType.Int32);
                //parampk.Value = scriptSearchValues.Person_ID;
                //scriptCommand.Parameters.Add(parampk);


                String strsort = "";
                if (sortBy == "Person_ID")
                {
                    strsort = strsort + " ORDER BY Person_ID ";
                }
                else if (sortBy == "FirstName")
                {
                    strsort = strsort + " ORDER BY FirstName ";
                }
                else if (sortBy == "LastName")
                {
                    strsort = strsort + " ORDER BY LastName ";
                }
                else if (sortBy == "Address")
                {
                    strsort = strsort + " ORDER BY Address ";
                }
                else if (sortBy == "UpdateDate")
                {
                    strsort = strsort + " ORDER BY UpdateDate ";
                }
                //else if (sortBy == "Country_ID")
                //{
                    //strsort = strsort + " ORDER BY Country_ID ";
                //}

                //else if (sortBy == "PersonKALSixthCol")
                //{
                    //strsort = strsort + " ORDER BY UpdateDate ";
                //}
                else
                {
                    strsort = strsort + " ORDER BY UpdateDate ";
                }

                if (sortAscendingDescending == "DESC")
                {
                    strsort = strsort + " DESC ";
                }
               
                

                if (currentPageNumber == 1)
                {
                    StartPoint = 1;
                }
                else
                {
                    StartPoint = ((currentPageNumber - 1) * pageSize) + 1;
                }
                EndPoint = currentPageNumber * pageSize;

                String strSQL = "";

                TotalRecords = 0;
                strSQL = "SELECT count(*) FROM " + strTable + strfilter;
                scriptCommand.CommandText = strSQL;
                TotalRecords = Convert.ToInt32(scriptCommand.ExecuteScalar());


                //if PageSize = -1, then creating PDF Report instead, so get all records.
                if (pageSize == -1)
                {
                    EndPoint = TotalRecords;
                }


                //Check if PK_ID exists, that means coming back from Update/Add popup. PK_ID is 0 for normal grid paging
                strSQL = "";
                //if (scriptSearchValues.Person_ID != 0)
                //{
                   // strSQL = "SELECT  " + strFields + " FROM " + strTable + strWherePK;
                   // strSQL = strSQL + " UNION ";
                   // if (TotalRecords == 0)   //going to show only 1 record
                   // {
                   //     TotalRecords = 1;  //so as to show the one record in grid at least
                   // }
                //}

                strSQL = strSQL + "SELECT  " + strFields + " FROM ";
                strSQL = strSQL + " (SELECT ROW_NUMBER() OVER (" + strsort + ") ";
                //strSQL = strSQL + " (SELECT TOP " + EndPoint + " ROW_NUMBER() OVER (" + strsort + ") ";
                strSQL = strSQL + " AS Row, " + strFields + " FROM " + strTable + strfilter + ") ";
                strSQL = strSQL + " AS LogWithRowNumbers ";
                //strSQL = strSQL + " WHERE Row >= @Startit AND Row <= @Endit " + " ";
                strSQL = strSQL + " WHERE Row >= " + StartPoint + " AND Row <= " + EndPoint + " ";
                strSQL = strSQL + strsort + " ";


                scriptCommand.CommandText = strSQL;

                //scriptCommand.Parameters.AddWithValue("Startit", StartPoint);
                //scriptCommand.Parameters.AddWithValue("Endit", EndPoint);

                SQLiteDataAdapter sqlAdapter = new SQLiteDataAdapter(scriptCommand);
                sqlAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;  //NB!!!!!
                sqlAdapter.Fill(scriptData);

               
                //strSQL = "SELECT count(*) FROM " + strTable + strfilter;
                //scriptCommand.CommandText = strSQL;
                //TotalRecords = Convert.ToInt32(scriptCommand.ExecuteScalar());

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnErrorMessage = "";
                returnStatus = true;

                return scriptData.Tables[0];
            }
            catch (Exception ex)
            {
                TotalRecords = 0;
                returnStatus = false;
                returnErrorMessage = ex.Message;
                //print ("error message is: " + returnErrorMessage);
                //Console.WriteLine("error message is: " + returnErrorMessage);

                DataTable scriptData = new DataTable();
                return scriptData;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
               // {
                   // connection.Close();
                   // connection.Dispose();
               // }
               
            }


        }



        /// <summary>
        /// Get Detail Information
        /// </summary>
        public PersonKAL GetPersonKALDetail(int PK_ID, string DBconnectString,
            out bool returnStatus,
            out string returnErrorMessage,
            out List<string> returnMessages)
        {

           //UtilitiesBLL UtilitiesBLLget = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLLget.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage); //SQL Server
            SqlConnection connection;
            connection = new SqlConnection();

            try
            {

                //List<RiskLevelList> ptypeList = new List<RiskLevelList>();

                string sqlString = "SELECT * FROM Person WHERE Person_ID = @PK_ID";
               //string sqlString = "SELECT * FROM ~viewcombotable~ WHERE Person_ID = @PK_ID";       //for normal combo, so as to show field on detail form

                returnErrorMessage = "";

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBconnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@PK_ID", DbType.String);
                param1.Value = PK_ID;
                //param1.Value = 312;
                sqlCommand.Parameters.Add(param1);

                SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);

                DataSet scriptData = new DataSet();
                sqlAdapter.Fill(scriptData);

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Person Information Retrieved");

                returnStatus = true;
                returnMessages = outputMessages;

                DateTime dateResult;
                string dateCheck = "";

                PersonKAL script = new PersonKAL();

                script.Person_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Person_ID"]);

                //script.FirstName = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["FirstName"]);

                 script.FirstName = scriptData.Tables[0].Rows[0]["FirstName"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["FirstName"].ToString() : "";




                //script.LastName = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["LastName"]);

                 script.LastName = scriptData.Tables[0].Rows[0]["LastName"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["LastName"].ToString() : "";



                //script.Address = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Address"]);

                 script.Address = scriptData.Tables[0].Rows[0]["Address"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Address"].ToString() : "";






                dateCheck = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["UpdateDate"]);
                if (scriptData.Tables[0].Rows[0]["UpdateDate"] == DBNull.Value)
                {
                    script.UpdateDate = Convert.ToDateTime("01/01/1858");
                    script.UpdateDate_Str = "";    //display on form
                }
                else
                {
                    if (DateTime.TryParse(dateCheck, out dateResult) == true)
                    {
                        script.UpdateDate = Convert.ToDateTime(scriptData.Tables[0].Rows[0]["UpdateDate"]);
                        script.UpdateDate_Str = UtilitiesBLL.FormatDate(script.UpdateDate);   //display on form
                        //script.UpdateDate = DateTimeOffset.Parse(scriptData.Tables[0].Rows[0]["UpdateDate"].ToString());   //optional display Offset Date on form
                        //script.UpdateDate_Str = UtilitiesBLL.FormatDateOffsetTime(script.UpdateDate);                                           //optional display Offset Date on form
                    }
                    else
                    {
                        script.UpdateDate_Str = "";
                    }
                }


                
                //script.Country_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Country_ID"]);


                 script.Country_ID = scriptData.Tables[0].Rows[0]["Country_ID"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Country_ID"]) : 0;


                
                //script.PostCode_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["PostCode_ID"]);


                 script.PostCode_ID = scriptData.Tables[0].Rows[0]["PostCode_ID"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["PostCode_ID"]) : 0;


                
                //script.Bank_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Bank_ID"]);


                 script.Bank_ID = scriptData.Tables[0].Rows[0]["Bank_ID"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Bank_ID"]) : 0;


                
                //script.Savings = Convert.ToDecimal(scriptData.Tables[0].Rows[0]["Savings"]);


                 script.Savings = scriptData.Tables[0].Rows[0]["Savings"] != DBNull.Value ? Convert.ToDecimal(scriptData.Tables[0].Rows[0]["Savings"]) : 0;


                
                //script.Job_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Job_ID"]);


                 script.Job_ID = scriptData.Tables[0].Rows[0]["Job_ID"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Job_ID"]) : 0;


                
                //script.Note = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Note"]);

                 script.Note = scriptData.Tables[0].Rows[0]["Note"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Note"].ToString() : "";



                





                //Next line is for Checkbox
                //script.Private_Cover = scriptData.Tables[0].Rows[0]["Private_Cover"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Private_Cover"]) : 0;
       
                //Next line is for Radio Button
                //script.Sex = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Sex"]);


                //----------------------------------------------------------------------------------------------------------------------
                //For Combo Normal processing  NOTE:-  Usually using an above column for combo display (eg column4)
                //                                                               
                //----------------------------------------------------------------------------------------------------------------------
                //next for combo by TEXT only
                //script.normcombocol1 = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["normcombocol1"]);    //normcombocol1  is column in table (usually a text field)   

                //ONLY NEED next line for when using an ID as the key stored in the Table. normcombopkid is a column in the table.
                //script.normcombopkid = scriptData.Tables[0].Rows[0]["normcombopkid"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["normcombopkid"]) : 0;
                //----------------------------------------------------------------------------------------------------------------------
                //END For Combo Normal processing
                //----------------------------------------------------------------------------------------------------------------------




                //---------------------------------------------------------------------------------------------------
                //get List for normal combo in EDIT mode, Get combo List ready for process in detail form
                //Reading Reference table
                //---------------------------------------------------------------------------------------------------
                //List<PersonKALnormcombo> PersonKALnormcomboList = new List<PersonKALnormcombo>(); 
                //PersonKALnormcomboList = GetPersonKALnormcombo(out returnStatus, out returnErrorMessage);
                //script.PersonKALnormcomboList = PersonKALnormcomboList;
                //---------------------------------------------------------------------------------------------------
                //END get Combo list
                //---------------------------------------------------------------------------------------------------

                return script;

            }
            catch (Exception ex)
            {

                List<string> outputMessages = new List<string>();

                returnStatus = false;
                returnErrorMessage = ex.Message;
                returnMessages = outputMessages;

                PersonKAL script = new PersonKAL();

                return script;
            }
            finally
            {
                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
            }

        }



        /// <summary>
        /// Format Detail Data
        /// </summary>
        public void FormatScriptData(ref PersonKAL scriptInformation, 
            out bool returnStatus,                                    
            out string returnErrorMessage)
        {

            try
            {
                if (scriptInformation.FirstName == null) scriptInformation.FirstName = "";
                if (scriptInformation.LastName == null) scriptInformation.LastName = "";
                if (scriptInformation.Address == null) scriptInformation.Address = "";
                
                
                if (scriptInformation.Note == null) scriptInformation.Note = "";
             

                //if (scriptInformation.Company == null) scriptInformation.Company = "";
                //if (scriptInformation.Script_Code == null) scriptInformation.Script_Code = "";

                //scriptInformation.Script_Name = scriptInformation.Script_Name.ToUpper().Trim();
                //scriptInformation.Company = scriptInformation.Company.ToUpper().Trim();
                //scriptInformation.Script_Code = scriptInformation.Script_Code.ToUpper().Trim();

                returnErrorMessage = "";
                returnStatus = true;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
            }

        }

        /// <summary>
        /// Validate Detail
        /// </summary>
        public bool ValidateScript(PersonKAL scriptInformation, 
            out List<string> Messages, 
            out bool returnStatus, 
            out string returnErrorMessage)
        {

            try
            {

                bool validPatient = true;

                List<string> outputMessages = new List<string>();

                if (scriptInformation.FirstName == null || scriptInformation.FirstName.Trim().Length == 0)
                {
                    outputMessages.Add("FirstName is required.FirstName");
                    validPatient = false;
                }




                if (scriptInformation.LastName == null || scriptInformation.LastName.Trim().Length == 0)
                {
                    outputMessages.Add("LastName is required.LastName");
                    validPatient = false;
                }




                if (scriptInformation.Address == null || scriptInformation.Address.Trim().Length == 0)
                {
                    outputMessages.Add("Address is required.~Address");
                    validPatient = false;
                }





                if (appBLL.UtilitiesBLL.IsValidDate(scriptInformation.UpdateDate.ToString()) == false)
                {
                    outputMessages.Add("UpdateDate is invalid.UpdateDate");
                    validPatient = false;
                }

                if (appBLL.UtilitiesBLL.IsDateSupplied(scriptInformation.UpdateDate.ToString()) == false)
                {
                    outputMessages.Add("UpdateDate is required.UpdateDate");
                    validPatient = false;
                }


                //Check for Duplicates
                /*
                if (scriptInformation.Person_ID != null && scriptInformation.FirstName != null)
                {
                    bool duplicateVehicle = DuplicateVehicle(
                        scriptInformation.Person_ID,
                        scriptInformation.FirstName, 
                        out returnStatus, 
                        out returnErrorMessage);

                    if (returnStatus == false)
                    {
                        outputMessages.Add(returnErrorMessage);
                        Messages = outputMessages;
                        return false;
                    }

                    if (duplicateVehicle == true)
                    {
                        outputMessages.Add("Duplicate Person_ID and/or FirstName");
                        validPatient = false;
                    }
                }
                */


                Messages = outputMessages;

                returnStatus = true;
                returnErrorMessage = "";

                return validPatient;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();
                Messages = outputMessages;

                returnStatus = false;
                returnErrorMessage = ex.Message;
                
                return false;
            }

        }

        
        /// <summary>
        /// Check For Duplicate Detail
        /// </summary>
        public bool DuplicateVehicle(int vehicleID, 
            string vehicleName, 
            out bool returnStatus, 
            out string returnErrorMessage)
        {

           //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            SqlConnection connection;
            connection = new SqlConnection();

            try
            {

                string sqlString = "SELECT Person_ID FROM Person ";
                sqlString = sqlString + " WHERE FirstName = @Name ";
 
                if (vehicleID > 0)
                {
                    sqlString = sqlString + " AND Person_ID <> @VEHICLE_ID";
                }

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                String DBconnectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBconnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@Name", DbType.String);
                param1.Value = vehicleName;
                sqlCommand.Parameters.Add(param1);

                if (vehicleID > 0)
                {
                    SQLiteParameter param3 = new SQLiteParameter("@VEHICLE_ID", DbType.Int32);
                    param3.Value = vehicleID;
                    sqlCommand.Parameters.Add(param3);
                }

                bool duplicatePatient = false;

                IDataReader dataReader = sqlCommand.ExecuteReader();
                if (dataReader.Read())
                {
                    duplicatePatient = true;
                }

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                returnStatus = true;
                returnErrorMessage = "";

                return duplicatePatient;

            }
            catch (Exception ex)
            {               
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return false;
            }
            finally
            {
                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
            }

        }
     
        
         
        /// <summary>
        /// Add Detail
        /// </summary>
        public PersonKAL AddPersonKAL(PersonKAL scriptInformation, 
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out List<string>returnMessages, 
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            
            SQLiteConnection connection;
            connection = new SQLiteConnection();


            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;
                returnRowNumber = -2;
          
                //StringBuilder sqlBuilder = new StringBuilder();

                List<string> messages;

                FormatScriptData(ref scriptInformation, out returnStatus, out returnErrorMessage);

                bool validScript = ValidateScript(
                    scriptInformation,
                    out messages,
                    out returnStatus,
                    out returnErrorMessage);

                if (validScript == false)
                {
                    returnStatus = false;
                    returnMessages = messages;
                    scriptInformation.Person_ID = -1;  //if validation error, make sure sent back json PK_ID is still set to -1 (for Add)
                    return scriptInformation;
                }


                string sqlString = "INSERT INTO Person ( ";
                sqlString = sqlString + " FirstName, LastName, ";

                sqlString = sqlString + " Note, ";
                
                
                sqlString = sqlString + " Country_ID, ";
                sqlString = sqlString + " PostCode_ID, ";
                sqlString = sqlString + " Bank_ID, ";
                sqlString = sqlString + " Job_ID, ";
                  
                sqlString = sqlString + " Savings, ";


                sqlString = sqlString + " Address, UpdateDate) VALUES ( ";
                sqlString = sqlString + " @Colum1, @Colum2, ";

                sqlString = sqlString + " @Colum10, ";
                 
                
                sqlString = sqlString + " @colum5, ";
                sqlString = sqlString + " @colum6, ";
                sqlString = sqlString + " @colum7, ";
                sqlString = sqlString + " @colum9, ";
                  
                sqlString = sqlString + " @colum8, ";

                sqlString = sqlString + " @Colum3, @Colum4)";
                //sqlString = sqlString + " select SCOPE_IDENTITY()";



                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@Colum1", DbType.String);
                param1.Value = scriptInformation.FirstName;
                sqlCommand.Parameters.Add(param1);





                SQLiteParameter param2 = new SQLiteParameter("@Colum2", DbType.String);
                param2.Value = scriptInformation.LastName;
                sqlCommand.Parameters.Add(param2);





                SQLiteParameter param3 = new SQLiteParameter("@Colum3", DbType.String);
                param3.Value = scriptInformation.Address;
                sqlCommand.Parameters.Add(param3);








                SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTime);
                //SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTimeOffset);    //optional for Offset Date format
                param4.Value = scriptInformation.UpdateDate;
                sqlCommand.Parameters.Add(param4);



                SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                param5.Value = scriptInformation.Country_ID;
                sqlCommand.Parameters.Add(param5);



                

                SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                param6.Value = scriptInformation.PostCode_ID;
                sqlCommand.Parameters.Add(param6);



                

                SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.Int32);
                param7.Value = scriptInformation.Bank_ID;
                sqlCommand.Parameters.Add(param7);



                


                SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.Decimal);
                param8.Value = scriptInformation.Savings;
                sqlCommand.Parameters.Add(param8);


                

                SQLiteParameter param9 = new SQLiteParameter("@Colum9", DbType.Int32);
                param9.Value = scriptInformation.Job_ID;
                sqlCommand.Parameters.Add(param9);



                
                SQLiteParameter param10 = new SQLiteParameter("@Colum10", DbType.String);
                param10.Value = scriptInformation.Note;
                sqlCommand.Parameters.Add(param10);




                







                //next parameter is for Checkbox processing
                //SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                //param5.Value = scriptInformation.Private_Cover;
                //sqlCommand.Parameters.Add(param5);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.String);    //combo by TEXT only. 
                //param6.Value = scriptInformation.normcombocol1;   
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                //param6.Value = scriptInformation.normcombopkid;
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                //param7.Value = scriptInformation.Sex;
                //sqlCommand.Parameters.Add(param7);


                int Status = sqlCommand.ExecuteNonQuery();

                sqlCommand.CommandText = "select last_insert_rowid()";

                scriptInformation.Person_ID = Convert.ToInt32(sqlCommand.ExecuteScalar());

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Person has been added.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();
                outputMessages.Add(ex.Message);
        
                returnPageNumber = -1;
                returnRowNumber = -2;
                returnStatus = false;
                returnErrorMessage = ex.Message;
                returnMessages = outputMessages;
                scriptInformation.Person_ID = -1;  //if validation error, make sure sent back json PK_ID is still set to -1 (for Add)
                //connection.Close();

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                   // connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }

       


        /// <summary>
        /// Update Detail
        /// </summary>
        public PersonKAL UpdatePersonKAL(PersonKAL scriptInformation, 
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,          
            out List<string> returnMessages)
        {

            string returnErrorMessage;

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                List<string> messages;

                FormatScriptData(ref scriptInformation, out returnStatus, out returnErrorMessage);

                bool validPatient = ValidateScript(
                    scriptInformation,
                    out messages,
                    out returnStatus,
                    out returnErrorMessage);

                if (returnStatus == false)
                {
                    returnStatus = false;
                    messages.Add(returnErrorMessage);
                    returnMessages = messages;
                    return scriptInformation;
                }

                if (validPatient == false)
                {
                    returnStatus = false;                   
                    returnMessages = messages;
                    return scriptInformation;
                }

                string sqlString = "UPDATE Person SET ";
                sqlString = sqlString + " FirstName = @Colum1, ";
                sqlString = sqlString + " LastName = @Colum2, ";
                sqlString = sqlString + " Address = @Colum3, ";

                sqlString = sqlString + " Note = @Colum10, ";
                
                
                sqlString = sqlString + " Country_ID = @Colum5, ";
                sqlString = sqlString + " PostCode_ID = @Colum6, ";
                sqlString = sqlString + " Bank_ID = @Colum7, ";
                sqlString = sqlString + " Job_ID = @Colum9, ";
                   
                sqlString = sqlString + " Savings = @Colum8, ";

                sqlString = sqlString + " UpdateDate = @Colum4 ";
                sqlString = sqlString + " WHERE Person_ID = @PK_ID ";


                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter paramPatientID = new SQLiteParameter("@PK_ID", DbType.Int32);
                paramPatientID.Value = scriptInformation.Person_ID;
                sqlCommand.Parameters.Add(paramPatientID);

                SQLiteParameter param1 = new SQLiteParameter("@Colum1", DbType.String);
                param1.Value = scriptInformation.FirstName;
                sqlCommand.Parameters.Add(param1);





                SQLiteParameter param2 = new SQLiteParameter("@Colum2", DbType.String);
                param2.Value = scriptInformation.LastName;
                sqlCommand.Parameters.Add(param2);





                SQLiteParameter param3 = new SQLiteParameter("@Colum3", DbType.String);
                param3.Value = scriptInformation.Address;
                sqlCommand.Parameters.Add(param3);








                SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTime);
                //SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTimeOffset);    //optional for Offset Date format
                param4.Value = scriptInformation.UpdateDate;
                sqlCommand.Parameters.Add(param4);

                

                SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                param5.Value = scriptInformation.Country_ID;
                sqlCommand.Parameters.Add(param5);



                     

                SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                param6.Value = scriptInformation.PostCode_ID;
                sqlCommand.Parameters.Add(param6);



                

                SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.Int32);
                param7.Value = scriptInformation.Bank_ID;
                sqlCommand.Parameters.Add(param7);



                


                SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.Decimal);
                param8.Value = scriptInformation.Savings;
                sqlCommand.Parameters.Add(param8);


                

                SQLiteParameter param9 = new SQLiteParameter("@Colum9", DbType.Int32);
                param9.Value = scriptInformation.Job_ID;
                sqlCommand.Parameters.Add(param9);



                
                SQLiteParameter param10 = new SQLiteParameter("@Colum10", DbType.String);
                param10.Value = scriptInformation.Note;
                sqlCommand.Parameters.Add(param10);




                







                //next parameter is for Checkbox processing
                //SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                //param5.Value = scriptInformation.Private_Cover;
                //sqlCommand.Parameters.Add(param5);




                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.String);    //combo by TEXT only. 
                //param6.Value = scriptInformation.normcombocol1;   
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                //param6.Value = scriptInformation.normcombopkid;
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                //param7.Value = scriptInformation.Sex;
                //sqlCommand.Parameters.Add(param7);

                sqlCommand.ExecuteNonQuery();

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Person has been updated.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
               // }
               
            }

        }


        /// <summary>
        /// Delete Detail record
        /// </summary>
        public PersonKAL DelPersonKAL(PersonKAL scriptInformation,
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,
            out List<string> returnMessages)
        {

           string returnErrorMessage;

           //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                string sqlString = "DELETE FROM Person ";
                sqlString = sqlString + " WHERE Person_ID = @PK_ID ";

                //sqlBuilder.Append("DELETE Person ");
                //sqlBuilder.Append(" WHERE Person_ID = @PK_ID ");

                //string sqlString = sqlBuilder.ToString();

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;


                SQLiteParameter paramPatientID = new SQLiteParameter("@PK_ID", DbType.Int32);
                paramPatientID.Value = scriptInformation.Person_ID;
                sqlCommand.Parameters.Add(paramPatientID);

                sqlCommand.ExecuteNonQuery();



                //-------------------------------------------------------------------------------------------------------------
                //If you have to Delete child records as well, then do following. Do grand child records if needed.
                //Change the top SQL to Delete the child records first, and then the parent table records next
                //-------------------------------------------------------------------------------------------------------------

                //sqlCommand.Parameters.Clear();

                //sqlString = "";
                //sqlBuilder = new StringBuilder();

                //sqlBuilder.Append("DELETE FROM childtable ");      //do this up above first instead
                //sqlBuilder.Append(" WHERE Person_ID = @PK_ID2 ");

                //SQLiteParameter paramPatientID2 = new SQLiteParameter("@PK_ID2", DbType.Int32);
                //paramPatientID2.Value = scriptInformation.Person_ID;
                //sqlCommand.Parameters.Add(paramPatientID2);

                //sqlString = sqlBuilder.ToString();
                //sqlCommand.CommandText = sqlString;
                //sqlCommand.ExecuteNonQuery();

                //-------------------------------------------------------------------------------------------------------------
                //END If you have to Delete child records as well, then do following. Do grand child records if needed.
                //Change the top SQL to Delete the child records first, and then the parent table records next
                //-------------------------------------------------------------------------------------------------------------


                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Person has been deleted.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }



        /// <summary>
        /// Delete Detail records in a List
        /// </summary>
        public PersonKAL DelPersonKALALL(PersonKAL scriptInformation,
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,
            out List<string> returnMessages)
        {

            string returnErrorMessage;

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                string sqlString = "";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                //next loop goes around all checked rows and then delete each record
                string Chkstr;
                int counterk2 = 0;

                //foreach (var recList in scriptInformation.Chk)
                foreach (var recList in scriptInformation.PK_IDD)
                {
                    Chkstr = scriptInformation.CheckBoxx[counterk2];
                    //Chkstr = scriptInformation.Chk.ToString();
                    //Chkstr = recList.ToString();
                    if (Chkstr == "on")
                    {
                        
                        sqlString = sqlString + "DELETE FROM Person ";
                        sqlString = sqlString + " WHERE Person_ID = @PK_IDDD ";

                        SQLiteParameter param1 = new SQLiteParameter("@PK_IDDD", DbType.Int32);
                        param1.Value = scriptInformation.PK_IDD[counterk2];
                        sqlCommand.Parameters.Add(param1);


                        //sqlString = sqlBuilder.ToString();
                        sqlCommand.CommandText = sqlString;
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand.Parameters.Remove(param1);

                        sqlString = "";
                        //sqlBuilder = new StringBuilder();

                    }

                    counterk2 = counterk2 + 1;
                }


                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Person/s has been deleted.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }

      

        /// Uses XLS Export Query to get All pages at a time.
        public MemoryStream PersonKALSearchXLS(
            PersonKAL SearchValues,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentPageNumber = 1;
            int pageSize = -1;  //to indicate it is XLS export (ie export all records)

            try
            {
                int totalPages = 0;
                int totalRows = 0;
                int pageRows = 0;
                MemoryStream msout = new MemoryStream();

               List<PersonKAL> scripts = PersonKALSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    return msout;
                }

                var scriptDataTable = CreateDataTable(scripts);

                //totalRows = scriptDataTable.Rows.Count;
                UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();

                //DataTable listDataOut = new DataTable();
                //Write table out to XLS
                string[] ColOrderk = new string[5] { "Person_ID", "FirstName", "LastName", "Address", "UpdateDate" };   //must match column names
                string[] ColNamek = new string[5] { "Person_ID", "FirstName", "LastName", "Address", "UpdateDate" };
                //msout = UtilitiesBLL.TableToXLSms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/PersonKALList.xls");  //works OK
                msout = UtilitiesBLL.TableToXLSXms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/PersonKALList.xlsx");  //works OK


                //searchType = "";
                //searchTypeOut = searchType;
                returnErrorMessage = "";
                returnStatus = true;
                return msout;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
              
                MemoryStream mserr = new MemoryStream();
                //byte[] BLOBbyterr;
                //mserr.Write(BLOBbyterr, 0, BLOBbyterr.Length);
                return mserr;
            }

        }



        /// Uses XLSX Export Query to get All pages at a time.
        public MemoryStream PersonKALSearchXLSX(
            PersonKAL SearchValues,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentPageNumber = 1;
            int pageSize = -1;  //to indicate it is XLS export (ie export all records)

            try
            {
                int totalPages = 0;
                int totalRows = 0;
                int pageRows = 0;
                MemoryStream msout = new MemoryStream();
              
               List<PersonKAL> scripts = PersonKALSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    return msout;
                }

                var scriptDataTable = CreateDataTable(scripts);

                //totalRows = scriptDataTable.Rows.Count;
                UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();

                //DataTable listDataOut = new DataTable();
                //Write table out to XLS
                string[] ColOrderk = new string[5] { "Person_ID", "FirstName", "LastName", "Address", "UpdateDate" };   //must match column names
                string[] ColNamek = new string[5] { "Person_ID", "FirstName", "LastName", "Address", "UpdateDate" };
                //msout = UtilitiesBLL.TableToXLSms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/PersonKALList.xls");  //works OK
                msout = UtilitiesBLL.TableToXLSXms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/PersonKALList.xlsx");  //works OK


                //searchType = "";
                //searchTypeOut = searchType;
                returnErrorMessage = "";
                returnStatus = true;
                return msout;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
              
                MemoryStream mserr = new MemoryStream();
                //byte[] BLOBbyterr;
                //mserr.Write(BLOBbyterr, 0, BLOBbyterr.Length);
                return mserr;
            }

        }


        /// Uses PDF Report Query to get All pages at a time.
        public string PersonKALSearchPDF(
            PersonKAL SearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int totalRows,
            out int totalPages,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int loopcount = -1;
            int pageSizeReal = pageSize;

            try
            {
                totalPages = 0;
                totalRows = 0;
                int pageRows = 0;
                //pageSize = 10000; //make large, so as to get all records
                pageSize = -1; //make large, so as to get all records
                string strTable = "";
                string trbgcolor = "#D3DCE5";
                string ImagePathSrc = SearchValues.Logoimg;   //Logo to display 

               List<PersonKAL> scripts = PersonKALSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    //return GridList;
                }

              var scriptDataTable = CreateDataTable(scripts); 

                if (totalRows == 0)
                {
                    strTable = strTable + " <div align='center' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                    strTable = strTable + " No Data found.";
                    strTable = strTable + " </div> ";
                }


                strTable = strTable + "<table border='0' align='center' style='width: 590px;'>";
        
                /*
                //Setup Header ROW
                strTable = strTable + "<tr bgcolor='#DCEDEA' >";

                strTable = strTable + "<th width='12%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Person_ID";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='22%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " FirstName";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='22%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " LastName";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='21%' align='center'> ";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Address";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='23%' align='center'> ";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " UpdateDate";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";
 
                strTable = strTable + "</tr>";
                //END of Header ROW
                */

                for (int i = 0; i < scriptDataTable.Rows.Count; i++)
                {
                    //currentRow++;

                    if (i % 2 == 0)
                    {
                        trbgcolor = "#D3DCE5";
                    }
                    else
                    {
                        trbgcolor = "#ebeff2";
                    }


                        PersonKAL recList = new PersonKAL();

                        recList.Person_ID = scriptDataTable.Rows[i]["Person_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Person_ID"]) : 0;

                        recList.FirstName = scriptDataTable.Rows[i]["FirstName"] != DBNull.Value ? scriptDataTable.Rows[i]["FirstName"].ToString() : "";
                     



                        recList.LastName = scriptDataTable.Rows[i]["LastName"] != DBNull.Value ? scriptDataTable.Rows[i]["LastName"].ToString() : "";
                    



                        recList.Address = scriptDataTable.Rows[i]["Address"] != DBNull.Value ? scriptDataTable.Rows[i]["Address"].ToString() : "";
                     



                     

                        if (scriptDataTable.Rows[i]["UpdateDate"] == DBNull.Value)
                        {
                            recList.UpdateDate = DateTime.MinValue;
                        }
                        else
                        {
                            recList.UpdateDate = Convert.ToDateTime(scriptDataTable.Rows[i]["UpdateDate"]);
                            //recList.UpdateDate = DateTimeOffset.Parse(scriptDataTable.Rows[i]["UpdateDate"].ToString());      //option for Date in Offset format
                        }

                    loopcount = loopcount + 1;
                    if (loopcount == pageSizeReal)    //write out a Page of Data
                    {

                        /*
                        strTable = strTable + "</table>";

                        strTable = strTable + "<div style='page-break-after: always;'/> </div>";

                        strTable = strTable + "<table border='0' style='width: 100%;'>";
                        //Setup Header ROW
                        strTable = strTable + "<tr bgcolor='#DCEDEA' >";

                        strTable = strTable + "<td width='12%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Person_ID";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='22%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " FirstName";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='22%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " LastName";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='21%' align='center'> ";
                        strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Address";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='23%' align='center'> ";
                        strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " UpdateDate";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        //END of Header ROW
                        strTable = strTable + "</tr>";
                        strTable = strTable + "</table>";

                        strTable = strTable + "<table border='0' style='width: 100%;'>";
                        */

                        loopcount = 0;  //reset count again
                    }


                        strTable = strTable + "<tr bgcolor='" + trbgcolor + "' >";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 82px;'> ";
                        strTable = strTable + recList.Person_ID;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 154px;'> ";
                        strTable = strTable + recList.FirstName;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 154px;'> ";
                        strTable = strTable + recList.LastName;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='center'> ";
                        //strTable = strTable + " <div align='center' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='center' style='font-size: 8px; width: 100px;'> ";
                        strTable = strTable + recList.Address;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='center'> ";
                        //strTable = strTable + " <div align='center' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='center' style='font-size: 8px; width: 100px;'> ";
                        strTable = strTable + UtilitiesBLL.FormatDate(recList.UpdateDate);
                        //strTable = strTable + UtilitiesBLL.FormatDateOffsetTime(recList.UpdateDate);     //optional for Offset Date
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        //END of data ROW
                        strTable = strTable + "</tr>";


                }
            
                strTable = strTable + "</table>";

                /*
                //------------------------------------------------------------------------------------------------------
                //Next is just a TEST, for showing formatting options. Borders, font-weight, font-family do not work for CSS on DIV in iText 7.
                //------------------------------------------------------------------------------------------------------
                strTable = strTable + "<div style='page-break-after: always;'/> </div>";

                strTable = strTable + "<table border='0' cellpadding='3' cellspacing='3' >";
                strTable = strTable + "<tr border='1' bgcolor='#777777' color='#ffffff'>";

                strTable = strTable + "<td colspan='1'>";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-size: 16px; color: #000000; border: 2px solid #000000;'> ";
                strTable = strTable + " Environmental Management Charge";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "</tr>";

                strTable = strTable + "<tr>";

                strTable = strTable + "<td colspan='1'>";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                strTable = strTable + " Environmental Management Charge22";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "</tr>";

                strTable = strTable + "</table>";
                //------------------------------------------------------------------------------------------------------
                //END TEST 
                //------------------------------------------------------------------------------------------------------
                */


                returnErrorMessage = "";
                returnStatus = true;
              
                return strTable;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
                totalPages = 0;
                totalRows = 0;

                string errstr = "";
                errstr = errstr + " <div align='center' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                errstr = errstr + " Error Found: " + returnErrorMessage;
                errstr = errstr + " </div> ";

                return errstr;

            }

        }



        private bool IsNumeric(object value)
        {
            bool Result = false;

            try
            {
                int i = Convert.ToInt32(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }


        private bool IsDouble(object value)
        {
            bool Result = false;

            try
            {
                double i = Convert.ToDouble(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }


        private bool IsDecimal(object value)
        {
            bool Result = false;

            try
            {
                decimal i = Convert.ToDecimal(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }



        public DataSet CreateDataSet<T>(List<T> list)
        {
            //list is nothing or has nothing, return nothing (or add exception handling)
            if (list == null || list.Count == 0) { return null; }

            //get the type of the first obj in the list
            var obj = list[0].GetType();

            //now grab all properties
            var properties = obj.GetProperties();

            //make sure the obj has properties, return nothing (or add exception handling)
            if (properties.Length == 0) { return null; }

            //it does so create the dataset and table
            var dataSet = new DataSet();
            var dataTable = new DataTable();

            //now build the columns from the properties
            var columns = new DataColumn[properties.Length];
            for (int i = 0; i < properties.Length; i++)
            {
                columns[i] = new DataColumn(properties[i].Name, properties[i].PropertyType);
            }

            //add columns to table
            dataTable.Columns.AddRange(columns);

            //now add the list values to the table
            foreach (var item in list)
            {
                //create a new row from table
                var dataRow = dataTable.NewRow();

                //now we have to iterate thru each property of the item and retrieve it's value for the corresponding row's cell
                var itemProperties = item.GetType().GetProperties();

                for (int i = 0; i < itemProperties.Length; i++)
                {
                    dataRow[i] = itemProperties[i].GetValue(item, null);
                }

                //now add the populated row to the table
                dataTable.Rows.Add(dataRow);
            }

            //add table to dataset
            dataSet.Tables.Add(dataTable);

            return dataSet;
        }

        public DataTable CreateDataTable<T>(List<T> list)
        {
            //list is nothing or has nothing, return nothing (or add exception handling)
            if (list == null || list.Count == 0) { return null; }

            //get the type of the first obj in the list
            var obj = list[0].GetType();

            //now grab all properties
            var properties = obj.GetProperties();

            //make sure the obj has properties, return nothing (or add exception handling)
            if (properties.Length == 0) { return null; }

            //it does so create the dataset and table
            var dataSet = new DataSet();
            var dataTable = new DataTable();

            //now build the columns from the properties
            var columns = new DataColumn[properties.Length];
            for (int i = 0; i < properties.Length; i++)
            {
                columns[i] = new DataColumn(properties[i].Name, properties[i].PropertyType);
            }

            //add columns to table
            dataTable.Columns.AddRange(columns);

            //now add the list values to the table
            foreach (var item in list)
            {
                //create a new row from table
                var dataRow = dataTable.NewRow();

                //now we have to iterate thru each property of the item and retrieve it's value for the corresponding row's cell
                var itemProperties = item.GetType().GetProperties();

                for (int i = 0; i < itemProperties.Length; i++)
                {
                    dataRow[i] = itemProperties[i].GetValue(item, null);
                }

                //now add the populated row to the table
                dataTable.Rows.Add(dataRow);
            }

            //add table to dataset
            //dataSet.Tables.Add(dataTable);

            //return dataset
            return dataTable;
        }






    }

}
