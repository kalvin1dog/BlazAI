using BlazLite1.Server.PersonKALUI;
using BlazLite1.Shared.PersonKALUI;
using BlazLite1.Server.Models.PersonKALUI;
using Microsoft.AspNetCore.Mvc;


namespace BlazLite1.Server.Controllers.PersonKALUI
{
 
    [ApiController]
    public class PersonKALCountry_IDautoController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PersonKALCountry_IDautoController> logger;

        public PersonKALCountry_IDautoController(ILogger<PersonKALCountry_IDautoController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PersonKALCountry_IDauto/GetAsyncListAuto")]
        public async Task<IEnumerable<PersonKALCountry_IDauto>> GetAsyncListAuto(string Id)
        {
            string testget = Id;
           
            List<PersonKALCountry_IDauto> ColJobs = new List<PersonKALCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKALCountry_IDautoBLL ThisBLL = new PersonKALCountry_IDautoBLL();

            PersonKALCountry_IDautoViewModel ThisViewModel = new PersonKALCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKALCountryListAuto(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }

          
        [HttpGet]
        [Route("api/PersonKALCountry_IDauto/GetAsyncListGet")]
        public async Task<IEnumerable<PersonKALCountry_IDauto>> GetAsyncListGet(string Id)
        {
            string testget = Id;
           
            List<PersonKALCountry_IDauto> ColJobs = new List<PersonKALCountry_IDauto>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKALCountry_IDautoBLL ThisBLL = new PersonKALCountry_IDautoBLL();

            PersonKALCountry_IDautoViewModel ThisViewModel = new PersonKALCountry_IDautoViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.GlobalSearchString = Id;

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKALCountryListGet(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
