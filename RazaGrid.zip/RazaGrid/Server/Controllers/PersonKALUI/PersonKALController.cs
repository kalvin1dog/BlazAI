using BlazLite1.Shared;
using BlazLite1.Server.PersonKALUI;
using BlazLite1.Shared.PersonKALUI;
using BlazLite1.Server.Models.PersonKALUI;

using Microsoft.AspNetCore.Mvc;

using iText.Html2pdf;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Xobject;
using iText.Kernel.Events;
using iText.Kernel.Geom;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Font;
using iText.Kernel.Font;
using iText.IO.Font.Constants;
using iText.IO;
using iText.Kernel.Utils;


namespace BlazLite1.Server.Controllers.PersonKALUI
{

    //[Authorize(Roles = "Admin")]
    //[Authorize(Users = "kalvin,umesh")]
    //[Authorize]
    [ApiController]
    public class PersonKALController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PersonKALController> logger;

        public PersonKALController(ILogger<PersonKALController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

       
        [HttpGet]
        [Route("api/PersonKAL/GetAsync")]
        public async Task<IEnumerable<PersonKAL>> GetAsync(string Id, int CurrPage, int Pagesize, string SortedBy, 
            string SortType, string FirstName, string LastName, string Address, string UpdateDate)
        {

            List<PersonKAL> ColPersonKALs = new List<PersonKAL>();

            int totalRows;
            int totalPages;
            int pageRows;
            bool returnStatus;
            string returnErrorMessage;

            PersonKALBLL ThisBLL = new PersonKALBLL();
            PersonKALViewModel ThisViewModel = new PersonKALViewModel();
        
            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

            ThisViewModel.PageSize = Pagesize;
            ThisViewModel.CurrentPageNumber = CurrPage;
            ThisViewModel.SortBy = SortedBy;
            ThisViewModel.SortAscendingDescending = SortType;

            ThisViewModel.FirstName_Str = FirstName;
            ThisViewModel.LastName_Str = LastName;
            ThisViewModel.Address_Str = Address;
            ThisViewModel.UpdateDate_Str = UpdateDate;

            ColPersonKALs = ThisBLL.PersonKALSearch(
                ThisViewModel,
                ThisViewModel.CurrentPageNumber,
                ThisViewModel.PageSize,
                ThisViewModel.SortBy,
                ThisViewModel.SortAscendingDescending,
                ThisViewModel.DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);


            return ColPersonKALs;
        
        }



        [HttpPost]
        [Route("api/PersonKAL/Post")]
        public void Post([FromBody] PersonKALUPD paramPersonKALs)
        {
            int returnPageNumber;
            int returnRowNumber;
            bool returnStatus;
            string returnErrorMessage;

            List<string> returnMessage;

            try
            {

             PersonKALBLL ThisBLL = new PersonKALBLL();
             PersonKALViewModel ThisViewModel = new PersonKALViewModel();

             //await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

             ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

             ThisViewModel.FirstName = paramPersonKALs.FirstName;
             ThisViewModel.LastName = paramPersonKALs.LastName;
             ThisViewModel.Address = paramPersonKALs.Address;
             ThisViewModel.UpdateDate = paramPersonKALs.UpdateDate; 
             
             ThisViewModel.Note = paramPersonKALs.Note;
              
                 
             ThisViewModel.Country_ID = paramPersonKALs.Country_ID;
             ThisViewModel.PostCode_ID = paramPersonKALs.PostCode_ID;
             ThisViewModel.Bank_ID = paramPersonKALs.Bank_ID;
             ThisViewModel.Job_ID = paramPersonKALs.Job_ID;
                  
             ThisViewModel.Savings = paramPersonKALs.Savings; 
         
             PersonKAL script = ThisBLL.AddPersonKAL(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnPageNumber,
                out returnRowNumber,
                out returnMessage,
                out returnStatus,
                out returnErrorMessage);

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;

            }

        }

    

        [HttpPut]
        [Route("api/PersonKAL/Put")]
        public void Put([FromBody] PersonKALUPD paramPersonKALs)
        {
            int returnPageNumber;
            int returnRowNumber;

            bool returnStatus;
            string returnErrorMessage;

            List<string> returnMessage;

            try
            {
             PersonKALBLL ThisBLL = new PersonKALBLL();
             PersonKALViewModel ThisViewModel = new PersonKALViewModel();

             //await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

             ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

             ThisViewModel.Person_ID = paramPersonKALs.Person_ID;
             ThisViewModel.FirstName = paramPersonKALs.FirstName;
             ThisViewModel.LastName = paramPersonKALs.LastName;
             ThisViewModel.Address = paramPersonKALs.Address;
             ThisViewModel.UpdateDate = paramPersonKALs.UpdateDate; 
              
             ThisViewModel.Note = paramPersonKALs.Note;
            
                 
             ThisViewModel.Country_ID = paramPersonKALs.Country_ID;
             ThisViewModel.PostCode_ID = paramPersonKALs.PostCode_ID;
             ThisViewModel.Bank_ID = paramPersonKALs.Bank_ID;
             ThisViewModel.Job_ID = paramPersonKALs.Job_ID;
                  
             ThisViewModel.Savings = paramPersonKALs.Savings; 
         

             PersonKAL script = ThisBLL.UpdatePersonKAL(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnPageNumber,
                out returnRowNumber,
                out returnStatus,
                out returnMessage);

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
 
            }

        }


              
        [HttpPut]
        [Route("api/PersonKAL/DeleteIT")]
        public void DeleteIT([FromBody] int paramPersonKALs)
        {
            int returnPageNumber;
            int returnRowNumber;

            bool returnStatus;
            string returnErrorMessage;

            List<string> returnMessage;

            PersonKALBLL ThisBLL = new PersonKALBLL();
            PersonKALViewModel ThisViewModel = new PersonKALViewModel();

            //await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
            ThisViewModel.Person_ID = paramPersonKALs;

            PersonKAL script = ThisBLL.DelPersonKAL(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnPageNumber,
                out returnRowNumber,
                out returnStatus,
                out returnMessage);

        }





        [HttpGet]
        [Route("api/PersonKAL/GetAsyncXLSX")]
        public async Task<Byte[]> GetAsyncXLSX(string Id, int CurrPage, int Pagesize, string SortedBy,
           string SortType, string FirstName, string LastName, string Address, string UpdateDate)
        {

            bool returnStatus;
            string returnErrorMessage;
    
            PersonKALBLL ThisBLL = new PersonKALBLL();
            PersonKALViewModel ThisViewModel = new PersonKALViewModel();

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

            ThisViewModel.PageSize = Pagesize;
            ThisViewModel.CurrentPageNumber = CurrPage;
            ThisViewModel.SortBy = SortedBy;
            ThisViewModel.SortAscendingDescending = SortType;
            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

            ThisViewModel.FirstName_Str = FirstName;
            ThisViewModel.LastName_Str = LastName;
            ThisViewModel.Address_Str = Address;
            ThisViewModel.UpdateDate_Str = UpdateDate;

            MemoryStream permitBLOB = ThisBLL.PersonKALSearchXLSX(
              ThisViewModel,
              ThisViewModel.SortBy,
              ThisViewModel.SortAscendingDescending,
              ThisViewModel.DBConnectString,
              out returnStatus,
              out returnErrorMessage);
           
            return permitBLOB.ToArray();
           
        }


        [HttpGet]
        [Route("api/PersonKAL/GetAsyncPDF")]
        public async Task<Byte[]> GetAsyncPDF(string Id, int CurrPage, int Pagesize, string SortedBy,
           string SortType, string FirstName, string LastName, string Address, string UpdateDate)
        {
            int totalRows;
            int totalPages;
            bool returnStatus;
            string returnErrorMessage;

            List<DownLoad> ColDownLoads = new List<DownLoad>();

            PersonKALBLL ThisBLL = new PersonKALBLL();
            PersonKALViewModel ThisViewModel = new PersonKALViewModel();

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input

            ThisViewModel.PageSize = Pagesize;
            ThisViewModel.CurrentPageNumber = CurrPage;
            ThisViewModel.SortBy = SortedBy;
            ThisViewModel.SortAscendingDescending = SortType;
            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

            ThisViewModel.FirstName_Str = FirstName;
            ThisViewModel.LastName_Str = LastName;
            ThisViewModel.Address_Str = Address;
            ThisViewModel.UpdateDate_Str = UpdateDate;
            
            string scripts = ThisBLL.PersonKALSearchPDF(
                ThisViewModel,
                ThisViewModel.CurrentPageNumber,
                ThisViewModel.PageSize,
                ThisViewModel.SortBy,
                ThisViewModel.SortAscendingDescending,
                ThisViewModel.DBConnectString,
                out totalRows,
                out totalPages,
                out returnStatus,
                out returnErrorMessage);


            iText.Html2pdf.ConverterProperties propk = new iText.Html2pdf.ConverterProperties();
          
            //string pthgetk = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/";
            string pthgetk = Request.Scheme + "://" + Request.Host + Request.PathBase + "/";

            propk.SetBaseUri(pthgetk);

            //PdfFont fontt = PdfFontFactory.CreateFont(StandardFontFamilies.COURIER);
           
            FontProvider fontProvider = new FontProvider();
            //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
            iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA);

            fontProvider.AddFont(fontprog);
            propk.SetFontProvider(fontProvider);

            string ws_html_front = "";
            ws_html_front = ws_html_front + "<HTML>";

            //add css for page margins
            ws_html_front = ws_html_front + "<style>";

            ws_html_front = ws_html_front + " @page { ";
            ws_html_front = ws_html_front + " margin-top: 47px;margin-bottom: 80px; ";
            //ws_html_front = ws_html_front + " @bottom-right {content: 'Page '; } ";   //works OK
            //ws_html_front = ws_html_front + " @top-right {content: 'Page ' counter(pages); } ";  //error with counter
            // ws_html_front = ws_html_front + "  @bottom-left {content: 'Page ' counter(page) ' of ' counter(pages); } ";
            ws_html_front = ws_html_front + " } ";
            ws_html_front = ws_html_front + "</style>";

            string ws_html_end = "";

            //Next Line is a TEST only
            ws_html_end = ws_html_end + "<br /><span>test span</span><img src='images/favicon2.png'/><span>test span2</span><br />";

            ws_html_end = ws_html_end + "</HTML>";

            String htmlContent = ws_html_front + scripts + ws_html_end;

            //var pdfContentType = "application/pdf";

            string htmlToConvert = htmlContent;

            string pthget = _Env.WebRootPath;
            var filenameit = "pdf_" + DateTime.Now.ToString("yyyyMMddHHmm");

            CreatePdf(pthget + "/" + filenameit + ".pdf", htmlToConvert, pthgetk);
            //CreatePdf(pthget + "/" + "Kal1Dog.pdf", htmlToConvert, pthgetk);

            DownLoad recList = new DownLoad();

            recList.FileName = filenameit;
            recList.FolderDir = pthget;
            ColDownLoads.Add(recList);

            //Convert to Byte[] now instead
            string pathin = pthget + "/" + filenameit + ".pdf";
            //string pathin = pthget + "/" + "Kal1Dog.pdf";

            byte[] ak = System.IO.File.ReadAllBytes(pathin);

            return ak;

        }


        private void CreatePdf(string dest, string html, string pthgetk)
        {
            //Initialize PDF document
            PdfDocument pdf = new PdfDocument(new PdfWriter(dest));

            //pdf.SetDefaultPageSize(PageSize.A4);  //works
            //pdf.SetDefaultPageSize(PageSize.A3);  

            string header = "Page Header";
            header = pthgetk;  //BaseUri  now

            string LocalPath = GetPathK();  //local Path
            //string LocalPath = _Env.WebRootPath;

            Header headerHandler = new Header(header);
            PageXofY footerHandler = new PageXofY(pdf, LocalPath);
            //Assign event-handlers
            pdf.AddEventHandler(PdfDocumentEvent.START_PAGE, headerHandler);
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, footerHandler);

            ConverterProperties converterProperties = new ConverterProperties().SetBaseUri(pthgetk);

            FontProvider fontProvider = new FontProvider();
            //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
            iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA);
            //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(FontConstants.);
            //PdfFont fontk = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA);
            //iText.IO.Font.FontProgram fontprog = iText.IO.Font.Constants.StandardFonts.HELVETICA;

            //fontProvider.AddFont(fontk);
            fontProvider.AddFont(fontprog);
            converterProperties.SetFontProvider(fontProvider);


            HtmlConverter.ConvertToDocument(html, pdf, converterProperties);
            //Write the total number of pages to the placeholder
            footerHandler.writeTotal(pdf);
            pdf.Close();


            /*
            //TEST code next
            iText.IO.Font.FontProgram fontprog2 = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.TIMES_BOLD);
            iText.IO.Font.FontProgram fontprog22 = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
            iText.IO.Font.FontProgram fontprog24 = iText.IO.Font.FontProgramFactory.CreateFont(LocalPath + "/Lato-Light.ttf");

            PdfFont fontt2 = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_OBLIQUE);
            PdfFont fontt3 = PdfFontFactory.CreateFont(LocalPath + "/Lato-Light.ttf", "CP1251", true);
            Text author = new Text("Test Text").SetFont(fontt3).SetFontSize(16);

            Paragraph p = new Paragraph("Hello World! ")
            .Add(new Text("Hallo Wereld! ").SetFontSize(14))
            .Add(new Text("Bonjour le monde! ").SetFontSize(10));

            //END Test code
            */

        }

        private string GetPathK()
        {
            //string pathget = Server.MapPath("~");
            string pathget = _Env.WebRootPath;
            //string pathget = "C:/MYTOOL";
            return pathget;
        }
       

        //Header event handler
        public class Header : IEventHandler
        {
            string header;
            public Header(string header)
            {
                this.header = header;
            }
            public void HandleEvent(Event e)
            {
                //Retrieve document
                PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
                PdfDocument pdf = docEvent.GetDocument();
                PdfPage page = docEvent.GetPage();
                Rectangle pageSize = page.GetPageSize();
                PdfCanvas pdfCanvas = new PdfCanvas(
                        page.GetLastContentStream(), page.GetResources(), pdf);
                Canvas canvas = new Canvas(pdfCanvas, pdf, pageSize);
                canvas.SetFontSize(18f);

                PdfFont fontt = PdfFontFactory.CreateFont(StandardFontFamilies.COURIER);
                //canvas.SetFont(fontt);

                //Write text at position
                Paragraph p = new Paragraph().SetFont(fontt);
              

                Table tablek = new Table(3);  //TEST
                //table.SetWidths(widths);
                //tablek.SetWidth(595);
                tablek.SetWidth(UnitValue.CreatePercentValue(100));
                tablek.AddHeaderCell("A");
                tablek.AddHeaderCell("B");
                tablek.AddHeaderCell("C");


                string strTable = "";
                strTable = strTable + "<table border='0' style='width: 590px;'>";

                strTable = strTable + "<tr bgcolor='white' >";
                strTable = strTable + "<td width='295px' align='center' colspan='2'> ";
                strTable = strTable + " <div align='left' style='font-size: 12px; color: #000000;'> ";
                strTable = strTable + "<img src='images/favicon2.png' style='height:20px;' />";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";
                strTable = strTable + "<td width='295px' align='center' colspan='3'> ";
                strTable = strTable + " <div align='center' style='font-size: 12px; color: #000000;'> ";
                strTable = strTable + "Page Header";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";
                strTable = strTable + "</tr>";

                //Setup Header ROW
                strTable = strTable + "<tr bgcolor='#DCEDEA' >";

                strTable = strTable + "<td align='left'> ";
                strTable = strTable + " <div align='left' style='font-size: 8px; color: #000000; width: 82px;'> ";
                strTable = strTable + "PK_ID";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "<td align='left'> ";
                strTable = strTable + " <div align='left' style='font-size: 8px; color: #000000; width: 154px;'> ";
                strTable = strTable + "Column1";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "<td align='left'> ";
                strTable = strTable + " <div align='left' style='font-size: 8px; color: #000000; width: 154px;'> ";
                strTable = strTable + "Column2";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "<td align='center'> ";
                strTable = strTable + " <div align='center' style='font-size: 8px; color: #000000; width: 100px;'> ";
                strTable = strTable + "Column3";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "<td align='center'> ";
                strTable = strTable + " <div align='center' style='font-size: 8px; color: #000000; width: 100px;'> ";
                strTable = strTable + "Column4";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                //END of Header ROW

                strTable = strTable + "</tr>";
                strTable = strTable + "</table>";

                iText.Html2pdf.ConverterProperties propk = new iText.Html2pdf.ConverterProperties();
                FontProvider fontProvider = new FontProvider();
                //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
                iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                fontProvider.AddFont(fontprog);
                propk.SetFontProvider(fontProvider);
                propk.SetBaseUri(header);
             
                var elements = HtmlConverter.ConvertToElements(strTable, propk);
                foreach (IElement ek2 in elements)
                    p.Add((IBlockElement)ek2);

                PdfFont fontt2 = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                Text author = new Text("Robert Louis Stevenson").SetFont(fontt2);
                //p.Add("By ").Add(author);

                //p.Add(tablek);
                //var pagew = pageSize.GetWidth();

                canvas.ShowTextAligned(p,
                        pageSize.GetWidth() / 2,
                        pageSize.GetTop() - 40, TextAlignment.CENTER);

                //next is original code
                //canvas.ShowTextAligned(header,
                // pageSize.GetWidth() / 2,
                //pageSize.GetTop() - 30, TextAlignment.CENTER);

            }
        }

        //Footer handler
        public class PageXofY : IEventHandler
        {
            public PdfFormXObject placeholder;
            public float side = 20;
            public float x = 300;
            public float y = 25;
            public float space = 4.5f;
            public float descent = 3;
            public string pathLocal;
            public PageXofY(PdfDocument pdf, string Localpathk)
            {
                placeholder =
                        new PdfFormXObject(new Rectangle(0, 0, side, side));

                pathLocal = Localpathk;

            }
            public void HandleEvent(Event e)
            {
                PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
                PdfDocument pdf = docEvent.GetDocument();
                PdfPage page = docEvent.GetPage();
                int pageNumber = pdf.GetPageNumber(page);
                string pageStr = pageNumber.ToString();
                Rectangle pageSize = page.GetPageSize();
                PdfCanvas pdfCanvas = new PdfCanvas(
                        page.GetLastContentStream(), page.GetResources(), pdf);
                Canvas canvas = new Canvas(pdfCanvas, pdf, pageSize);

                //try to css the footer, with a html table
                string strTable = "";
                //strTable = "";
                strTable = strTable + " <div align='right' style='font-size: 12px; color: navy;width: 120px;'> ";
                strTable = strTable + "Page " + pageStr + " of";
                strTable = strTable + " </div> ";

                iText.Html2pdf.ConverterProperties propk = new iText.Html2pdf.ConverterProperties();
                FontProvider fontProvider = new FontProvider();
                //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
                iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                iText.IO.Font.FontProgram fontprog2 = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                //iText.IO.Font.FontProgram fontprog2 = iText.IO.Font.FontProgramFactory.CreateFont(pathLocal + "/Lato-Light.ttf");

                fontProvider.AddFont(fontprog2);
                propk.SetFontProvider(fontProvider);
                var elements = HtmlConverter.ConvertToElements(strTable, propk);
                Paragraph p2 = new Paragraph();
                foreach (IElement ek2 in elements)
                    p2.Add((IBlockElement)ek2);

                PdfFont fontt = PdfFontFactory.CreateFont(StandardFontFamilies.COURIER);
                //PdfFont fontt = PdfFontFactory.CreateFont(pathLocal + "/Lato-Light.ttf", "CP1251", true);  //works

                Text author = new Text("Page ").SetFont(fontt);
                //p2.Add("Page  ").Add(author).Add(pageNumber.ToString()).Add(" of");  //Works OK


                Paragraph p = new Paragraph()
                        .Add("Page ").Add(pageNumber.ToString()).Add(" of");

                //canvas.ShowTextAligned(p2, x, y, TextAlignment.CENTER);
                canvas.ShowTextAligned(p2, x, y, TextAlignment.RIGHT);

                pdfCanvas.AddXObject(placeholder, x + space, y - descent);
                pdfCanvas.Release();
            }
            public void writeTotal(PdfDocument pdf)
            {
                string pageTotal = pdf.GetNumberOfPages().ToString();
                string strTable = "";
                strTable = strTable + " <div align='left' style='font-size: 12px; color: navy;width: 40px;'> ";
                strTable = strTable + "" + pageTotal + "";
                strTable = strTable + " </div> ";
                iText.Html2pdf.ConverterProperties propk = new iText.Html2pdf.ConverterProperties();
                FontProvider fontProvider = new FontProvider();
                //iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFontFamilies.COURIER);
                iText.IO.Font.FontProgram fontprog = iText.IO.Font.FontProgramFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                fontProvider.AddFont(fontprog);
                propk.SetFontProvider(fontProvider);
                var elements = HtmlConverter.ConvertToElements(strTable, propk);
                Paragraph p2 = new Paragraph();
                foreach (IElement ek2 in elements)
                    p2.Add((IBlockElement)ek2);


                Canvas canvas = new Canvas(placeholder, pdf);
                canvas.ShowTextAligned(p2,
                      0, descent, TextAlignment.LEFT);

                //canvas.ShowTextAligned(pdf.GetNumberOfPages().ToString(),
                // 0, descent, TextAlignment.LEFT);
            }
        }





    }
}
