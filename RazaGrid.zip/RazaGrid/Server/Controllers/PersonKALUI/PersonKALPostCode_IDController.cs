using BlazLite1.Server.PersonKALUI;
using BlazLite1.Shared.PersonKALUI;
using BlazLite1.Server.Models.PersonKALUI;
using Microsoft.AspNetCore.Mvc;


namespace BlazLite1.Server.Controllers.PersonKALUI
{
 
    [ApiController]
    public class PersonKALPostCode_IDController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<PersonKALPostCode_IDController> logger;

        public PersonKALPostCode_IDController(ILogger<PersonKALPostCode_IDController> logger, IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            this.logger = logger;
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }

        
        [HttpGet]
        [Route("api/PersonKALPostCode_ID/GetAsyncList")]
        public async Task<IEnumerable<PersonKALPostCode_ID>> GetAsyncList(string Id)
        {
            string testget = Id;
           
            List<PersonKALPostCode_ID> ColJobs = new List<PersonKALPostCode_ID>();

            bool returnStatus;
            string returnErrorMessage;

            PersonKALPostCode_IDBLL ThisBLL = new PersonKALPostCode_IDBLL();

            PersonKALPostCode_IDViewModel ThisViewModel = new PersonKALPostCode_IDViewModel();  

            await this.TryUpdateModelAsync(ThisViewModel);    //get search criteria form input NOT Really doing anything!!

            ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
           
            ColJobs = ThisBLL.GetPersonKALPostCodeList(
                ThisViewModel,
                ThisViewModel.DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }




    }
}
