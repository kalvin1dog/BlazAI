﻿using BlazLite1.Shared;
using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using MimeKit;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.Extensions.Configuration;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Data;
using BlazLite1.Server.Models;
using System.Data.SQLite;

namespace BlazLite1.Server.Controllers
{

    //[Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private IWebHostEnvironment _Env;   //for 3.1 above

        IConfiguration _iconfiguration;  //new


        public AccountsController(UserManager<ApplicationUser> userManager, IWebHostEnvironment envrtmnt, IConfiguration iconfiguration)
        {
            _userManager = userManager;
            _Env = envrtmnt;
            _iconfiguration = iconfiguration;

        }


        [HttpPost]
        [Route("api/Register/Post")]
        public async Task<IActionResult> Post([FromBody] RegisterModel model)
        {
            var newUser = new ApplicationUser { UserName = model.Email, Email = model.Email };

            var result = await _userManager.CreateAsync(newUser, model.Password);

            if (!result.Succeeded)
            {

                var errors = result.Errors.Select(x => x.Description);

                return Ok(new RegisterResult { Successful = false, Errors = errors });

            }
            else
            {
                //Confirm User Registration.
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(newUser);
                var result2 = await _userManager.ConfirmEmailAsync(newUser, token);

            }

            return Ok(new RegisterResult { Successful = true });
        }
        


        [HttpPost]
        [Route("api/Remove/Post")]
        public async Task<IActionResult> PostRemove([FromBody] ForgotPasswordModel model)
        {
            var userk = await _userManager.FindByNameAsync(model.Email);

            var result = await _userManager.DeleteAsync(userk);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(x => x.Description);

                return Ok(new ForgotPasswordResult { Successful = false, Errors = errors });

            }

            return Ok(new ForgotPasswordResult { Successful = true });
        }



        [HttpPost]
        [Route("api/Reset/Post")]
        public async Task<IActionResult> PostReset([FromBody] ResetPasswordModel model)
        {
            var userk = await _userManager.FindByNameAsync(model.Email);

            _userManager.Options.User.RequireUniqueEmail = false;

            var code = await _userManager.GeneratePasswordResetTokenAsync(userk);
          
            var result = await _userManager.ResetPasswordAsync(userk, code, model.Password);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(x => x.Description);

                return Ok(new ResetPasswordResult { Successful = false, Errors = errors });

            }

            return Ok(new ResetPasswordResult { Successful = true });

        }



        [HttpPost]
        [Route("api/ResetForgot/Post")]
        public async Task<IActionResult> PostResetForgot([FromBody] ResetPasswordModel model)
        {
            var userk = await _userManager.FindByNameAsync(model.Email);

            _userManager.Options.User.RequireUniqueEmail = false;

            var TokenCode = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(model.Token));

            var result = await _userManager.ResetPasswordAsync(userk, TokenCode, model.Password);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(x => x.Description);

                return Ok(new ResetPasswordResult { Successful = false, Errors = errors });

            }


            return Ok(new ResetPasswordResult { Successful = true });

        }



        [HttpPost]
        [Route("api/Forgot/Post")]
        public async Task<IActionResult> PostForgot([FromBody] ForgotPasswordModel model)
        {

            try
            {
                var userk = await _userManager.FindByNameAsync(model.Email);

                var code = await _userManager.GeneratePasswordResetTokenAsync(userk);
                code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));

                string pthgetkk = Request.Scheme + "://" + Request.Host + Request.PathBase + "/";

                string callbackUrl = pthgetkk + "ResetPassword";

                callbackUrl = callbackUrl + "token=" + code + "&user=" + model.Email;

                MimeMessage message = new MimeMessage();
                MailboxAddress from = new MailboxAddress("ResetPassword", "kalvinlernst@gmail.com");   //email to use for sending (must have SMTP credentials)
                message.From.Add(from);

                //MailboxAddress to = new MailboxAddress("KalvinZingit", "kalvin@zingit.com.au");  //use email in form
                MailboxAddress to = new MailboxAddress("Reset", model.Email);

                message.To.Add(to);

                message.Subject = "This is email subject";

                BodyBuilder bodyBuilder = new BodyBuilder();
                //bodyBuilder.HtmlBody = "<h1>Hello World!</h1>";
                bodyBuilder.HtmlBody = $"Please reset your password by <a href='{HtmlEncoder.Default.Encode(callbackUrl)}'>clicking here</a>.";
                //bodyBuilder.TextBody = $"Please reset your password by <a href='{HtmlEncoder.Default.Encode(callbackUrl)}'>clicking here</a>.";

                //bodyBuilder.Attachments.Add(_Env.WebRootPath + "\\file.png");

                message.Body = bodyBuilder.ToMessageBody();

                //Sending email Credentials
                SmtpClient client = new SmtpClient();
                client.Connect("smtp.gmail.com", 465, true);
                client.Authenticate("kalvinbb@gmail.com", "cvvvv");


                client.Send(message);
                client.Disconnect(true);
                client.Dispose();

                return Ok(new ForgotPasswordResult { Successful = true });


            }
            catch (Exception ex)
            {
                //returnErrorMessage = ex.Message;
                IEnumerable<string> Errorskk = new string[] { ex.Message, "", "" };
                return Ok(new ForgotPasswordResult { Successful = false, Errors = Errorskk });

            }




        }



        private string GetNamesDetail(string PK_ID,
         out bool returnStatus,
         out string returnErrorMessage,
         out List<string> returnMessages)
        {

            try
            {

                StringBuilder sqlBuilder = new StringBuilder();

                //string sqlString = "SELECT * FROM AspNetUsers WHERE Email = @PK_ID";
                string sqlString = "SELECT * FROM AspNetUsers WHERE UserName = @PK_ID";

                //SqlConnection connection;
                //connection = new SqlConnection();

                SQLiteConnection connection;
                connection = new SQLiteConnection();

                //ThisViewModel.DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

                String connectionString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;


                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                //UtilitiesBLL UtilitiesBLLget = new UtilitiesBLL();
                //SqlConnection connection = UtilitiesBLLget.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage); //SQL Server
                //SqlConnection connection = CreateConnection(out returnStatus, out returnErrorMessage);

                SQLiteCommand patientCommand = new SQLiteCommand();
                //SqlCommand patientCommand = new SqlCommand();
                patientCommand.CommandType = CommandType.Text;
                patientCommand.Connection = connection;
                patientCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@PK_ID", DbType.String);
                param1.Value = PK_ID;
                //param1.Value = 312;
                patientCommand.Parameters.Add(param1);

                SQLiteDataAdapter sqlAdapter = new SQLiteDataAdapter(patientCommand);

                DataSet scriptData = new DataSet();
                sqlAdapter.Fill(scriptData, "Patients");

                connection.Close();

                List<string> outputMessages = new List<string>();
                outputMessages.Add("Names Information Retrieved");

                returnStatus = true;
                returnMessages = outputMessages;
                string dateCheck = "";

                dateCheck = Convert.ToString(scriptData.Tables[0].Rows[0]["Id"]);

                //dateCheck = Convert.ToString(scriptData.Tables[0].Rows[0]["UserID"]).ToUpper();
                //dateCheck = Convert.ToString(scriptData.Tables[0].Rows[0]["UserID"]);

                //script.Name_ID = Convert.ToInt64(scriptData.Tables[0].Rows[0]["UserID"]);
                //script.Lastname = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Lastname"]);
                //script.Firstname = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Firstname"]);
                returnErrorMessage = "OK";

                return dateCheck;

            }
            catch (Exception ex)
            {

                List<string> outputMessages = new List<string>();

                returnStatus = false;
                returnErrorMessage = ex.Message;
                returnMessages = outputMessages;
                string dateCheck = "";
                //Names script = new Names();

                return dateCheck;

            }

        }



    }
}
