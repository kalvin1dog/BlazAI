﻿using appBLL;
using BlazLite1.Shared;
using Microsoft.AspNetCore.Mvc;

namespace BlazLite1.Server.Controllers
{
    //[Authorize]
    [ApiController]
    //[Route("[controller]")]
    public class GenCodeController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;

        public GenCodeController(IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }


        [HttpPost]
        [Route("api/GenCode/PostCombo")]
        public ENTITYTABLE PostCombo([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs" ,SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        
                        GenerateCOMBORAZUSE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        
                        GenerateCOMBORAZNEW2USE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }




        [HttpPost]
        [Route("api/GenCode/PostComboAuto")]
        public ENTITYTABLE PostComboAuto([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {


                        GenerateCOMBOAUTORAZUSE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        
                        GenerateCOMBOAUTORAZNEW2USE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }



        [HttpPost]
        [Route("api/GenCode/Post")]
        public ENTITYTABLE Post([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                //new for combos
                string strdropcol1In = "";
                string strdropcol2In = "";
                string strdropcol3In = "";
                string strdropcol4In = "";
                string strdropcol5In = "";
                string strdropcol6In = "";
                string strautodropcol1In = "";
                string strautodropcol2In = "";
                string strautodropcol3In = "";
                string strautodropcol4In = "";
                string strautodropcol5In = "";
                string strautodropcol6In = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.primarykey;
                column1str = paramENTITY.column1;
                column1type = paramENTITY.column1type;
                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //new for combos
                strdropcol1In = paramENTITY.dropcol1In;
                strdropcol2In = paramENTITY.dropcol2In;
                strdropcol3In = paramENTITY.dropcol3In;
                strdropcol4In = paramENTITY.dropcol4In;
                strdropcol5In = paramENTITY.dropcol5In;
                strdropcol6In = paramENTITY.dropcol6In;

                strautodropcol1In = paramENTITY.autodropcol1In;
                strautodropcol2In = paramENTITY.autodropcol2In;
                strautodropcol3In = paramENTITY.autodropcol3In;
                strautodropcol4In = paramENTITY.autodropcol4In;
                strautodropcol5In = paramENTITY.autodropcol5In;
                strautodropcol6In = paramENTITY.autodropcol6In;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column1str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 1 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column2str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 2 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column3str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 3 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column4str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 4 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {


                        
                        GenerateTOPGRIDRAZUSE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                            strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);
                        

                        GenerateTOPGRIDRAZNEW2USE(projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        

                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }


        private string ConvertTypes(string textin, string columnin, string columntypein, int colno)
        {
            string Result = "";
            string repcol = "~column" + colno + "~";
            string repcolnull = "column" + colno + "BLANK";
            string columntypeinUP = columntypein.ToUpper();

            try
            {
                if (columnin == "")
                {
                    textin = textin.Replace(repcol, repcolnull);
                }
                else
                {
                    textin = textin.Replace(repcol, columnin);
                }
              
                //textin = textin.Replace("~column" + colno + "~", columnin);
                if (columntypein.ToUpper() == "CHAR" || columntypeinUP == "VARCHAR" || columntypeinUP == "TEXT" || columntypeinUP == "BLOB")
                {
                    textin = textin.Replace("~chartypecol" + colno + "~", "");
                }
                if (columntypeinUP == "INTEGER")
                {
                    textin = textin.Replace("~inttypecol" + colno + "~", "");
                }
                if (columntypeinUP == "DECIMAL" || columntypeinUP == "MONEY" || columntypeinUP == "REAL")
                {
                    textin = textin.Replace("~dectypecol" + colno + "~", "");
                }
                if (columntypeinUP == "DATE" || columntypeinUP == "DATETIME")
                {
                    textin = textin.Replace("~datetypecol" + colno + "~", "");
                }


                if (columntypeinUP == "FINISH")
                {
                    textin = textin.Replace("~dropdowntypecol" + colno + "~", "");
                    textin = textin.Replace("~autodropdowntypecol" + colno + "~", "");
                }


                Result = textin;

            }
            catch
            {
                Result = textin;
                // Ignore errors 
            }

            return Result;
        }


        private void GenerateCOMBOAUTORAZUSE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                string newoutfolder = "";


                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoMod.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoMod.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/colautoMod.ck", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                //ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col3", column3type);

                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "autoMod.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~combotable~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~tablecolumin~", comboprogstr);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE

                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Shared");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + comboprogstr + "autoMod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoViewModel.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoViewModel.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "autoViewModel.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~combotable~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Models/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Models/" + progstr + "UI/" + progstr + comboprogstr + "autoViewModels.cs";


                //destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------






            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }



        private void GenerateCOMBOAUTORAZNEW2USE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoBLL.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoBLL.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/colautoBLL.ck", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);


                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "autoBLL.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~column1~", column1str);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE   NB could be used, but assume column1 is always CHAR
                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                string newoutfolder = _Env.ContentRootPath + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + comboprogstr + "autoBLL.cs";

                //destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoController.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoController.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";

                //ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col5", column5type);

                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "autoController.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);

                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);
                //text = text.Replace("~column2~", column2str);
                //text = text.Replace("~column3~", column3str);
                //text = text.Replace("~column4~", column4str);

                //text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Controllers/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Controllers/" + progstr + "UI/" + progstr + comboprogstr + "autoController.cs";


                //destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoCombo.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colautoCombo.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                //ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);

                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "autoCombo.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~column1~", column1str);

                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);

                //text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Shared/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Shared/" + progstr + "UI/" + progstr + comboprogstr + "autoCombo.razor";

                //destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------


            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }


        private void GenerateCOMBORAZUSE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                string newoutfolder = "";


                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colMod.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colMod.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/colMod.ck", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                //ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col3", column3type);
               
                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "Mod.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~combotable~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~tablecolumin~", comboprogstr);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE

                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                

                System.IO.File.WriteAllText(outprogrealname, text);
                 
                newoutfolder = _Env.ContentRootPath + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Shared");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + comboprogstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colViewModel.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colViewModel.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "ViewModel.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~combotable~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Models/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Models/" + progstr + "UI/" + progstr + comboprogstr + "ViewModels.cs";


                //destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------






            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }



        private void GenerateCOMBORAZNEW2USE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colBLL.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colBLL.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/colBLL.ck", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);
             

                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "BLL.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~column1~", column1str);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE   NB could be used, but assume column1 is always CHAR
                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                

                System.IO.File.WriteAllText(outprogrealname, text);

                string newoutfolder = _Env.ContentRootPath + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + comboprogstr + "BLL.cs";

                //destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colController.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colController.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";

                //ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col5", column5type);
                
                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "Controller.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);

                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);
                //text = text.Replace("~column2~", column2str);
                //text = text.Replace("~column3~", column3str);
                //text = text.Replace("~column4~", column4str);

                //text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
              

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Controllers/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Controllers/" + progstr + "UI/" + progstr + comboprogstr + "Controller.cs";


                //destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colCombo.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/colCombo.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                //ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                //ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);
               
                progrealname = "Gen_Code/TOPGRID/" + comboprogstr + "Combo.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~combotable~", tablestr);
                text = text.Replace("~tablecolumin~", comboprogstr);
                text = text.Replace("~columpk~", strpkid);
                text = text.Replace("~column1~", column1str);

                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);

                //text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                //text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Shared/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Shared/" + progstr + "UI/" + progstr + comboprogstr + "Combo.razor";

                //destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------


            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }



        private void GenerateTOPGRIDRAZUSE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid, 
            string strdropcol1In, string strdropcol2In, string strdropcol3In, string strdropcol4In, string strdropcol5In, string strdropcol6In,
            string strautodropcol1In, string strautodropcol2In, string strautodropcol3In, string strautodropcol4In, string strautodropcol5In, string strautodropcol6In)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                string newoutfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col11", column11type);


                progrealname = "Gen_Code/TOPGRID/" + progstr + "Grid.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE

                System.IO.File.WriteAllText(outprogrealname, text);


                //string root = @"C:\Temp";
                //string subdir = @"C:\Temp\Mahesh";
                // If directory does not exist, create it.  
                //if (!System.IO.Directory.Exists(root))
                //{
                //System.IO.Directory.CreateDirectory(root);
                //}

                newoutfolder = _Env.ContentRootPath + "Pages/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                 System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Pages/" + progstr + "UI/" + progstr + "Grid.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                
                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Mod.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);
                 
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Shared");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + progstr + "ViewModel.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Models/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Models/" + progstr + "UI/" + progstr + "ViewModels.cs";


                //destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------





                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";

                 
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", strdropcol1In);
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", strdropcol2In);
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col3", strdropcol3In);
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col4", strdropcol4In);
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col5", strdropcol5In);
                ConfigureComboColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col6", strdropcol6In);

                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", strautodropcol1In);
                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", strautodropcol2In);
                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col3", strautodropcol3In);
                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col4", strautodropcol4In);
                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col5", strautodropcol5In);
                ConfigureComboAutoColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col6", strautodropcol6In);


                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Dialog.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);

                text = ConvertTypes(text, column1str, strdropcol1In, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, strdropcol2In, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, strdropcol3In, 3);  //NEW CODE 
                text = ConvertTypes(text, column4str, strdropcol4In, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, strdropcol5In, 5);  //NEW CODE 
                text = ConvertTypes(text, column6str, strdropcol6In, 6);  //NEW CODE


                text = ConvertTypes(text, column1str, strautodropcol1In, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, strautodropcol2In, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, strautodropcol3In, 3);  //NEW CODE 
                text = ConvertTypes(text, column4str, strautodropcol4In, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, strautodropcol5In, 5);  //NEW CODE 
                text = ConvertTypes(text, column6str, strautodropcol6In, 6);  //NEW CODE

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Shared/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Shared/" + progstr + "UI/" + progstr + "Dialog.razor";

                //destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }



        private void GenerateTOPGRIDRAZNEW2USE(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col4", column4type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col11", column11type);


                progrealname = "Gen_Code/TOPGRID/" + progstr + "BLL.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                string newoutfolder = _Env.ContentRootPath + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = progstr + "UI/" + progstr + "BLL.cs";

                //destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";

                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Controller.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);

                text = text.Replace("~column1~", column1str);
                text = text.Replace("~column2~", column2str);
                text = text.Replace("~column3~", column3str);
                text = text.Replace("~column4~", column4str);

                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                newoutfolder = _Env.ContentRootPath + "Controllers/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does not exist, create it.  
                if (!System.IO.Directory.Exists(newoutfolder))
                {
                    System.IO.Directory.CreateDirectory(newoutfolder);
                }

                destfolderViews = "Controllers/" + progstr + "UI/" + progstr + "Controller.cs";


                //destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                destfolderViews = "Shared/" + "NavMenu.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                string kprog1 = progstr;
                newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);

                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }


        private void GenerateTOPGRIDRAZTEST(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo,
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col11", column11type);


                progrealname = "Gen_Code/TOPGRID/" + progstr + "Grid.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE
             
                System.IO.File.WriteAllText(outprogrealname, text);


                //string root = @"C:\Temp";
                //string subdir = @"C:\Temp\Mahesh";
                // If directory does not exist, create it. 
                //if (!System.IO.Directory.Exists(root))
                //{
                    //System.IO.Directory.CreateDirectory(root);
                //}


                destfolderViews = "Pages/" + progstr + "Grid.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Mod.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE

                /*
                for (int ik = 0; ik < 12; ik++)
                {
                    //Console.WriteLine(ik);
                    text = text.Replace("~column" + ik + "~", column1str);
                    if ("column" + ik + "type" == "Char" || "column" + ik + "type" == "VARCHAR")
                    {
                        text = text.Replace("~chartypecol" + ik + "~", "");
                    }
                }
                */

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "" + progstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Dialog.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                //text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1~", column1str);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + progstr + "ViewModel.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }



        private void GenerateTOPGRIDRAZNEW2TEST(string projstr, string progstr, string strpkid, string column1str, string column1type,
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type,
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type,
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type,
            string column11str, string column11type,
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, 
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col4", column4type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col11", column11type);
               

                progrealname = "Gen_Code/TOPGRID/" + progstr + "BLL.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);

                text = ConvertTypes(text, column1str, column1type, 1);  //NEW CODE
                text = ConvertTypes(text, column2str, column2type, 2);  //NEW CODE
                text = ConvertTypes(text, column3str, column3type, 3);  //NEW CODE
                text = ConvertTypes(text, column4str, column4type, 4);  //NEW CODE
                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";

                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progController.ck", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Controller.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);

                text = text.Replace("~column1~", column1str);
                text = text.Replace("~column2~", column2str);
                text = text.Replace("~column3~", column3str);
                text = text.Replace("~column4~", column4str);

                text = ConvertTypes(text, column5str, column5type, 5);  //NEW CODE
                text = ConvertTypes(text, column6str, column6type, 6);  //NEW CODE
                text = ConvertTypes(text, column7str, column7type, 7);  //NEW CODE
                text = ConvertTypes(text, column8str, column8type, 8);  //NEW CODE
                text = ConvertTypes(text, column9str, column9type, 9);  //NEW CODE
                text = ConvertTypes(text, column10str, column10type, 10);  //NEW CODE
                text = ConvertTypes(text, column11str, column11type, 11);  //NEW CODE


                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                destfolderViews = "Shared/" + "NavMenu.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                string kprog1 = progstr;
                newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);

                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }






        private void GenerateTOPGRIDRAZNEW(string projstr, string progstr, string strpkid, string column1str, string column1type, 
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, 
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, 
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, 
            string column11str, string column11type, 
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, 
            string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                //string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------

                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progGrid.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/progGrid.rzzk", "col11", column11type);


                progrealname = "Gen_Code/TOPGRID/" + progstr + "Grid.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);


                text = text.Replace("~column1~", column1str);
                if (column1type == "Char")
                {
                    text = text.Replace("~chartypecol1~", "");
                }
                if (column1type == "Integer")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "INTEGER")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "Decimal")
                {
                    text = text.Replace("~dectypecol1~", "");
                }
                if (column1type == "Date")
                {
                    text = text.Replace("~datetypecol1~", "");
                }
                text = text.Replace("~column2~", column2str);
                if (column2type == "Char")
                {
                    text = text.Replace("~chartypecol2~", "");
                }
                if (column2type == "Integer")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "INTEGER")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "Decimal")
                {
                    text = text.Replace("~dectypecol2~", "");
                }
                if (column2type == "Date")
                {
                    text = text.Replace("~datetypecol2~", "");
                }
                text = text.Replace("~column3~", column3str);
                if (column3type == "Char")
                {
                    text = text.Replace("~chartypecol3~", "");
                }
                if (column3type == "Integer")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "INTEGER")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "Decimal")
                {
                    text = text.Replace("~dectypecol3~", "");
                }
                if (column3type == "Date")
                {
                    text = text.Replace("~datetypecol3~", "");
                }
                text = text.Replace("~column4~", column4str);
                if (column4type == "Char")
                {
                    text = text.Replace("~chartypecol4~", "");
                }
                if (column4type == "Integer")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "INTEGER")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "Decimal")
                {
                    text = text.Replace("~dectypecol4~", "");
                }
                if (column4type == "Date")
                {
                    text = text.Replace("~datetypecol4~", "");
                }


                if (column5str == "")
                {
                    text = text.Replace("~column5~", "column5");
                }
                else
                {
                    text = text.Replace("~column5~", column5str);
                }
               
                if (column5type == "Char")
                {
                    text = text.Replace("~chartypecol5~", "");
                }
                if (column5type == "Integer")
                {
                    text = text.Replace("~inttypecol5~", "");
                }
                if (column5type == "INTEGER")
                {
                    text = text.Replace("~inttypecol5~", "");
                }
                if (column5type == "Decimal")
                {
                    text = text.Replace("~dectypecol5~", "");
                }
                if (column5type == "Date")
                {
                    text = text.Replace("~datetypecol5~", "");
                }


                if (column6str == "")
                {
                    text = text.Replace("~column6~", "column6");
                }
                else
                {
                    text = text.Replace("~column6~", column6str);
                }

                if (column6type == "Char")
                {
                    text = text.Replace("~chartypecol6~", "");
                }
                if (column6type == "Integer")
                {
                    text = text.Replace("~inttypecol6~", "");
                }
                if (column6type == "INTEGER")
                {
                    text = text.Replace("~inttypecol6~", "");
                }
                if (column6type == "Decimal")
                {
                    text = text.Replace("~dectypecol6~", "");
                }
                if (column6type == "Date")
                {
                    text = text.Replace("~datetypecol6~", "");
                }


                if (column7str == "")
                {
                    text = text.Replace("~column7~", "column7");
                }
                else
                {
                    text = text.Replace("~column7~", column7str);
                }

                if (column7type == "Char")
                {
                    text = text.Replace("~chartypecol7~", "");
                }
                if (column7type == "Integer")
                {
                    text = text.Replace("~inttypecol7~", "");
                }
                if (column7type == "INTEGER")
                {
                    text = text.Replace("~inttypecol7~", "");
                }
                if (column7type == "Decimal")
                {
                    text = text.Replace("~dectypecol7~", "");
                }
                if (column7type == "Date")
                {
                    text = text.Replace("~datetypecol7~", "");
                }


                if (column8str == "")
                {
                    text = text.Replace("~column8~", "column8");
                }
                else
                {
                    text = text.Replace("~column8~", column8str);
                }

                if (column8type == "Char")
                {
                    text = text.Replace("~chartypecol8~", "");
                }
                if (column8type == "Integer")
                {
                    text = text.Replace("~inttypecol8~", "");
                }
                if (column8type == "INTEGER")
                {
                    text = text.Replace("~inttypecol8~", "");
                }
                if (column8type == "Decimal")
                {
                    text = text.Replace("~dectypecol8~", "");
                }
                if (column8type == "Date")
                {
                    text = text.Replace("~datetypecol8~", "");
                }


                if (column9str == "")
                {
                    text = text.Replace("~column9~", "column9");
                }
                else
                {
                    text = text.Replace("~column9~", column9str);
                }

                if (column9type == "Char")
                {
                    text = text.Replace("~chartypecol9~", "");
                }
                if (column9type == "Integer")
                {
                    text = text.Replace("~inttypecol9~", "");
                }
                if (column9type == "INTEGER")
                {
                    text = text.Replace("~inttypecol9~", "");
                }
                if (column9type == "Decimal")
                {
                    text = text.Replace("~dectypecol9~", "");
                }
                if (column9type == "Date")
                {
                    text = text.Replace("~datetypecol9~", "");
                }


                if (column10str == "")
                {
                    text = text.Replace("~column10~", "column10");
                }
                else
                {
                    text = text.Replace("~column10~", column10str);
                }

                if (column10type == "Char")
                {
                    text = text.Replace("~chartypecol10~", "");
                }
                if (column10type == "Integer")
                {
                    text = text.Replace("~inttypecol10~", "");
                }
                if (column10type == "INTEGER")
                {
                    text = text.Replace("~inttypecol10~", "");
                }
                if (column10type == "Decimal")
                {
                    text = text.Replace("~dectypecol10~", "");
                }
                if (column10type == "Date")
                {
                    text = text.Replace("~datetypecol10~", "");
                }


                if (column11str == "")
                {
                    text = text.Replace("~column11~", "column11");
                }
                else
                {
                    text = text.Replace("~column11~", column11str);
                }

                if (column11type == "Char")
                {
                    text = text.Replace("~chartypecol11~", "");
                }
                if (column11type == "Integer")
                {
                    text = text.Replace("~inttypecol11~", "");
                }
                if (column11type == "INTEGER")
                {
                    text = text.Replace("~inttypecol11~", "");
                }
                if (column11type == "Decimal")
                {
                    text = text.Replace("~dectypecol11~", "");
                }
                if (column11type == "Date")
                {
                    text = text.Replace("~datetypecol11~", "");
                }


                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Pages/" + progstr + "Grid.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzr");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progDialog.rzzk");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progDialog.rzzk", "col4", column4type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Dialog.rzzk";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                //text = text.Replace("~proglower~", progstr.ToLower());
                text = text.Replace("~proj~", projstr);
                //text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                //text = text.Replace("~PK_ID~", strpkid);
                text = text.Replace("~column1~", column1str);
                if (column1type == "Char")
                {
                    text = text.Replace("~chartypecol1~", "");
                }
                if (column1type == "Integer")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "INTEGER")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "Decimal")
                {
                    text = text.Replace("~dectypecol1~", "");
                }
                if (column1type == "Date")
                {
                    text = text.Replace("~datetypecol1~", "");
                }
                text = text.Replace("~column2~", column2str);
                if (column2type == "Char")
                {
                    text = text.Replace("~chartypecol2~", "");
                }
                if (column2type == "Integer")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "INTEGER")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "Decimal")
                {
                    text = text.Replace("~dectypecol2~", "");
                }
                if (column2type == "Date")
                {
                    text = text.Replace("~datetypecol2~", "");
                }
                text = text.Replace("~column3~", column3str);
                if (column3type == "Char")
                {
                    text = text.Replace("~chartypecol3~", "");
                }
                if (column3type == "Integer")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "INTEGER")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "Decimal")
                {
                    text = text.Replace("~dectypecol3~", "");
                }
                if (column3type == "Date")
                {
                    text = text.Replace("~datetypecol3~", "");
                }
                text = text.Replace("~column4~", column4str);
                if (column4type == "Char")
                {
                    text = text.Replace("~chartypecol4~", "");
                }
                if (column4type == "Integer")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "INTEGER")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "Decimal")
                {
                    text = text.Replace("~dectypecol4~", "");
                }
                if (column4type == "Date")
                {
                    text = text.Replace("~datetypecol4~", "");
                }

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------






                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/projMod.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col4", column4type);

                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col5", column5type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col6", column6type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col7", column7type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col8", column8type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col9", column9type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col10", column10type);
                ConfigureColumn("Gen_Code/TOPGRID/projMod.ck", "col11", column11type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "Mod.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~prog~", progstr);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", progstr);
                text = text.Replace("~PK_ID~", strpkid);
                text = text.Replace("~column1~", column1str);
                if (strpkid == "Char")   //Guid
                {
                    // text = text.Replace("long", "string");
                }
                if (column1type == "Char")
                {
                    text = text.Replace("~chartypecol1~", "");
                }
                if (column1type == "Integer")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "INTEGER")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "Decimal")
                {
                    text = text.Replace("~dectypecol1~", "");
                }
                if (column1type == "Date")
                {
                    text = text.Replace("~datetypecol1~", "");
                }
                text = text.Replace("~column2~", column2str);
                if (column2type == "Char")
                {
                    text = text.Replace("~chartypecol2~", "");
                }
                if (column2type == "Integer")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "INTEGER")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "Decimal")
                {
                    text = text.Replace("~dectypecol2~", "");
                }
                if (column2type == "Date")
                {
                    text = text.Replace("~datetypecol2~", "");
                }
                text = text.Replace("~column3~", column3str);
                if (column3type == "Char")
                {
                    text = text.Replace("~chartypecol3~", "");
                }
                if (column3type == "Integer")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "INTEGER")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "Decimal")
                {
                    text = text.Replace("~dectypecol3~", "");
                }
                if (column3type == "Date")
                {
                    text = text.Replace("~datetypecol3~", "");
                }
                text = text.Replace("~column4~", column4str);
                if (column4type == "Char")
                {
                    text = text.Replace("~chartypecol4~", "");
                }
                if (column4type == "Integer")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "INTEGER")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "Decimal")
                {
                    text = text.Replace("~dectypecol4~", "");
                }
                if (column4type == "Date")
                {
                    text = text.Replace("~datetypecol4~", "");
                }


                if (column5str == "")
                {
                    text = text.Replace("~column5~", "column5");
                }
                else
                {
                    text = text.Replace("~column5~", column5str);
                }

                if (column5type == "Char")
                {
                    text = text.Replace("~chartypecol5~", "");
                }
                if (column5type == "Integer")
                {
                    text = text.Replace("~inttypecol5~", "");
                }
                if (column5type == "INTEGER")
                {
                    text = text.Replace("~inttypecol5~", "");
                }
                if (column5type == "Decimal")
                {
                    text = text.Replace("~dectypecol5~", "");
                }
                if (column5type == "Date")
                {
                    text = text.Replace("~datetypecol5~", "");
                }


                if (column6str == "")
                {
                    text = text.Replace("~column6~", "column6");
                }
                else
                {
                    text = text.Replace("~column6~", column6str);
                }

                if (column6type == "Char")
                {
                    text = text.Replace("~chartypecol6~", "");
                }
                if (column6type == "Integer")
                {
                    text = text.Replace("~inttypecol6~", "");
                }
                if (column6type == "INTEGER")
                {
                    text = text.Replace("~inttypecol6~", "");
                }
                if (column6type == "Decimal")
                {
                    text = text.Replace("~dectypecol6~", "");
                }
                if (column6type == "Date")
                {
                    text = text.Replace("~datetypecol6~", "");
                }


                if (column7str == "")
                {
                    text = text.Replace("~column7~", "column7");
                }
                else
                {
                    text = text.Replace("~column7~", column7str);
                }

                if (column7type == "Char")
                {
                    text = text.Replace("~chartypecol7~", "");
                }
                if (column7type == "Integer")
                {
                    text = text.Replace("~inttypecol7~", "");
                }
                if (column7type == "INTEGER")
                {
                    text = text.Replace("~inttypecol7~", "");
                }
                if (column7type == "Decimal")
                {
                    text = text.Replace("~dectypecol7~", "");
                }
                if (column7type == "Date")
                {
                    text = text.Replace("~datetypecol7~", "");
                }


                if (column8str == "")
                {
                    text = text.Replace("~column8~", "column8");
                }
                else
                {
                    text = text.Replace("~column8~", column8str);
                }

                if (column8type == "Char")
                {
                    text = text.Replace("~chartypecol8~", "");
                }
                if (column8type == "Integer")
                {
                    text = text.Replace("~inttypecol8~", "");
                }
                if (column8type == "INTEGER")
                {
                    text = text.Replace("~inttypecol8~", "");
                }
                if (column8type == "Decimal")
                {
                    text = text.Replace("~dectypecol8~", "");
                }
                if (column8type == "Date")
                {
                    text = text.Replace("~datetypecol8~", "");
                }


                if (column9str == "")
                {
                    text = text.Replace("~column9~", "column9");
                }
                else
                {
                    text = text.Replace("~column9~", column9str);
                }

                if (column9type == "Char")
                {
                    text = text.Replace("~chartypecol9~", "");
                }
                if (column9type == "Integer")
                {
                    text = text.Replace("~inttypecol9~", "");
                }
                if (column9type == "INTEGER")
                {
                    text = text.Replace("~inttypecol9~", "");
                }
                if (column9type == "Decimal")
                {
                    text = text.Replace("~dectypecol9~", "");
                }
                if (column9type == "Date")
                {
                    text = text.Replace("~datetypecol9~", "");
                }


                if (column10str == "")
                {
                    text = text.Replace("~column10~", "column10");
                }
                else
                {
                    text = text.Replace("~column10~", column10str);
                }

                if (column10type == "Char")
                {
                    text = text.Replace("~chartypecol10~", "");
                }
                if (column10type == "Integer")
                {
                    text = text.Replace("~inttypecol10~", "");
                }
                if (column10type == "INTEGER")
                {
                    text = text.Replace("~inttypecol10~", "");
                }
                if (column10type == "Decimal")
                {
                    text = text.Replace("~dectypecol10~", "");
                }
                if (column10type == "Date")
                {
                    text = text.Replace("~datetypecol10~", "");
                }


                if (column11str == "")
                {
                    text = text.Replace("~column11~", "column11");
                }
                else
                {
                    text = text.Replace("~column11~", column11str);
                }

                if (column11type == "Char")
                {
                    text = text.Replace("~chartypecol11~", "");
                }
                if (column11type == "Integer")
                {
                    text = text.Replace("~inttypecol11~", "");
                }
                if (column11type == "INTEGER")
                {
                    text = text.Replace("~inttypecol11~", "");
                }
                if (column11type == "Decimal")
                {
                    text = text.Replace("~dectypecol11~", "");
                }
                if (column11type == "Date")
                {
                    text = text.Replace("~datetypecol11~", "");
                }


                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "" + progstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");

                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------




                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progViewModel.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + progstr + "ViewModel.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                //text = text.Replace("~table~", tablestr);
                //text = text.Replace("~PK_ID~", strpkid);

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------


                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }




        private void GenerateTOPGRIDRAZNEW2(string projstr, string progstr, string strpkid, string column1str, string column1type, 
            string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, 
            string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, 
            string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, 
            string column11str, string column11type, 
            string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {

            try
            {
                string inputDecrpt = "";
                string outputDecrpt = "";
                string text = "";
                string newcsproj = "";
                string progrealname = "";
                string outprogrealname = "";
                string destfolderViews = "";
                string outputdestfolder = "";

                //--------------------------------------------------------------------------------------------------------------------
                //TOP GRID Building
                //--------------------------------------------------------------------------------------------------------------------
                 
                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progBLL.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col1", column1type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col3", column3type);
                ConfigureColumn("Gen_Code/TOPGRID/progBLL.ck", "col4", column4type);

                progrealname = "Gen_Code/TOPGRID/" + progstr + "BLL.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);

                text = System.IO.File.ReadAllText(outputDecrpt);

                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);

                //text = text.Replace("~column1type~", column1type);  //Change taken out
                //text = text.Replace("~column2type~", column2type);
                //text = text.Replace("~column3type~", column3type);
                //text = text.Replace("~column4type~", column4type);

                text = text.Replace("~column1~", column1str);
                if (column1type == "Char")
                {
                    text = text.Replace("~chartypecol1~", "");
                }
                if (column1type == "Integer")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "INTEGER")
                {
                    text = text.Replace("~inttypecol1~", "");
                }
                if (column1type == "Decimal")
                {
                    text = text.Replace("~dectypecol1~", "");
                }
                if (column1type == "Date")
                {
                    text = text.Replace("~datetypecol1~", "");
                }
                text = text.Replace("~column2~", column2str);
                if (column2type == "Char")
                {
                    text = text.Replace("~chartypecol2~", "");
                }
                if (column2type == "Integer")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "INTEGER")
                {
                    text = text.Replace("~inttypecol2~", "");
                }
                if (column2type == "Decimal")
                {
                    text = text.Replace("~dectypecol2~", "");
                }
                if (column2type == "Date")
                {
                    text = text.Replace("~datetypecol2~", "");
                }
                text = text.Replace("~column3~", column3str);
                if (column3type == "Char")
                {
                    text = text.Replace("~chartypecol3~", "");
                }
                if (column3type == "Integer")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "INTEGER")
                {
                    text = text.Replace("~inttypecol3~", "");
                }
                if (column3type == "Decimal")
                {
                    text = text.Replace("~dectypecol3~", "");
                }
                if (column3type == "Date")
                {
                    text = text.Replace("~datetypecol3~", "");
                }
                text = text.Replace("~column4~", column4str);
                if (column4type == "Char")
                {
                    text = text.Replace("~chartypecol4~", "");
                }
                if (column4type == "Integer")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "INTEGER")
                {
                    text = text.Replace("~inttypecol4~", "");
                }
                if (column4type == "Decimal")
                {
                    text = text.Replace("~dectypecol4~", "");
                }
                if (column4type == "Date")
                {
                    text = text.Replace("~datetypecol4~", "");
                }

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                inputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.cz");
                outputDecrpt = System.IO.Path.Combine(_Env.ContentRootPath, "Gen_Code/TOPGRID/progController.ck");
                System.IO.File.Copy(inputDecrpt, outputDecrpt, true);

                progrealname = "";
                progrealname = "Gen_Code/TOPGRID/" + progstr + "Controller.ck";
                outprogrealname = System.IO.Path.Combine(_Env.ContentRootPath, progrealname);
                text = "";
                text = System.IO.File.ReadAllText(outputDecrpt);
                text = text.Replace("~proj~", projstr);
                text = text.Replace("~prog~", progstr);
                text = text.Replace("~tablemodel~", tablestr);
                text = text.Replace("~table~", tablestr);
                text = text.Replace("~PK_ID~", strpkid);
                text = text.Replace("~column1~", column1str);
                text = text.Replace("~column2~", column2str);
                text = text.Replace("~column3~", column3str);
                text = text.Replace("~column4~", column4str);

                System.IO.File.WriteAllText(outprogrealname, text);

                destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Copy(outprogrealname, outputdestfolder, true);

                System.IO.File.Delete(outprogrealname);
                System.IO.File.Delete(outputDecrpt);
                //-------------------------------------------------------------------------------------------------



                destfolderViews = "Shared/" + "NavMenu.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                string kprog1 = progstr;
                newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);

                //END Building
                //-----------------------------------------------------------------------------------------------------------------------------------

            }
            catch (Exception ex)
            {

                string err = ex.Message;
                string delresponse = DelProgsAgain(progstr);  //Delete Code again

            }

        }




        [HttpPost]
        [Route("api/DelCode/Post")]
        public ENTITYTABLE PostDel([FromBody] ENTITYTABLE paramENTITY)
        {
            //long returnPageNumber;
            //long returnRowNumber;
            //bool returnStatus;
            //string returnErrorMessage;

            //List<string> returnMessage;

            //string col1 = paramENTITY.column1;  //just test
            //string col2 = paramENTITY.column2;  //just test

            try
            {
                string progstr = "";

                //string tablestr = ThisViewModel.tablename;
                progstr = paramENTITY.progname;

                //paramENTITY.propnote = "propnote";  //test

                if (progstr == null || progstr == "")
                {
                    List<string> outputMessagesk = new List<string>();

                    //returnStatus = false;
                    //outputMessagesk.Add("Program Name invalid!");

                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }


                string chk = "NotFound";
                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    {
                        chk = "foundProg";  //so found already
                    }
                }

                if (chk == "NotFound")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please Change Name.";

                    //return paramENTITY;  //test only commented out

                }


                //new code to do Delete, not doing below anymore
                //string delresponse = DelProgsAgain(progstr);
                string delresponse = DelProgsAgainTest(progstr);

                //returnStatus = true;
                //returnErrorMessage = "Done";

                paramENTITY.ErrChk = true;
                paramENTITY.ErrMsg = "Code Deleted OK.";

                return paramENTITY;

            }
            catch (Exception ex)
            {
                //List<string> outputMessages = new List<string>();

                //returnStatus = false;
                //outputMessages.Add(ex.Message);

                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                return paramENTITY;
            }

        }



        private string DelProgsAgainTest(string progstr)
        {
            try
            {
                string newoutfolder = "";

                //string destfolderViews = "Pages/" + progstr + "Grid.razor";
                //string outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                //outputdestfolder = outputdestfolder.Replace("Server", "Client");
                //System.IO.File.Delete(outputdestfolder);


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + "Pages/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + "Shared/" + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + "Controllers/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + "Models/" + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + progstr + "UI";
                //newoutfolder = newoutfolder.Replace("Server", "Client");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                //Delete folder here as well, also deletes all sub files in the folder
                newoutfolder = _Env.ContentRootPath + progstr + "UI";
                newoutfolder = newoutfolder.Replace("Server", "Shared");
                // If directory does exist, delete it.  
                if (System.IO.Directory.Exists(newoutfolder))
                {
                    //System.IO.Directory.CreateDirectory(newoutfolder);
                    System.IO.Directory.Delete(newoutfolder, true);
                }


                string destfolderViews = "Shared/" + "NavMenu.razor";
                string outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                //string kprog1 = progstr;
                string newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                //UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);
                MakeAHIMDelete(outputdestfolder, newcsproj, "ADDLINKHERE");


                /*
                destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "" + progstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");
                System.IO.File.Delete(outputdestfolder);


                //delete line in NavMenu.razor
                //string kprog1 = progstr;
                //string kprog2 = "Display" + progstr;
                //string newcsproj = "<li>@Html.ActionLink(" + (char)34 + kprog1 + (char)34 + "," + (char)34 + kprog2 + (char)34 + "," + (char)34 + kprog1 + (char)34 + ", null, new { onclick = " + (char)34 + "return LayoutShowProgressBar();" + (char)34 + " })</li>";
                //MakeAHIMDelete("Views/Shared/" + "_Layout.cshtml", newcsproj, "ADDLINKHERE");


                destfolderViews = "Shared/" + "NavMenu.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                //string kprog1 = progstr;
                string newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                //UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);
                MakeAHIMDelete(outputdestfolder, newcsproj, "ADDLINKHERE");

                */

                return "OK";

            }
            catch (Exception ex)
            {
                //outputMessages.Add(ex.Message);

                return "Error is:- " + ex.Message;
            }


        }


        private string DelProgsAgain(string progstr)
        {
            try
            {
                string destfolderViews = "Pages/" + progstr + "Grid.razor";
                string outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "Shared/" + progstr + "Dialog.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "Controllers/" + progstr + "Controller.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "Models/" + progstr + "ViewModel.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "" + progstr + "BLL.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                System.IO.File.Delete(outputdestfolder);

                destfolderViews = "" + progstr + "Mod.cs";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Shared");
                System.IO.File.Delete(outputdestfolder);


                //delete line in NavMenu.razor
                //string kprog1 = progstr;
                //string kprog2 = "Display" + progstr;
                //string newcsproj = "<li>@Html.ActionLink(" + (char)34 + kprog1 + (char)34 + "," + (char)34 + kprog2 + (char)34 + "," + (char)34 + kprog1 + (char)34 + ", null, new { onclick = " + (char)34 + "return LayoutShowProgressBar();" + (char)34 + " })</li>";
                //MakeAHIMDelete("Views/Shared/" + "_Layout.cshtml", newcsproj, "ADDLINKHERE");


                destfolderViews = "Shared/" + "NavMenu.razor";
                outputdestfolder = System.IO.Path.Combine(_Env.ContentRootPath, destfolderViews);
                outputdestfolder = outputdestfolder.Replace("Server", "Client");

                //string kprog1 = progstr;
                string newcsproj = "<div class='nav-item px-3'><NavLink class='nav-link' href='" + progstr.ToLower() + "grid'><span class='oi oi-person' aria-hidden='true'></span>" + progstr + "</NavLink></div>";

                //UpdateAHIMproj(outputdestfolder, "ADDLINKHERE", newcsproj);
                MakeAHIMDelete(outputdestfolder, newcsproj, "ADDLINKHERE");


                return "OK";

            }
            catch (Exception ex)
            {
                //outputMessages.Add(ex.Message);

                return "Error is:- " + ex.Message;
            }


        }



        //===================================================================================================================
        //This function configures a COLUMN depending on type
        //===================================================================================================================
        private void ConfigureColumn(string infile, string col, string typee)
        {
            string errmsg = "";

            try
            {

                if (typee == "")
                {
                    MakeBlankColumn(infile, col);
                }
               
                if (typee.ToUpper() == "VARCHAR")
                {
                    MakeCharColumn(infile, col);
                }
                if (typee.ToUpper() == "CHAR")
                {
                    MakeCharColumn(infile, col);
                }
                if (typee.ToUpper() == "TEXT")
                {
                    MakeCharColumn(infile, col);
                }
                if (typee.ToUpper() == "BLOB")
                {
                    MakeCharColumn(infile, col);
                }
                //if (typee == "Number")
                //{
                //MakeNumColumn(infile, col);
                //}
                if (typee.ToUpper() == "DATE" || typee.ToUpper() == "DATETIME")
                {
                    MakeDateColumn(infile, col);
                }
                //if (typee == "Date")
                //{
                   // MakeDateColumn(infile, col);
                //}
                if (typee.ToUpper() == "REAL")
                {
                    MakeDecColumn(infile, col);
                }
                if (typee.ToUpper() == "INTEGER")
                {
                    MakeIntColumn(infile, col);
                }
                if (typee.ToUpper() == "DECIMAL")
                {
                    MakeDecColumn(infile, col);
                }
                if (typee.ToUpper() == "MONEY")
                {
                    MakeDecColumn(infile, col);
                }


            }
            catch (Exception ex)
            {
                errmsg = ex.Message;
                //return "Error is:- " + ex.Message;
            }



        }
        private void ConfigureComboColumn(string infile, string col, string typee)
        {
            string errmsg = "";
             
            try
            {

                if (typee == "")
                {
                    MakeBlankComboColumn(infile, col);
                }
                if (typee.ToUpper() == "START")
                {
                    MakeBlankComboColumn(infile, col);
                }

            }
            catch (Exception ex)
            {
                errmsg = ex.Message;
                //return "Error is:- " + ex.Message;
            }



        }

        private void ConfigureComboAutoColumn(string infile, string col, string typee)
        {
            string errmsg = "";

            try
            {

                if (typee == "")
                {
                    MakeBlankComboAutoColumn(infile, col);
                }
                if (typee.ToUpper() == "START")
                {
                    MakeBlankComboAutoColumn(infile, col);
                }

            }
            catch (Exception ex)
            {
                errmsg = ex.Message;
                //return "Error is:- " + ex.Message;
            }



        }

        //This function gets rid of all lines for a COLUMN)
        private void MakeBlankColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text4 = "~datetype" + col + "~";   //delete all lines with this text in it (ie DATE)
                string old4;
                string n4 = "";
                StreamReader sr4 = System.IO.File.OpenText(FileName);
                while ((old4 = sr4.ReadLine()) != null)
                {
                    if (!old4.Contains(search_text4))
                    {
                        n4 += old4 + Environment.NewLine;
                    }
                }
                sr4.Close();
                System.IO.File.WriteAllText(FileName, n4);


                string search_text = "~chartype" + col + "~";   //delete all lines with this text in it (ie CHAR)
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)
                {
                    if (!old.Contains(search_text))
                    {
                        n += old + Environment.NewLine;
                    }
                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);


                string search_text2 = "~inttype" + col + "~";   //delete all lines with this text in it (ie INTEGER)
                string old2;
                string n2 = "";
                StreamReader sr2 = System.IO.File.OpenText(FileName);
                while ((old2 = sr2.ReadLine()) != null)
                {
                    if (!old2.Contains(search_text2))
                    {
                        n2 += old2 + Environment.NewLine;
                    }
                }
                sr2.Close();
                System.IO.File.WriteAllText(FileName, n2);


                string search_text3 = "~dectype" + col + "~";   //delete all lines with this text in it (ie DECIMAL)
                string old3;
                string n3 = "";
                StreamReader sr3 = System.IO.File.OpenText(FileName);
                while ((old3 = sr3.ReadLine()) != null)
                {
                    if (!old3.Contains(search_text3))
                    {
                        n3 += old3 + Environment.NewLine;
                    }
                }
                sr3.Close();
                System.IO.File.WriteAllText(FileName, n3);


            }
            catch (Exception)
            {


            }

        }

        private void MakeBlankComboColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text42 = "~dropdowntype" + col + "~";   //delete all lines for combos
                string old42;
                string n42 = "";
                StreamReader sr42 = System.IO.File.OpenText(FileName);
                while ((old42 = sr42.ReadLine()) != null)
                {
                    if (!old42.Contains(search_text42))
                    {
                        n42 += old42 + Environment.NewLine;
                    }
                }
                sr42.Close();
                System.IO.File.WriteAllText(FileName, n42);


            }
            catch (Exception)
            {


            }

        }

        private void MakeBlankComboAutoColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                //do auto combos now
                string search_text422 = "~autodropdowntype" + col + "~";   //delete all lines for combos
                string old422;
                string n422 = "";
                StreamReader sr422 = System.IO.File.OpenText(FileName);
                while ((old422 = sr422.ReadLine()) != null)
                {
                    if (!old422.Contains(search_text422))
                    {
                        n422 += old422 + Environment.NewLine;
                    }
                }
                sr422.Close();
                System.IO.File.WriteAllText(FileName, n422);



            }
            catch (Exception)
            {


            }

        }


        //This function gets rid of all lines for a COLUMN that are NOT for a Date (ie ~chartype~, ~numtype~)
        private void MakeDateColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = "~chartype" + col + "~";   //delete all lines with this text in it (ie CHAR)
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)
                {
                    if (!old.Contains(search_text))
                    {
                        n += old + Environment.NewLine;
                    }
                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);


                string search_text2 = "~inttype" + col + "~";   //delete all lines with this text in it (ie INTEGER)
                string old2;
                string n2 = "";
                StreamReader sr2 = System.IO.File.OpenText(FileName);
                while ((old2 = sr2.ReadLine()) != null)
                {
                    if (!old2.Contains(search_text2))
                    {
                        n2 += old2 + Environment.NewLine;
                    }
                }
                sr2.Close();
                System.IO.File.WriteAllText(FileName, n2);


                string search_text3 = "~dectype" + col + "~";   //delete all lines with this text in it (ie DECIMAL)
                string old3;
                string n3 = "";
                StreamReader sr3 = System.IO.File.OpenText(FileName);
                while ((old3 = sr3.ReadLine()) != null)
                {
                    if (!old3.Contains(search_text3))
                    {
                        n3 += old3 + Environment.NewLine;
                    }
                }
                sr3.Close();
                System.IO.File.WriteAllText(FileName, n3);


            }
            catch (Exception)
            {


            }

        }

        //This function gets rid of all lines for a COLUMN that are NOT for a Char (ie ~datetype~, ~numtype~)
        private void MakeCharColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = "~datetype" + col + "~";   //delete all lines with this text in it (ie DATE)
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)
                {
                    if (!old.Contains(search_text))
                    {
                        n += old + Environment.NewLine;
                    }
                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);


                string search_text2 = "~inttype" + col + "~";   //delete all lines with this text in it (ie INTEGER)
                string old2;
                string n2 = "";
                StreamReader sr2 = System.IO.File.OpenText(FileName);
                while ((old2 = sr2.ReadLine()) != null)
                {
                    if (!old2.Contains(search_text2))
                    {
                        n2 += old2 + Environment.NewLine;
                    }
                }
                sr2.Close();
                System.IO.File.WriteAllText(FileName, n2);


                string search_text3 = "~dectype" + col + "~";   //delete all lines with this text in it (ie DECIMAL)
                string old3;
                string n3 = "";
                StreamReader sr3 = System.IO.File.OpenText(FileName);
                while ((old3 = sr3.ReadLine()) != null)
                {
                    if (!old3.Contains(search_text3))
                    {
                        n3 += old3 + Environment.NewLine;
                    }
                }
                sr3.Close();
                System.IO.File.WriteAllText(FileName, n3);


            }
            catch (Exception)
            {


            }

        }

        //This function gets rid of all lines for a COLUMN that are NOT for a Number (ie ~chartype~, ~datetype~, ~dectype~)
        private void MakeIntColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = "~chartype" + col + "~";   //delete all lines with this text in it (ie CHAR)
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)
                {
                    if (!old.Contains(search_text))
                    {
                        n += old + Environment.NewLine;
                    }
                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);


                string search_text2 = "~datetype" + col + "~";   //delete all lines with this text in it (ie DATE)
                string old2;
                string n2 = "";
                StreamReader sr2 = System.IO.File.OpenText(FileName);
                while ((old2 = sr2.ReadLine()) != null)
                {
                    if (!old2.Contains(search_text2))
                    {
                        n2 += old2 + Environment.NewLine;
                    }
                }
                sr2.Close();
                System.IO.File.WriteAllText(FileName, n2);


                string search_text3 = "~dectype" + col + "~";   //delete all lines with this text in it (ie DECIMAL)
                string old3;
                string n3 = "";
                StreamReader sr3 = System.IO.File.OpenText(FileName);
                while ((old3 = sr3.ReadLine()) != null)
                {
                    if (!old3.Contains(search_text3))
                    {
                        n3 += old3 + Environment.NewLine;
                    }
                }
                sr3.Close();
                System.IO.File.WriteAllText(FileName, n3);


            }
            catch (Exception)
            {


            }

        }

        //This function gets rid of all lines for a COLUMN that are NOT for a Number (ie ~chartype~, ~datetype~, ~inttype~)
        private void MakeDecColumn(string infile, string col)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = "~chartype" + col + "~";   //delete all lines with this text in it (ie CHAR)
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)
                {
                    if (!old.Contains(search_text))
                    {
                        n += old + Environment.NewLine;
                    }
                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);


                string search_text2 = "~datetype" + col + "~";   //delete all lines with this text in it (ie DATE)
                string old2;
                string n2 = "";
                StreamReader sr2 = System.IO.File.OpenText(FileName);
                while ((old2 = sr2.ReadLine()) != null)
                {
                    if (!old2.Contains(search_text2))
                    {
                        n2 += old2 + Environment.NewLine;
                    }
                }
                sr2.Close();
                System.IO.File.WriteAllText(FileName, n2);


                string search_text3 = "~inttype" + col + "~";   //delete all lines with this text in it (ie INTEGER)
                string old3;
                string n3 = "";
                StreamReader sr3 = System.IO.File.OpenText(FileName);
                while ((old3 = sr3.ReadLine()) != null)
                {
                    if (!old3.Contains(search_text3))
                    {
                        n3 += old3 + Environment.NewLine;
                    }
                }
                sr3.Close();
                System.IO.File.WriteAllText(FileName, n3);


            }
            catch (Exception)
            {


            }

        }



        //-------------------------------------------------------------------------
        private void UpdateAHIMproj(string infile, string col, string newline)
        {

            MakeAHIMChange(infile, col, newline);
        }
        private void MakeAHIMChange(string infile, string col, string newline)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = col;   //Find line from where to Add new line
                string old;
                string n = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)   //read all lines
                {
                    if (old.Contains(search_text))
                    {
                        n += newline + Environment.NewLine;   //add new line, after found target line
                    }

                    n += old + Environment.NewLine;

                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);

            }
            catch (Exception)
            {


            }

        }



        private void MakeAHIMDelete(string infile, string col, string newline)
        {
            try
            {
                //var FileName = HttpContext.Server.MapPath(infile);
                var FileName = System.IO.Path.Combine(_Env.ContentRootPath, infile);

                string search_text = col;   //Find line from where to Add new line
                string old;
                string n = "";
                //string chk = "";
                StreamReader sr = System.IO.File.OpenText(FileName);
                while ((old = sr.ReadLine()) != null)   //read all lines
                {
                    if (old.Contains(search_text))
                    {
                        //chk = "found";
                    }
                    else
                    {
                        n += old + Environment.NewLine;
                    }

                }
                sr.Close();
                System.IO.File.WriteAllText(FileName, n);

            }
            catch (Exception)
            {


            }

        }





    }
}
