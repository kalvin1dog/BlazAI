﻿using appBLL;
using BlazLite1.Shared;
using Microsoft.AspNetCore.Mvc;

namespace BlazLite1.Server.Controllers
{
    //[Authorize]
    [ApiController]
    //[Route("[controller]")]
    //[Route("[controller]")]
    public class TableGenController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;

        public TableGenController(IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }


        [HttpGet]
        [Route("api/KEL")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                //TemperatureC = Random.Shared.Next(-20, 55),
                // = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }


        [HttpGet]
        [Route("api/TableNamesOnly/GetAsyncName")]
        public async Task<IEnumerable<TableName>> GetAsyncName(string Id)
        //public IEnumerable<TableName> GetName()   //works
        {
            string testget = Id;

            List<TableName> ColJobs = new List<TableName>();

            bool returnStatus;
            string returnErrorMessage;
          
            TableGenBLL ThisBLL = new TableGenBLL();

            string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;


            ColJobs = ThisBLL.GetTableNamesOnly(
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }



        [HttpGet]
        [Route("api/TableGen/GetAsync")]
        public async Task<IEnumerable<TableGen>> GetAsync(string Id)
        {
            string testget = Id;

            List<TableGen> ColJobs = new List<TableGen>();

            bool returnStatus;
            string returnErrorMessage;
           
            TableGenBLL ThisBLL = new TableGenBLL();

            string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;

            ColJobs = ThisBLL.GetTableGens(
                Id,
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);


            return ColJobs;

        }



    }
}
