using BlazLite1.Shared.CountryRefUI;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Data.SQLite;
using appBLL;
 
namespace BlazLite1.Server.CountryRefUI
{
    /// <summary>
    /// GLOBAL Business Logic Layer
    /// </summary>
    public class CountryRefBLL
    {

        /// <summary>
        /// Uses PAGING GRID Query to get 1 page at a time.
        /// By internal SQL statement
        /// </summary>
        public List<CountryRef> CountryRefSearch(
            CountryRef SearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int totalRows,
            out int totalPages,
            out int pageRows,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentRow;
            int result;

            try
            {
                totalPages = 0;
                totalRows = 0;
               pageRows = 0;
               double timediff = SearchValues.TimeDiff;     //getting local time difference from UTC, from javascript on client

                List<CountryRef> GridList = new List<CountryRef>();
                
                DataTable scriptDataTable = GetCountryRef(SearchValues,
                    currentPageNumber,
                    pageSize,
                    sortBy,
                    sortAscendingDescending,
                    DBConnectString,
                    out totalRows,
                    out returnStatus,
                    out returnErrorMessage);

                if (returnStatus == false)
                {
                    return GridList;
                }

                //totalRows = scriptDataTable.Rows.Count;
                totalPages = 0;

                Math.DivRem(totalRows, pageSize, out result);
                if (result > 0)
                    totalPages = Convert.ToInt32(totalRows / pageSize) + 1;
                else
                    totalPages = Convert.ToInt32(totalRows / pageSize);

                currentRow = 0;

                for (int i = 0; i < scriptDataTable.Rows.Count; i++)
                {
                        currentRow++;

                        CountryRef recList = new CountryRef();

                        recList.Country_ID = scriptDataTable.Rows[i]["Country_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Country_ID"]) : 0;

                        recList.Name = scriptDataTable.Rows[i]["Name"] != DBNull.Value ? scriptDataTable.Rows[i]["Name"].ToString() : "";



                        recList.Capitol = scriptDataTable.Rows[i]["Capitol"] != DBNull.Value ? scriptDataTable.Rows[i]["Capitol"].ToString() : "";



                        recList.Language = scriptDataTable.Rows[i]["Language"] != DBNull.Value ? scriptDataTable.Rows[i]["Language"].ToString() : "";
           





                        if (scriptDataTable.Rows[i]["StartDate"] == DBNull.Value)
                        {
                            recList.StartDate = Convert.ToDateTime("01/01/1858");
                            //recList.StartDate = DateTimeOffset.Parse("01/01/1858");       //option for Date in Offset format
                        }
                        else
                        {
                            recList.StartDate = Convert.ToDateTime(scriptDataTable.Rows[i]["StartDate"]);
                            //recList.StartDate = DateTimeOffset.Parse(scriptDataTable.Rows[i]["StartDate"].ToString());      //option for Date in Offset format
                            //recList.StartDate = recList.StartDate.AddMinutes(-timediff);                                                        //adjust to local time here    
                       }

                       

                        recList.Worth = scriptDataTable.Rows[i]["Worth"] != DBNull.Value ? Convert.ToDecimal(scriptDataTable.Rows[i]["Worth"]) : 0;


                       

                        recList.Population = scriptDataTable.Rows[i]["Population"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Population"]) : 0;


                       
                        recList.Description = scriptDataTable.Rows[i]["Description"] != DBNull.Value ? scriptDataTable.Rows[i]["Description"].ToString() : "";



                       


                        if (scriptDataTable.Rows[i]["UpdateDate"] == DBNull.Value)
                        {
                            recList.UpdateDate = Convert.ToDateTime("01/01/1858");
                            //recList.UpdateDate = DateTimeOffset.Parse("01/01/1858");       //option for Date in Offset format
                        }
                        else
                        {
                            recList.UpdateDate = Convert.ToDateTime(scriptDataTable.Rows[i]["UpdateDate"]);
                            //recList.UpdateDate = DateTimeOffset.Parse(scriptDataTable.Rows[i]["UpdateDate"].ToString());      //option for Date in Offset format
                            //recList.UpdateDate = recList.UpdateDate.AddMinutes(-timediff);                                                        //adjust to local time here    
                       }

                       
                        recList.ProdImage = scriptDataTable.Rows[i]["ProdImage"] != DBNull.Value ? scriptDataTable.Rows[i]["ProdImage"].ToString() : "";




                        recList.ImageData = scriptDataTable.Rows[i]["ImageData"] != DBNull.Value ? scriptDataTable.Rows[i]["ImageData"].ToString() : "";



                       





                        recList.TotalPages = totalPages;
                        recList.TotalRows = totalRows;

                        GridList.Add(recList);

                }
                
                pageRows = currentRow;

                returnErrorMessage = "";
                returnStatus = true;
                return GridList;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
                totalPages = 0;
                totalRows = 0;
                pageRows = 0;

                List<CountryRef> GridList = new List<CountryRef>();
             
                return GridList;
            }

        }

  

        /// <summary>
        /// Get Scripts -  SQL SERVER ONLY
        /// Uses PAGING GRID Query to get 1 page at a time.
        /// By internal SQL statements
        /// </summary>
        public DataTable GetCountryRef(
            CountryRef scriptSearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int TotalRecords,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage); //SQL Server
            //OracleConnection connection = CreateConnectionOracle(out returnStatus, out returnErrorMessage);  //Oracle

            //SqlConnection connection;
            //connection = new SqlConnection();
            
            SQLiteConnection connection;
            connection = new SQLiteConnection();


            try
            {
                int StartPoint;
                int EndPoint;
                String strfilter = "";
                bool GlobalSearchSQL = false;

                DataSet scriptData = new DataSet();

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                //SqlCommand scriptCommand = new SqlCommand();
                SQLiteCommand scriptCommand = new SQLiteCommand();
                scriptCommand.CommandType = CommandType.Text;
                scriptCommand.Connection = connection;


                //String strFields = "Country_ID, Name, Capitol, ";
                //strFields = strFields + "Language, ";

                String strFields = "Country_ID, Name, Capitol ";

                strFields = strFields + ", Language ";
                strFields = strFields + ", Description ";
                strFields = strFields + ", ProdImage ";
                strFields = strFields + ", ImageData ";
                
                strFields = strFields + ", StartDate ";
                strFields = strFields + ", UpdateDate ";
                   
                strFields = strFields + ", Population ";
                      
                strFields = strFields + ", Worth ";

                String strTable = "Country ";
               
                strfilter = " WHERE 1=1 ";


                //Next code will have to be done manually, depending if any columns are Char
                //if (scriptSearchValues.GlobalSearchString != null)
                //{
                    //GlobalSearchSQL = true;
                    //strfilter = strfilter + " AND ( ";

                    //strfilter = strfilter + " UPPER(Name_Str) LIKE @ppt1 OR  ";
                    //SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                    //param1.Value = "%" + scriptSearchValues.GlobalSearchString.ToUpper().Trim() + "%";
                    //scriptCommand.Parameters.Add(param1);

                    //strfilter = strfilter + " UPPER(Capitol_Str) LIKE @ppt2  ";
                    //SQLiteParameter param2 = new SQLiteParameter("@ppt2", DbType.String);
                    //param2.Value = "%" + scriptSearchValues.GlobalSearchString.ToUpper().Trim() + "%";
                    //scriptCommand.Parameters.Add(param2);

                    //strfilter = strfilter + " ) ";
                //}


                if (GlobalSearchSQL == false)  //OK use normal individual Search strings
                {
                    if (scriptSearchValues.Name_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(Name) LIKE @ppt1 ";
                        //SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                        SQLiteParameter param1 = new SQLiteParameter("@ppt1", DbType.String);
                        param1.Value = "%" + scriptSearchValues.Name_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param1);
                    }





                    if (scriptSearchValues.Capitol_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(Capitol) LIKE @ppt2 ";
                        SQLiteParameter param2 = new SQLiteParameter("@ppt2", DbType.String);
                        param2.Value = "%" + scriptSearchValues.Capitol_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param2);
                    }





                    if (scriptSearchValues.Language_Str != null)
                    {
                        strfilter = strfilter + " AND UPPER(Language) LIKE @ppt3 ";
                        SQLiteParameter param3 = new SQLiteParameter("@ppt3", DbType.String);
                        param3.Value = "%" + scriptSearchValues.Language_Str.ToUpper().Trim() + "%";
                        scriptCommand.Parameters.Add(param3);
                    }








                    if (scriptSearchValues.StartDate_Str != null)
                    {
                        strfilter = strfilter + " AND StartDate >= @ppt4 ";
                        SQLiteParameter paramcol4 = new SQLiteParameter("@ppt4", DbType.DateTime);
                        paramcol4.Value = "" + scriptSearchValues.StartDate_Str.ToUpper().Trim() + "";
                        scriptCommand.Parameters.Add(paramcol4);
                     }

                    //if (scriptSearchValues.Language_Str != null)
                    //{
                        //SQLiteParameter param11 = new SQLiteParameter("@ppt3", DbType.DateTime);
                        //param11.Value = "" + scriptSearchValues.Language_Str.ToUpper().Trim() + "";
                        //scriptCommand.Parameters.Add(param11);

                       // if (scriptSearchValues.StartDate_Str != null)
                       // {
                           // sqlWhereClause.Append(" AND Language BETWEEN @ppt3 AND @ppt4 ");
                            //SQLiteParameter param12 = new SQLiteParameter("@ppt4", DbType.DateTime);
                            //param12.Value = "" + scriptSearchValues.StartDate_Str.ToUpper().Trim() + "";
                            //scriptCommand.Parameters.Add(param12);
                        //}
                    //}


                }


                //String strWherePK = "WHERE Country_ID = @PKID ";
                //SQLiteParameter parampk = new SQLiteParameter("@PKID", DbType.Int32);
                //parampk.Value = scriptSearchValues.Country_ID;
                //scriptCommand.Parameters.Add(parampk);


                String strsort = "";
                if (sortBy == "Country_ID")
                {
                    strsort = strsort + " ORDER BY Country_ID ";
                }
                else if (sortBy == "Name")
                {
                    strsort = strsort + " ORDER BY Name ";
                }
                else if (sortBy == "Capitol")
                {
                    strsort = strsort + " ORDER BY Capitol ";
                }
                else if (sortBy == "Language")
                {
                    strsort = strsort + " ORDER BY Language ";
                }
                else if (sortBy == "StartDate")
                {
                    strsort = strsort + " ORDER BY StartDate ";
                }
                //else if (sortBy == "Worth")
                //{
                    //strsort = strsort + " ORDER BY Worth ";
                //}

                //else if (sortBy == "CountryRefSixthCol")
                //{
                    //strsort = strsort + " ORDER BY StartDate ";
                //}
                else
                {
                    strsort = strsort + " ORDER BY StartDate ";
                }

                if (sortAscendingDescending == "DESC")
                {
                    strsort = strsort + " DESC ";
                }
               
                

                if (currentPageNumber == 1)
                {
                    StartPoint = 1;
                }
                else
                {
                    StartPoint = ((currentPageNumber - 1) * pageSize) + 1;
                }
                EndPoint = currentPageNumber * pageSize;

                String strSQL = "";

                TotalRecords = 0;
                strSQL = "SELECT count(*) FROM " + strTable + strfilter;
                scriptCommand.CommandText = strSQL;
                TotalRecords = Convert.ToInt32(scriptCommand.ExecuteScalar());


                //if PageSize = -1, then creating PDF Report instead, so get all records.
                if (pageSize == -1)
                {
                    EndPoint = TotalRecords;
                }


                //Check if PK_ID exists, that means coming back from Update/Add popup. PK_ID is 0 for normal grid paging
                strSQL = "";
                //if (scriptSearchValues.Country_ID != 0)
                //{
                   // strSQL = "SELECT  " + strFields + " FROM " + strTable + strWherePK;
                   // strSQL = strSQL + " UNION ";
                   // if (TotalRecords == 0)   //going to show only 1 record
                   // {
                   //     TotalRecords = 1;  //so as to show the one record in grid at least
                   // }
                //}

                strSQL = strSQL + "SELECT  " + strFields + " FROM ";
                strSQL = strSQL + " (SELECT ROW_NUMBER() OVER (" + strsort + ") ";
                //strSQL = strSQL + " (SELECT TOP " + EndPoint + " ROW_NUMBER() OVER (" + strsort + ") ";
                strSQL = strSQL + " AS Row, " + strFields + " FROM " + strTable + strfilter + ") ";
                strSQL = strSQL + " AS LogWithRowNumbers ";
                //strSQL = strSQL + " WHERE Row >= @Startit AND Row <= @Endit " + " ";
                strSQL = strSQL + " WHERE Row >= " + StartPoint + " AND Row <= " + EndPoint + " ";
                strSQL = strSQL + strsort + " ";


                scriptCommand.CommandText = strSQL;

                //scriptCommand.Parameters.AddWithValue("Startit", StartPoint);
                //scriptCommand.Parameters.AddWithValue("Endit", EndPoint);

                SQLiteDataAdapter sqlAdapter = new SQLiteDataAdapter(scriptCommand);
                sqlAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;  //NB!!!!!
                sqlAdapter.Fill(scriptData);

               
                //strSQL = "SELECT count(*) FROM " + strTable + strfilter;
                //scriptCommand.CommandText = strSQL;
                //TotalRecords = Convert.ToInt32(scriptCommand.ExecuteScalar());

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }

                returnErrorMessage = "";
                returnStatus = true;

                return scriptData.Tables[0];
            }
            catch (Exception ex)
            {
                TotalRecords = 0;
                returnStatus = false;
                returnErrorMessage = ex.Message;
                //print ("error message is: " + returnErrorMessage);
                //Console.WriteLine("error message is: " + returnErrorMessage);

                DataTable scriptData = new DataTable();
                return scriptData;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
               // {
                   // connection.Close();
                   // connection.Dispose();
               // }
               
            }


        }



        /// <summary>
        /// Get Detail Information
        /// </summary>
        public CountryRef GetCountryRefDetail(int PK_ID, string DBconnectString,
            out bool returnStatus,
            out string returnErrorMessage,
            out List<string> returnMessages)
        {

           //UtilitiesBLL UtilitiesBLLget = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLLget.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage); //SQL Server
            SqlConnection connection;
            connection = new SqlConnection();

            try
            {

                //List<RiskLevelList> ptypeList = new List<RiskLevelList>();

                string sqlString = "SELECT * FROM Country WHERE Country_ID = @PK_ID";
               //string sqlString = "SELECT * FROM ~viewcombotable~ WHERE Country_ID = @PK_ID";       //for normal combo, so as to show field on detail form

                returnErrorMessage = "";

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBconnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@PK_ID", DbType.String);
                param1.Value = PK_ID;
                //param1.Value = 312;
                sqlCommand.Parameters.Add(param1);

                SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);

                DataSet scriptData = new DataSet();
                sqlAdapter.Fill(scriptData);

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Country Information Retrieved");

                returnStatus = true;
                returnMessages = outputMessages;

                DateTime dateResult;
                string dateCheck = "";

                CountryRef script = new CountryRef();

                script.Country_ID = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Country_ID"]);

                //script.Name = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Name"]);

                 script.Name = scriptData.Tables[0].Rows[0]["Name"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Name"].ToString() : "";




                //script.Capitol = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Capitol"]);

                 script.Capitol = scriptData.Tables[0].Rows[0]["Capitol"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Capitol"].ToString() : "";



                //script.Language = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Language"]);

                 script.Language = scriptData.Tables[0].Rows[0]["Language"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Language"].ToString() : "";






                dateCheck = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["StartDate"]);
                if (scriptData.Tables[0].Rows[0]["StartDate"] == DBNull.Value)
                {
                    script.StartDate = Convert.ToDateTime("01/01/1858");
                    script.StartDate_Str = "";    //display on form
                }
                else
                {
                    if (DateTime.TryParse(dateCheck, out dateResult) == true)
                    {
                        script.StartDate = Convert.ToDateTime(scriptData.Tables[0].Rows[0]["StartDate"]);
                        script.StartDate_Str = UtilitiesBLL.FormatDate(script.StartDate);   //display on form
                        //script.StartDate = DateTimeOffset.Parse(scriptData.Tables[0].Rows[0]["StartDate"].ToString());   //optional display Offset Date on form
                        //script.StartDate_Str = UtilitiesBLL.FormatDateOffsetTime(script.StartDate);                                           //optional display Offset Date on form
                    }
                    else
                    {
                        script.StartDate_Str = "";
                    }
                }


                
                //script.Worth = Convert.ToDecimal(scriptData.Tables[0].Rows[0]["Worth"]);


                 script.Worth = scriptData.Tables[0].Rows[0]["Worth"] != DBNull.Value ? Convert.ToDecimal(scriptData.Tables[0].Rows[0]["Worth"]) : 0;


                
                //script.Population = Convert.ToInt32(scriptData.Tables[0].Rows[0]["Population"]);


                 script.Population = scriptData.Tables[0].Rows[0]["Population"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Population"]) : 0;


                
                //script.Description = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Description"]);

                 script.Description = scriptData.Tables[0].Rows[0]["Description"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["Description"].ToString() : "";



                



                dateCheck = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["UpdateDate"]);
                if (scriptData.Tables[0].Rows[0]["UpdateDate"] == DBNull.Value)
                {
                    script.UpdateDate = Convert.ToDateTime("01/01/1858");
                    script.UpdateDate_Str = "";    //display on form
                }
                else
                {
                    if (DateTime.TryParse(dateCheck, out dateResult) == true)
                    {
                        script.UpdateDate = Convert.ToDateTime(scriptData.Tables[0].Rows[0]["UpdateDate"]);
                        script.UpdateDate_Str = UtilitiesBLL.FormatDate(script.UpdateDate);   //display on form
                        //script.UpdateDate = DateTimeOffset.Parse(scriptData.Tables[0].Rows[0]["UpdateDate"].ToString());   //optional display Offset Date on form
                        //script.UpdateDate_Str = UtilitiesBLL.FormatDateOffsetTime(script.UpdateDate);                                           //optional display Offset Date on form
                    }
                    else
                    {
                        script.UpdateDate_Str = "";
                    }
                }

                
                //script.ProdImage = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["ProdImage"]);

                 script.ProdImage = scriptData.Tables[0].Rows[0]["ProdImage"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["ProdImage"].ToString() : "";



                
                //script.ImageData = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["ImageData"]);

                 script.ImageData = scriptData.Tables[0].Rows[0]["ImageData"] != DBNull.Value ? scriptData.Tables[0].Rows[0]["ImageData"].ToString() : "";



                





                //Next line is for Checkbox
                //script.Private_Cover = scriptData.Tables[0].Rows[0]["Private_Cover"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["Private_Cover"]) : 0;
       
                //Next line is for Radio Button
                //script.Sex = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["Sex"]);


                //----------------------------------------------------------------------------------------------------------------------
                //For Combo Normal processing  NOTE:-  Usually using an above column for combo display (eg column4)
                //                                                               
                //----------------------------------------------------------------------------------------------------------------------
                //next for combo by TEXT only
                //script.normcombocol1 = UtilitiesBLL.ConvertToString(scriptData.Tables[0].Rows[0]["normcombocol1"]);    //normcombocol1  is column in table (usually a text field)   

                //ONLY NEED next line for when using an ID as the key stored in the Table. normcombopkid is a column in the table.
                //script.normcombopkid = scriptData.Tables[0].Rows[0]["normcombopkid"] != DBNull.Value ? Convert.ToInt32(scriptData.Tables[0].Rows[0]["normcombopkid"]) : 0;
                //----------------------------------------------------------------------------------------------------------------------
                //END For Combo Normal processing
                //----------------------------------------------------------------------------------------------------------------------




                //---------------------------------------------------------------------------------------------------
                //get List for normal combo in EDIT mode, Get combo List ready for process in detail form
                //Reading Reference table
                //---------------------------------------------------------------------------------------------------
                //List<CountryRefnormcombo> CountryRefnormcomboList = new List<CountryRefnormcombo>(); 
                //CountryRefnormcomboList = GetCountryRefnormcombo(out returnStatus, out returnErrorMessage);
                //script.CountryRefnormcomboList = CountryRefnormcomboList;
                //---------------------------------------------------------------------------------------------------
                //END get Combo list
                //---------------------------------------------------------------------------------------------------

                return script;

            }
            catch (Exception ex)
            {

                List<string> outputMessages = new List<string>();

                returnStatus = false;
                returnErrorMessage = ex.Message;
                returnMessages = outputMessages;

                CountryRef script = new CountryRef();

                return script;
            }
            finally
            {
                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
            }

        }



        /// <summary>
        /// Format Detail Data
        /// </summary>
        public void FormatScriptData(ref CountryRef scriptInformation, 
            out bool returnStatus,                                    
            out string returnErrorMessage)
        {

            try
            {
                if (scriptInformation.Name == null) scriptInformation.Name = "";
                if (scriptInformation.Capitol == null) scriptInformation.Capitol = "";
                if (scriptInformation.Language == null) scriptInformation.Language = "";
                
                if (scriptInformation.Description == null) scriptInformation.Description = "";
                
                if (scriptInformation.ProdImage == null) scriptInformation.ProdImage = "";
                if (scriptInformation.ImageData == null) scriptInformation.ImageData = "";
             

                //if (scriptInformation.Company == null) scriptInformation.Company = "";
                //if (scriptInformation.Script_Code == null) scriptInformation.Script_Code = "";

                //scriptInformation.Script_Name = scriptInformation.Script_Name.ToUpper().Trim();
                //scriptInformation.Company = scriptInformation.Company.ToUpper().Trim();
                //scriptInformation.Script_Code = scriptInformation.Script_Code.ToUpper().Trim();

                returnErrorMessage = "";
                returnStatus = true;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
            }

        }

        /// <summary>
        /// Validate Detail
        /// </summary>
        public bool ValidateScript(CountryRef scriptInformation, 
            out List<string> Messages, 
            out bool returnStatus, 
            out string returnErrorMessage)
        {

            try
            {

                bool validPatient = true;

                List<string> outputMessages = new List<string>();

                if (scriptInformation.Name == null || scriptInformation.Name.Trim().Length == 0)
                {
                    outputMessages.Add("Name is required.Name");
                    validPatient = false;
                }




                if (scriptInformation.Capitol == null || scriptInformation.Capitol.Trim().Length == 0)
                {
                    outputMessages.Add("Capitol is required.Capitol");
                    validPatient = false;
                }




                if (scriptInformation.Language == null || scriptInformation.Language.Trim().Length == 0)
                {
                    outputMessages.Add("Language is required.~Language");
                    validPatient = false;
                }





                if (appBLL.UtilitiesBLL.IsValidDate(scriptInformation.StartDate.ToString()) == false)
                {
                    outputMessages.Add("StartDate is invalid.StartDate");
                    validPatient = false;
                }

                if (appBLL.UtilitiesBLL.IsDateSupplied(scriptInformation.StartDate.ToString()) == false)
                {
                    outputMessages.Add("StartDate is required.StartDate");
                    validPatient = false;
                }


                //Check for Duplicates
                /*
                if (scriptInformation.Country_ID != null && scriptInformation.Name != null)
                {
                    bool duplicateVehicle = DuplicateVehicle(
                        scriptInformation.Country_ID,
                        scriptInformation.Name, 
                        out returnStatus, 
                        out returnErrorMessage);

                    if (returnStatus == false)
                    {
                        outputMessages.Add(returnErrorMessage);
                        Messages = outputMessages;
                        return false;
                    }

                    if (duplicateVehicle == true)
                    {
                        outputMessages.Add("Duplicate Country_ID and/or Name");
                        validPatient = false;
                    }
                }
                */


                Messages = outputMessages;

                returnStatus = true;
                returnErrorMessage = "";

                return validPatient;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();
                Messages = outputMessages;

                returnStatus = false;
                returnErrorMessage = ex.Message;
                
                return false;
            }

        }

        
        /// <summary>
        /// Check For Duplicate Detail
        /// </summary>
        public bool DuplicateVehicle(int vehicleID, 
            string vehicleName, 
            out bool returnStatus, 
            out string returnErrorMessage)
        {

           //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            SqlConnection connection;
            connection = new SqlConnection();

            try
            {

                string sqlString = "SELECT Country_ID FROM Country ";
                sqlString = sqlString + " WHERE Name = @Name ";
 
                if (vehicleID > 0)
                {
                    sqlString = sqlString + " AND Country_ID <> @VEHICLE_ID";
                }

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();
                //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                String DBconnectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBconnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@Name", DbType.String);
                param1.Value = vehicleName;
                sqlCommand.Parameters.Add(param1);

                if (vehicleID > 0)
                {
                    SQLiteParameter param3 = new SQLiteParameter("@VEHICLE_ID", DbType.Int32);
                    param3.Value = vehicleID;
                    sqlCommand.Parameters.Add(param3);
                }

                bool duplicatePatient = false;

                IDataReader dataReader = sqlCommand.ExecuteReader();
                if (dataReader.Read())
                {
                    duplicatePatient = true;
                }

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                returnStatus = true;
                returnErrorMessage = "";

                return duplicatePatient;

            }
            catch (Exception ex)
            {               
                returnStatus = false;
                returnErrorMessage = ex.Message;

                return false;
            }
            finally
            {
                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
            }

        }
     
        
         
        /// <summary>
        /// Add Detail
        /// </summary>
        public CountryRef AddCountryRef(CountryRef scriptInformation, 
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out List<string>returnMessages, 
            out bool returnStatus,
            out string returnErrorMessage)
        {

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            
            SQLiteConnection connection;
            connection = new SQLiteConnection();


            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;
                returnRowNumber = -2;
          
                //StringBuilder sqlBuilder = new StringBuilder();

                List<string> messages;

                FormatScriptData(ref scriptInformation, out returnStatus, out returnErrorMessage);

                bool validScript = ValidateScript(
                    scriptInformation,
                    out messages,
                    out returnStatus,
                    out returnErrorMessage);

                if (validScript == false)
                {
                    returnStatus = false;
                    returnMessages = messages;
                    scriptInformation.Country_ID = -1;  //if validation error, make sure sent back json PK_ID is still set to -1 (for Add)
                    return scriptInformation;
                }


                string sqlString = "INSERT INTO Country ( ";
                sqlString = sqlString + " Name, Capitol, ";

                sqlString = sqlString + " Description, ";
                sqlString = sqlString + " ProdImage, ";
                sqlString = sqlString + " ImageData, ";
                
                sqlString = sqlString + " UpdateDate, ";
                
                sqlString = sqlString + " Population, ";
                  
                sqlString = sqlString + " Worth, ";


                sqlString = sqlString + " Language, StartDate) VALUES ( ";
                sqlString = sqlString + " @Colum1, @Colum2, ";

                sqlString = sqlString + " @Colum7, ";
                sqlString = sqlString + " @Colum9, ";
                sqlString = sqlString + " @Colum10, ";
                 
                sqlString = sqlString + " @colum8, ";
                
                sqlString = sqlString + " @colum6, ";
                  
                sqlString = sqlString + " @colum5, ";

                sqlString = sqlString + " @Colum3, @Colum4)";
                //sqlString = sqlString + " select SCOPE_IDENTITY()";



                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter param1 = new SQLiteParameter("@Colum1", DbType.String);
                param1.Value = scriptInformation.Name;
                sqlCommand.Parameters.Add(param1);





                SQLiteParameter param2 = new SQLiteParameter("@Colum2", DbType.String);
                param2.Value = scriptInformation.Capitol;
                sqlCommand.Parameters.Add(param2);





                SQLiteParameter param3 = new SQLiteParameter("@Colum3", DbType.String);
                param3.Value = scriptInformation.Language;
                sqlCommand.Parameters.Add(param3);








                SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTime);
                //SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTimeOffset);    //optional for Offset Date format
                param4.Value = scriptInformation.StartDate;
                sqlCommand.Parameters.Add(param4);




                SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Decimal);
                param5.Value = scriptInformation.Worth;
                sqlCommand.Parameters.Add(param5);


                

                SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                param6.Value = scriptInformation.Population;
                sqlCommand.Parameters.Add(param6);



                
                SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                param7.Value = scriptInformation.Description;
                sqlCommand.Parameters.Add(param7);




                



                SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.DateTime);
                //SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.DateTimeOffset);    //optional for Offset Date format
                param8.Value = scriptInformation.UpdateDate;
                sqlCommand.Parameters.Add(param8);

                
                SQLiteParameter param9 = new SQLiteParameter("@Colum9", DbType.String);
                param9.Value = scriptInformation.ProdImage;
                sqlCommand.Parameters.Add(param9);




                
                SQLiteParameter param10 = new SQLiteParameter("@Colum10", DbType.String);
                param10.Value = scriptInformation.ImageData;
                sqlCommand.Parameters.Add(param10);




                







                //next parameter is for Checkbox processing
                //SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                //param5.Value = scriptInformation.Private_Cover;
                //sqlCommand.Parameters.Add(param5);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.String);    //combo by TEXT only. 
                //param6.Value = scriptInformation.normcombocol1;   
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                //param6.Value = scriptInformation.normcombopkid;
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                //param7.Value = scriptInformation.Sex;
                //sqlCommand.Parameters.Add(param7);


                int Status = sqlCommand.ExecuteNonQuery();

                sqlCommand.CommandText = "select last_insert_rowid()";

                scriptInformation.Country_ID = Convert.ToInt32(sqlCommand.ExecuteScalar());

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Country has been added.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();
                outputMessages.Add(ex.Message);
        
                returnPageNumber = -1;
                returnRowNumber = -2;
                returnStatus = false;
                returnErrorMessage = ex.Message;
                returnMessages = outputMessages;
                scriptInformation.Country_ID = -1;  //if validation error, make sure sent back json PK_ID is still set to -1 (for Add)
                //connection.Close();

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                   // connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }

       


        /// <summary>
        /// Update Detail
        /// </summary>
        public CountryRef UpdateCountryRef(CountryRef scriptInformation, 
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,          
            out List<string> returnMessages)
        {

            string returnErrorMessage;

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                List<string> messages;

                FormatScriptData(ref scriptInformation, out returnStatus, out returnErrorMessage);

                bool validPatient = ValidateScript(
                    scriptInformation,
                    out messages,
                    out returnStatus,
                    out returnErrorMessage);

                if (returnStatus == false)
                {
                    returnStatus = false;
                    messages.Add(returnErrorMessage);
                    returnMessages = messages;
                    return scriptInformation;
                }

                if (validPatient == false)
                {
                    returnStatus = false;                   
                    returnMessages = messages;
                    return scriptInformation;
                }

                string sqlString = "UPDATE Country SET ";
                sqlString = sqlString + " Name = @Colum1, ";
                sqlString = sqlString + " Capitol = @Colum2, ";
                sqlString = sqlString + " Language = @Colum3, ";

                sqlString = sqlString + " Description = @Colum7, ";
                sqlString = sqlString + " ProdImage = @Colum9, ";
                sqlString = sqlString + " ImageData = @Colum10, ";
                
                sqlString = sqlString + " UpdateDate = @Colum8, ";
                
                sqlString = sqlString + " Population = @Colum6, ";
                   
                sqlString = sqlString + " Worth = @Colum5, ";

                sqlString = sqlString + " StartDate = @Colum4 ";
                sqlString = sqlString + " WHERE Country_ID = @PK_ID ";


                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                SQLiteParameter paramPatientID = new SQLiteParameter("@PK_ID", DbType.Int32);
                paramPatientID.Value = scriptInformation.Country_ID;
                sqlCommand.Parameters.Add(paramPatientID);

                SQLiteParameter param1 = new SQLiteParameter("@Colum1", DbType.String);
                param1.Value = scriptInformation.Name;
                sqlCommand.Parameters.Add(param1);





                SQLiteParameter param2 = new SQLiteParameter("@Colum2", DbType.String);
                param2.Value = scriptInformation.Capitol;
                sqlCommand.Parameters.Add(param2);





                SQLiteParameter param3 = new SQLiteParameter("@Colum3", DbType.String);
                param3.Value = scriptInformation.Language;
                sqlCommand.Parameters.Add(param3);








                SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTime);
                //SQLiteParameter param4 = new SQLiteParameter("@Colum4", DbType.DateTimeOffset);    //optional for Offset Date format
                param4.Value = scriptInformation.StartDate;
                sqlCommand.Parameters.Add(param4);

                


                SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Decimal);
                param5.Value = scriptInformation.Worth;
                sqlCommand.Parameters.Add(param5);


                     

                SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                param6.Value = scriptInformation.Population;
                sqlCommand.Parameters.Add(param6);



                
                SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                param7.Value = scriptInformation.Description;
                sqlCommand.Parameters.Add(param7);




                



                SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.DateTime);
                //SQLiteParameter param8 = new SQLiteParameter("@Colum8", DbType.DateTimeOffset);    //optional for Offset Date format
                param8.Value = scriptInformation.UpdateDate;
                sqlCommand.Parameters.Add(param8);

                
                SQLiteParameter param9 = new SQLiteParameter("@Colum9", DbType.String);
                param9.Value = scriptInformation.ProdImage;
                sqlCommand.Parameters.Add(param9);




                
                SQLiteParameter param10 = new SQLiteParameter("@Colum10", DbType.String);
                param10.Value = scriptInformation.ImageData;
                sqlCommand.Parameters.Add(param10);




                







                //next parameter is for Checkbox processing
                //SQLiteParameter param5 = new SQLiteParameter("@Colum5", DbType.Int32);
                //param5.Value = scriptInformation.Private_Cover;
                //sqlCommand.Parameters.Add(param5);




                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.String);    //combo by TEXT only. 
                //param6.Value = scriptInformation.normcombocol1;   
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param6 = new SQLiteParameter("@Colum6", DbType.Int32);
                //param6.Value = scriptInformation.normcombopkid;
                //sqlCommand.Parameters.Add(param6);

                //SQLiteParameter param7 = new SQLiteParameter("@Colum7", DbType.String);
                //param7.Value = scriptInformation.Sex;
                //sqlCommand.Parameters.Add(param7);

                sqlCommand.ExecuteNonQuery();

                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Country has been updated.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
               // }
               
            }

        }


        /// <summary>
        /// Delete Detail record
        /// </summary>
        public CountryRef DelCountryRef(CountryRef scriptInformation,
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,
            out List<string> returnMessages)
        {

           string returnErrorMessage;

           //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
           //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                string sqlString = "DELETE FROM Country ";
                sqlString = sqlString + " WHERE Country_ID = @PK_ID ";

                //sqlBuilder.Append("DELETE Country ");
                //sqlBuilder.Append(" WHERE Country_ID = @PK_ID ");

                //string sqlString = sqlBuilder.ToString();

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;


                SQLiteParameter paramPatientID = new SQLiteParameter("@PK_ID", DbType.Int32);
                paramPatientID.Value = scriptInformation.Country_ID;
                sqlCommand.Parameters.Add(paramPatientID);

                sqlCommand.ExecuteNonQuery();



                //-------------------------------------------------------------------------------------------------------------
                //If you have to Delete child records as well, then do following. Do grand child records if needed.
                //Change the top SQL to Delete the child records first, and then the parent table records next
                //-------------------------------------------------------------------------------------------------------------

                //sqlCommand.Parameters.Clear();

                //sqlString = "";
                //sqlBuilder = new StringBuilder();

                //sqlBuilder.Append("DELETE FROM childtable ");      //do this up above first instead
                //sqlBuilder.Append(" WHERE Country_ID = @PK_ID2 ");

                //SQLiteParameter paramPatientID2 = new SQLiteParameter("@PK_ID2", DbType.Int32);
                //paramPatientID2.Value = scriptInformation.Country_ID;
                //sqlCommand.Parameters.Add(paramPatientID2);

                //sqlString = sqlBuilder.ToString();
                //sqlCommand.CommandText = sqlString;
                //sqlCommand.ExecuteNonQuery();

                //-------------------------------------------------------------------------------------------------------------
                //END If you have to Delete child records as well, then do following. Do grand child records if needed.
                //Change the top SQL to Delete the child records first, and then the parent table records next
                //-------------------------------------------------------------------------------------------------------------


                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Country has been deleted.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }



        /// <summary>
        /// Delete Detail records in a List
        /// </summary>
        public CountryRef DelCountryRefALL(CountryRef scriptInformation,
            string DBConnectString,
            out int returnPageNumber,
            out int returnRowNumber,
            out bool returnStatus,
            out List<string> returnMessages)
        {

            string returnErrorMessage;

            //UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();
            //SqlConnection connection = UtilitiesBLL.CreateConnectionRMSPROD(out returnStatus, out returnErrorMessage);
            //SqlConnection connection;
            //connection = new SqlConnection();
            SQLiteConnection connection;
            connection = new SQLiteConnection();

            try
            {

                //SqlConnection connection;                                                                                                        //connectionString = System.Configuration.ConfigurationManager.AppSettings["ScriptDatabase"];
                                                                                                                                             //String connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RMS-PROD"].ToString();                                                                                                                           //String connectionString = "Server=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;";
                //String connectString = "Data Source=(localdb)\\mssqllocaldb;Database=AHIM;Trusted_Connection=True;MultipleActiveResultSets=true";

                String connectionString = DBConnectString;

                //connection = new SqlConnection();
                connection.ConnectionString = connectionString;
                connection.Open();


                returnPageNumber = -1;  //could be changed if sort field changed, later down in code
                returnRowNumber = -2;   //could be changed if sort field changed, later down in code

                //StringBuilder sqlBuilder = new StringBuilder();

                string sqlString = "";

                //SqlCommand sqlCommand = new SqlCommand();
                SQLiteCommand sqlCommand = new SQLiteCommand();
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Connection = connection;
                sqlCommand.CommandText = sqlString;

                //next loop goes around all checked rows and then delete each record
                string Chkstr;
                int counterk2 = 0;

                //foreach (var recList in scriptInformation.Chk)
                foreach (var recList in scriptInformation.PK_IDD)
                {
                    Chkstr = scriptInformation.CheckBoxx[counterk2];
                    //Chkstr = scriptInformation.Chk.ToString();
                    //Chkstr = recList.ToString();
                    if (Chkstr == "on")
                    {
                        
                        sqlString = sqlString + "DELETE FROM Country ";
                        sqlString = sqlString + " WHERE Country_ID = @PK_IDDD ";

                        SQLiteParameter param1 = new SQLiteParameter("@PK_IDDD", DbType.Int32);
                        param1.Value = scriptInformation.PK_IDD[counterk2];
                        sqlCommand.Parameters.Add(param1);


                        //sqlString = sqlBuilder.ToString();
                        sqlCommand.CommandText = sqlString;
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand.Parameters.Remove(param1);

                        sqlString = "";
                        //sqlBuilder = new StringBuilder();

                    }

                    counterk2 = counterk2 + 1;
                }


                //connection.Close();
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
               
                List<string> outputMessages = new List<string>();
                outputMessages.Add("Country/s has been deleted.");

                returnStatus = true;
                returnErrorMessage = "";
                returnMessages = outputMessages;

                return scriptInformation;
            }
            catch (Exception ex)
            {
                List<string> outputMessages = new List<string>();

                returnPageNumber = -1;
                returnRowNumber = -2;

                returnStatus = false;
                outputMessages.Add(ex.Message);
                returnMessages = outputMessages;

                return scriptInformation;
            }
            finally
            {
                //connection.Close();
                //if (connection.State == ConnectionState.Open)
                //{
                    //connection.Close();
                    //connection.Dispose();
                //}
               
            }

        }

      

        /// Uses XLS Export Query to get All pages at a time.
        public MemoryStream CountryRefSearchXLS(
            CountryRef SearchValues,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentPageNumber = 1;
            int pageSize = -1;  //to indicate it is XLS export (ie export all records)

            try
            {
                int totalPages = 0;
                int totalRows = 0;
                int pageRows = 0;
                MemoryStream msout = new MemoryStream();

               List<CountryRef> scripts = CountryRefSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    return msout;
                }

                var scriptDataTable = CreateDataTable(scripts);

                //totalRows = scriptDataTable.Rows.Count;
                UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();

                //DataTable listDataOut = new DataTable();
                //Write table out to XLS
                string[] ColOrderk = new string[5] { "Country_ID", "Name", "Capitol", "Language", "StartDate" };   //must match column names
                string[] ColNamek = new string[5] { "Country_ID", "Name", "Capitol", "Language", "StartDate" };
                //msout = UtilitiesBLL.TableToXLSms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/CountryRefList.xls");  //works OK
                msout = UtilitiesBLL.TableToXLSXms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/CountryRefList.xlsx");  //works OK


                //searchType = "";
                //searchTypeOut = searchType;
                returnErrorMessage = "";
                returnStatus = true;
                return msout;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
              
                MemoryStream mserr = new MemoryStream();
                //byte[] BLOBbyterr;
                //mserr.Write(BLOBbyterr, 0, BLOBbyterr.Length);
                return mserr;
            }

        }



        /// Uses XLSX Export Query to get All pages at a time.
        public MemoryStream CountryRefSearchXLSX(
            CountryRef SearchValues,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int currentPageNumber = 1;
            int pageSize = -1;  //to indicate it is XLS export (ie export all records)

            try
            {
                int totalPages = 0;
                int totalRows = 0;
                int pageRows = 0;
                MemoryStream msout = new MemoryStream();
              
               List<CountryRef> scripts = CountryRefSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    return msout;
                }

                var scriptDataTable = CreateDataTable(scripts);

                //totalRows = scriptDataTable.Rows.Count;
                UtilitiesBLL UtilitiesBLL = new UtilitiesBLL();

                //DataTable listDataOut = new DataTable();
                //Write table out to XLS
                string[] ColOrderk = new string[5] { "Country_ID", "Name", "Capitol", "Language", "StartDate" };   //must match column names
                string[] ColNamek = new string[5] { "Country_ID", "Name", "Capitol", "Language", "StartDate" };
                //msout = UtilitiesBLL.TableToXLSms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/CountryRefList.xls");  //works OK
                msout = UtilitiesBLL.TableToXLSXms(scriptDataTable, ColOrderk, ColNamek, true, "c:/AP/CountryRefList.xlsx");  //works OK


                //searchType = "";
                //searchTypeOut = searchType;
                returnErrorMessage = "";
                returnStatus = true;
                return msout;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
              
                MemoryStream mserr = new MemoryStream();
                //byte[] BLOBbyterr;
                //mserr.Write(BLOBbyterr, 0, BLOBbyterr.Length);
                return mserr;
            }

        }


        /// Uses PDF Report Query to get All pages at a time.
        public string CountryRefSearchPDF(
            CountryRef SearchValues,
            int currentPageNumber,
            int pageSize,
            string sortBy,
            string sortAscendingDescending,
            string DBConnectString,
            out int totalRows,
            out int totalPages,
            out bool returnStatus,
            out string returnErrorMessage)
        {

            int loopcount = -1;
            int pageSizeReal = pageSize;

            try
            {
                totalPages = 0;
                totalRows = 0;
                int pageRows = 0;
                //pageSize = 10000; //make large, so as to get all records
                pageSize = -1; //make large, so as to get all records
                string strTable = "";
                string trbgcolor = "#D3DCE5";
                string ImagePathSrc = SearchValues.Logoimg;   //Logo to display 

               List<CountryRef> scripts = CountryRefSearch(
                SearchValues,
                currentPageNumber,
                pageSize,
                sortBy,
                sortAscendingDescending,
                DBConnectString,
                out totalRows,
                out totalPages,
                out pageRows,
                out returnStatus,
                out returnErrorMessage);

                if (returnStatus == false)
                {
                    //return GridList;
                }

              var scriptDataTable = CreateDataTable(scripts); 

                if (totalRows == 0)
                {
                    strTable = strTable + " <div align='center' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                    strTable = strTable + " No Data found.";
                    strTable = strTable + " </div> ";
                }


                strTable = strTable + "<table border='0' align='center' style='width: 590px;'>";
        
                /*
                //Setup Header ROW
                strTable = strTable + "<tr bgcolor='#DCEDEA' >";

                strTable = strTable + "<th width='12%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Country_ID";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='22%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Name";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='22%' align='left'> ";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Capitol";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='21%' align='center'> ";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " Language";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";

                strTable = strTable + "<th width='23%' align='center'> ";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                strTable = strTable + " StartDate";
                strTable = strTable + " </div> ";
                strTable = strTable + "</th>";
 
                strTable = strTable + "</tr>";
                //END of Header ROW
                */

                for (int i = 0; i < scriptDataTable.Rows.Count; i++)
                {
                    //currentRow++;

                    if (i % 2 == 0)
                    {
                        trbgcolor = "#D3DCE5";
                    }
                    else
                    {
                        trbgcolor = "#ebeff2";
                    }


                        CountryRef recList = new CountryRef();

                        recList.Country_ID = scriptDataTable.Rows[i]["Country_ID"] != DBNull.Value ? Convert.ToInt32(scriptDataTable.Rows[i]["Country_ID"]) : 0;

                        recList.Name = scriptDataTable.Rows[i]["Name"] != DBNull.Value ? scriptDataTable.Rows[i]["Name"].ToString() : "";
                     



                        recList.Capitol = scriptDataTable.Rows[i]["Capitol"] != DBNull.Value ? scriptDataTable.Rows[i]["Capitol"].ToString() : "";
                    



                        recList.Language = scriptDataTable.Rows[i]["Language"] != DBNull.Value ? scriptDataTable.Rows[i]["Language"].ToString() : "";
                     



                     

                        if (scriptDataTable.Rows[i]["StartDate"] == DBNull.Value)
                        {
                            recList.StartDate = DateTime.MinValue;
                        }
                        else
                        {
                            recList.StartDate = Convert.ToDateTime(scriptDataTable.Rows[i]["StartDate"]);
                            //recList.StartDate = DateTimeOffset.Parse(scriptDataTable.Rows[i]["StartDate"].ToString());      //option for Date in Offset format
                        }

                    loopcount = loopcount + 1;
                    if (loopcount == pageSizeReal)    //write out a Page of Data
                    {

                        /*
                        strTable = strTable + "</table>";

                        strTable = strTable + "<div style='page-break-after: always;'/> </div>";

                        strTable = strTable + "<table border='0' style='width: 100%;'>";
                        //Setup Header ROW
                        strTable = strTable + "<tr bgcolor='#DCEDEA' >";

                        strTable = strTable + "<td width='12%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Country_ID";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='22%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Name";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='22%' align='left'> ";
                        strTable = strTable + " <div align='left' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Capitol";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='21%' align='center'> ";
                        strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " Language";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td width='23%' align='center'> ";
                        strTable = strTable + " <div align='center' style='font-family: Arial; font-weight: bold; font-size: 8px; color: #000000;'> ";
                        strTable = strTable + " StartDate";
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        //END of Header ROW
                        strTable = strTable + "</tr>";
                        strTable = strTable + "</table>";

                        strTable = strTable + "<table border='0' style='width: 100%;'>";
                        */

                        loopcount = 0;  //reset count again
                    }


                        strTable = strTable + "<tr bgcolor='" + trbgcolor + "' >";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 82px;'> ";
                        strTable = strTable + recList.Country_ID;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 154px;'> ";
                        strTable = strTable + recList.Name;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='left'> ";
                        //strTable = strTable + " <div align='left' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='left' style='font-size: 8px; width: 154px;'> ";
                        strTable = strTable + recList.Capitol;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='center'> ";
                        //strTable = strTable + " <div align='center' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='center' style='font-size: 8px; width: 100px;'> ";
                        strTable = strTable + recList.Language;
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        strTable = strTable + "<td align='center'> ";
                        //strTable = strTable + " <div align='center' style='font-weight: normal; font-family: Arial; font-size: 8px;'> ";
                        strTable = strTable + " <div align='center' style='font-size: 8px; width: 100px;'> ";
                        strTable = strTable + UtilitiesBLL.FormatDate(recList.StartDate);
                        //strTable = strTable + UtilitiesBLL.FormatDateOffsetTime(recList.StartDate);     //optional for Offset Date
                        strTable = strTable + " </div> ";
                        strTable = strTable + "</td>";

                        //END of data ROW
                        strTable = strTable + "</tr>";


                }
            
                strTable = strTable + "</table>";

                /*
                //------------------------------------------------------------------------------------------------------
                //Next is just a TEST, for showing formatting options. Borders, font-weight, font-family do not work for CSS on DIV in iText 7.
                //------------------------------------------------------------------------------------------------------
                strTable = strTable + "<div style='page-break-after: always;'/> </div>";

                strTable = strTable + "<table border='0' cellpadding='3' cellspacing='3' >";
                strTable = strTable + "<tr border='1' bgcolor='#777777' color='#ffffff'>";

                strTable = strTable + "<td colspan='1'>";
                strTable = strTable + " <div align='center' style='font-family: Arial; font-size: 16px; color: #000000; border: 2px solid #000000;'> ";
                strTable = strTable + " Environmental Management Charge";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "</tr>";

                strTable = strTable + "<tr>";

                strTable = strTable + "<td colspan='1'>";
                strTable = strTable + " <div align='left' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                strTable = strTable + " Environmental Management Charge22";
                strTable = strTable + " </div> ";
                strTable = strTable + "</td>";

                strTable = strTable + "</tr>";

                strTable = strTable + "</table>";
                //------------------------------------------------------------------------------------------------------
                //END TEST 
                //------------------------------------------------------------------------------------------------------
                */


                returnErrorMessage = "";
                returnStatus = true;
              
                return strTable;

            }
            catch (Exception ex)
            {
                returnErrorMessage = ex.Message;
                returnStatus = false;
                totalPages = 0;
                totalRows = 0;

                string errstr = "";
                errstr = errstr + " <div align='center' style='font-family: Arial; font-size: 12px; color: #0000FF; border: 1px solid #000000;'> ";
                errstr = errstr + " Error Found: " + returnErrorMessage;
                errstr = errstr + " </div> ";

                return errstr;

            }

        }



        private bool IsNumeric(object value)
        {
            bool Result = false;

            try
            {
                int i = Convert.ToInt32(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }


        private bool IsDouble(object value)
        {
            bool Result = false;

            try
            {
                double i = Convert.ToDouble(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }


        private bool IsDecimal(object value)
        {
            bool Result = false;

            try
            {
                decimal i = Convert.ToDecimal(value);
                Result = true;
            }
            catch
            {
                // Ignore errors 
            }
            return Result;
        }



        public DataSet CreateDataSet<T>(List<T> list)
        {
            //list is nothing or has nothing, return nothing (or add exception handling)
            if (list == null || list.Count == 0) { return null; }

            //get the type of the first obj in the list
            var obj = list[0].GetType();

            //now grab all properties
            var properties = obj.GetProperties();

            //make sure the obj has properties, return nothing (or add exception handling)
            if (properties.Length == 0) { return null; }

            //it does so create the dataset and table
            var dataSet = new DataSet();
            var dataTable = new DataTable();

            //now build the columns from the properties
            var columns = new DataColumn[properties.Length];
            for (int i = 0; i < properties.Length; i++)
            {
                columns[i] = new DataColumn(properties[i].Name, properties[i].PropertyType);
            }

            //add columns to table
            dataTable.Columns.AddRange(columns);

            //now add the list values to the table
            foreach (var item in list)
            {
                //create a new row from table
                var dataRow = dataTable.NewRow();

                //now we have to iterate thru each property of the item and retrieve it's value for the corresponding row's cell
                var itemProperties = item.GetType().GetProperties();

                for (int i = 0; i < itemProperties.Length; i++)
                {
                    dataRow[i] = itemProperties[i].GetValue(item, null);
                }

                //now add the populated row to the table
                dataTable.Rows.Add(dataRow);
            }

            //add table to dataset
            dataSet.Tables.Add(dataTable);

            return dataSet;
        }

        public DataTable CreateDataTable<T>(List<T> list)
        {
            //list is nothing or has nothing, return nothing (or add exception handling)
            if (list == null || list.Count == 0) { return null; }

            //get the type of the first obj in the list
            var obj = list[0].GetType();

            //now grab all properties
            var properties = obj.GetProperties();

            //make sure the obj has properties, return nothing (or add exception handling)
            if (properties.Length == 0) { return null; }

            //it does so create the dataset and table
            var dataSet = new DataSet();
            var dataTable = new DataTable();

            //now build the columns from the properties
            var columns = new DataColumn[properties.Length];
            for (int i = 0; i < properties.Length; i++)
            {
                columns[i] = new DataColumn(properties[i].Name, properties[i].PropertyType);
            }

            //add columns to table
            dataTable.Columns.AddRange(columns);

            //now add the list values to the table
            foreach (var item in list)
            {
                //create a new row from table
                var dataRow = dataTable.NewRow();

                //now we have to iterate thru each property of the item and retrieve it's value for the corresponding row's cell
                var itemProperties = item.GetType().GetProperties();

                for (int i = 0; i < itemProperties.Length; i++)
                {
                    dataRow[i] = itemProperties[i].GetValue(item, null);
                }

                //now add the populated row to the table
                dataTable.Rows.Add(dataRow);
            }

            //add table to dataset
            //dataSet.Tables.Add(dataTable);

            //return dataset
            return dataTable;
        }






    }

}
